﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigiShop
{
    public partial class ReportView : Form
    {
        public ReportView()
        {
            InitializeComponent();
        }

        private void ReportView_Load(object sender, EventArgs e)
        {
            Selection s = new Selection();
            s.showreport(crystalReportViewer1, "getsalesrecepit");
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
             
        }
    }
}
