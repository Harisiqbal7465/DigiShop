﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using kp.Toaster;
using CrystalDecisions.CrystalReports.Engine;
using Bunifu.UI.WinForms.BunifuTextbox;
using CrystalDecisions.Windows.Forms;

namespace DigiShop
{
    class Selection
    {
        
        public void showIteams(DataGridView gv,DataGridViewColumn c1, DataGridViewColumn c2, DataGridViewColumn c3, DataGridViewColumn c4, DataGridViewColumn c5, DataGridViewColumn c6, DataGridViewColumn c7, DataGridViewColumn c8, string data=null)
        {
            try
            {
                SqlCommand cmd;
                if (data==null)
                {
                     cmd = new SqlCommand("sel_iteam", DBMain.con);
                }
                else
                {
                    cmd = new SqlCommand("ser_iteam", DBMain.con);
                    cmd.Parameters.AddWithValue("@data",data);
                }
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                c1.DataPropertyName = dt.Columns["Code"].ToString();
                c2.DataPropertyName = dt.Columns["Name"].ToString();
                c3.DataPropertyName = dt.Columns["Price"].ToString();
                c4.DataPropertyName = dt.Columns["Quantity"].ToString();
                c5.DataPropertyName = dt.Columns["Profit"].ToString();
                c6.DataPropertyName = dt.Columns["Expiry"].ToString();
                c8.DataPropertyName = dt.Columns["Selprice"].ToString();
                c7.DataPropertyName = dt.Columns["Id"].ToString();
                gv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        public void showreturns(Int64 saleid,DataGridView gv, DataGridViewColumn r1, DataGridViewColumn r2, DataGridViewColumn r3, DataGridViewColumn r4, DataGridViewColumn r5, DataGridViewColumn r6, DataGridViewColumn r7, DataGridViewColumn r8, DataGridViewColumn r9, DataGridViewColumn r10, DataGridViewColumn r11)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("getreturns", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("saleid", saleid);
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                r1.DataPropertyName = dt.Columns["Saleid"].ToString();
                r2.DataPropertyName = dt.Columns["Barcode"].ToString();
                r3.DataPropertyName = dt.Columns["Name"].ToString();
                r4.DataPropertyName = dt.Columns["Price"].ToString();
                r5.DataPropertyName = dt.Columns["Total"].ToString();
                r6.DataPropertyName = dt.Columns["Given"].ToString();
                r7.DataPropertyName = dt.Columns["Return"].ToString();
                r8.DataPropertyName = dt.Columns["Quantity"].ToString();
                r9.DataPropertyName = dt.Columns["Date"].ToString();
                r10.DataPropertyName = dt.Columns["TotalPerprice"].ToString();
                r11.DataPropertyName = dt.Columns["ProductID"].ToString();
                gv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        public void showsales(DateTime date,DataGridView gv, DataGridViewColumn s1, DataGridViewColumn s2, DataGridViewColumn s3, DataGridViewColumn s4, DataGridViewColumn s5)
        {
            try
            {
                SqlCommand   cmd = new SqlCommand("getdailysales", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@date", date);
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                s1.DataPropertyName = dt.Columns["Sale ID"].ToString();
                s2.DataPropertyName = dt.Columns["Total"].ToString();
                s3.DataPropertyName = dt.Columns["Given"].ToString();
                s4.DataPropertyName = dt.Columns["Return"].ToString();
                s5.DataPropertyName = dt.Columns["Refund"].ToString();
                    
                gv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        public void showStockIteams(DataGridView gv, DataGridViewColumn scode, DataGridViewColumn sname, DataGridViewColumn sqty, DataGridViewColumn sexpiry, DataGridViewColumn sprice, string data = null)
        {
            //hi
            try
            {
                SqlCommand cmd;
                if (data == null)
                {
                    cmd = new SqlCommand("stock_itm", DBMain.con);
                }
                else
                {
                    cmd = new SqlCommand("ser_stock", DBMain.con);
                    cmd.Parameters.AddWithValue("@data", data);
                }
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                scode.DataPropertyName = dt.Columns["Code"].ToString();
                sname.DataPropertyName = dt.Columns["Name"].ToString();
                //c3.DataPropertyName = dt.Columns["Price"].ToString();
                sqty.DataPropertyName = dt.Columns["Quantity"].ToString();
                //c5.DataPropertyName = dt.Columns["Profit"].ToString();
                sexpiry.DataPropertyName = dt.Columns["Expiry"].ToString();
                sprice.DataPropertyName = dt.Columns["Selprice"].ToString();
                //c7.DataPropertyName = dt.Columns["Id"].ToString();

                gv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        public void showEmptyIteams(DataGridView gv, DataGridViewColumn ecode, DataGridViewColumn ename, DataGridViewColumn eqty, DataGridViewColumn eexpiry, DataGridViewColumn eprice, string data = null)
        {
            try
            {
                SqlCommand cmd;
                if (data == null)
                {
                    cmd = new SqlCommand("emp_iteam", DBMain.con);
                }
                else
                {
                    cmd = new SqlCommand("ser_emp", DBMain.con);
                    cmd.Parameters.AddWithValue("@data", data);
                }
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                ecode.DataPropertyName = dt.Columns["Code"].ToString();
                ename.DataPropertyName = dt.Columns["Name"].ToString();
                //c3.DataPropertyName = dt.Columns["Price"].ToString();
                eqty.DataPropertyName = dt.Columns["Quantity"].ToString();
                //c5.DataPropertyName = dt.Columns["Profit"].ToString();
                eexpiry.DataPropertyName = dt.Columns["Expiry"].ToString();
                eprice.DataPropertyName = dt.Columns["Selprice"].ToString();
                //c7.DataPropertyName = dt.Columns["Id"].ToString();
                gv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private static bool checkLogin;  
           static login log = new login();

        public static bool GetDetail(string name,string password)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("sg_get", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@pass", password);
                DBMain.con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
               
                if (!dr.HasRows)
                {
                    //while(dr.Read())
                    //{
                    //    UserName = dr["Name"].ToString();
                    //    Password = dr["Password"].ToString();
                    //    user_name = dr["Name"].ToString();
                    //    pass_password = dr["Password"].ToString();
                    //    checkLogin = true;
                    //}
                    Toast.show(log, "Error", "Username or Password is incorrect", ToastType.ERROR, ToastDuration.SHORT, ToastTheme.LIGHT);

                    checkLogin = false;
                
                }
                else
                {
                    checkLogin = true;
                     }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
            return checkLogin;
        }
        public void showLoan(DataGridView gv, DataGridViewColumn g1, DataGridViewColumn g2, DataGridViewColumn g3, DataGridViewColumn g4, DataGridViewColumn g5, DataGridViewColumn g6, DataGridViewColumn g7, string data = null)
        {
            try
            {
                SqlCommand cmd;
                if (data == null)
                {
                    cmd = new SqlCommand("seldel_loan", DBMain.con);
                }
                else
                {
                    cmd = new SqlCommand("ser_iteam", DBMain.con);
                    cmd.Parameters.AddWithValue("@data", data);
                }
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                g1.DataPropertyName = dt.Columns["Name"].ToString();
                g7.DataPropertyName = dt.Columns["Id"].ToString();
                g2.DataPropertyName = dt.Columns["No"].ToString();
                g4.DataPropertyName = dt.Columns["Loan"].ToString();
                g3.DataPropertyName = dt.Columns["Title"].ToString();
                g5.DataPropertyName = dt.Columns["Give"].ToString();
                g6.DataPropertyName = dt.Columns["Remaning"].ToString();
                gv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private string[] productData = new string[4];
        public string[] getProduct(string barcode)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("get_barcode",DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@code", barcode);
                DBMain.con.Open();
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        productData[0] = rd[0].ToString();//id 
                        productData[1] = rd[1].ToString();//name
                        productData[2] = rd[2].ToString();//code
                        productData[3] = rd[3].ToString();//selling price
                    }
                }
                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
            return productData;
        } 
        
        public int getqtyfromsd(int proid)
        {
            int qty = 0;
            try
            {
                SqlCommand cmd = new SqlCommand("getqtybysaleid", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@proid", proid);
                DBMain.con.Open();
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                       qty =Convert.ToInt32(rd[0].ToString());//quantity 
                    }
                }     
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
            return qty;
        }
        private object productcount = 0;
        public object getquantity(int id)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("in_getquantity", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
               DBMain.con.Open();
                productcount = cmd.ExecuteScalar();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
            return productcount;
        } 
        public object withgetquantity(int id)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("in_getquantity", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
               //DBMain.con.Open();
                productcount = cmd.ExecuteScalar();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //DBMain.con.Close();
            }
            finally
            {
                //DBMain.con.Close();
            }
            return productcount;
        }
        ReportDocument rd;
        public void showreport(CrystalReportViewer crv,string proc)
        {
            try
            {
                SqlCommand cmd = new SqlCommand(proc, DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter ad = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                rd = new ReportDocument();
                rd.Load(Application.StartupPath+ "\\Reports\\saleReciept.rpt");
                rd.SetDataSource(dt);
                crv.ReportSource=rd;
                crv.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
       private byte[] imgg=null;
        public byte[] showimage()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("show_image", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                DBMain.con.Open();
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                         imgg = (byte[])(rd[0]);
                    }

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
            return imgg;
        }
    }
}
