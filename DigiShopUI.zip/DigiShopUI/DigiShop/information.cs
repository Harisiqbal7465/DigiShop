﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using kp.Toaster;
using System.IO;
using System.Data.SqlClient;

namespace DigiShop
{
    public partial class Information : Form
    {
        private string img;
        Insertion i = new Insertion();
        public Information()
        {
            InitializeComponent();
            //add shadow
            (new Core.DropShaddow()).ApplyShadows(this);
            //dragging the form
            bunifuFormDock1.SubscribeControlToDragEvents(panel1,true);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            //nathing
        }

        private void bunifuTextBox4_TextChanged(object sender, EventArgs e)
        {
            //nathing
        }

        private void label5_Click(object sender, EventArgs e)
        {
            //nathing
        }

        private void btntodb_Click(object sender, EventArgs e)
        {
            string s;
            string path = Environment.GetFolderPath(Environment.SpecialFolder.MyComputer);
            //got to profile
           
            if (ischeck.Checked)
            {
                if (server.Text != "" && database.Text != "")
                {
                    s = "Data Source=" + server.Text + ";Initial Catalog=" + database.Text + ";Integrated Security=true";
                    File.WriteAllText(path+"\\connect",s);
                    bunifuPages1.SetPage("user");
                }
                else
                    Toast.show(this,"Error", "Please give complate data to continue", ToastType.ERROR,ToastDuration.SHORT,ToastTheme.LIGHT);
            }
            else
            {
                if (server.Text != "" && database.Text != "" && userid.Text!="" && password.Text!="")
                {
                    s = "Data Source=" + server.Text + ";Initial Catalog=" + database.Text + ";User ID"+userid.Text+";Password"+password.Text+";";
                    File.WriteAllText(path+"\\connect", s);
                   // File.WriteAllText(Application.StartupPath + "\\Connection\\connect", s);
                    bunifuPages1.SetPage("user");
                }
                else
                    Toast.show(this, "Error", "Please give complate data to continue", ToastType.ERROR, ToastDuration.SHORT, ToastTheme.DARK);
            }
            Deletion del = new Deletion();
            del.delete_user();
        }

        private void btnbackdb_Click(object sender, EventArgs e)
        {
            //go back database information
            bunifuPages1.SetPage("database");
        }
        private void btntofinish_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(username.Text)||string.IsNullOrEmpty(pass.Text))
            {
                Toast.show(this, "Error", "Please give complate data to continue", ToastType.ERROR, ToastDuration.SHORT, ToastTheme.LIGHT);
            }
            else
            {
                byte[] imgg = null;
               
                if (!string.IsNullOrEmpty(img))
                {
                    FileStream fs = new FileStream(img, FileMode.Open, FileAccess.Read);
                    Insertion i = new Insertion();
                    BinaryReader br = new BinaryReader(fs);
                    imgg = br.ReadBytes(Convert.ToInt32(fs.Length));
                    i.InsertUser(username.Text, pass.Text, imgg);
                    //go to finish page
                    bunifuPages1.SetPage("finish");
                    ////check and enable the check box
                    //c4.Checked = c4.Enabled = true;
                    //l4.ForeColor = Color.Black;
                }
                else
                {
                    i.InsertUserwim(username.Text, pass.Text);
                    //go to finish page
                    bunifuPages1.SetPage("finish");
                    ////check and enable the check box
                    //c4.Checked = c4.Enabled = true;
                    //l4.ForeColor = Color.Black;
                }
            }
        }

        private void bunifuPages1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //update steps
            //check and enable the check boxes
            switch (bunifuPages1.SelectedIndex)
            {
                case 1:
                    c1.Checked = c1.Enabled = true;
                    l1.ForeColor = Color.Black;
                    break;
                case 2:
                    c2.Checked = c2.Enabled = true;
                    l2.ForeColor = Color.Black;
                    break;
            }
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
            //exit the application
            Application.Exit();
        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            //go to login form when click this button
            login lg = new login(); //object of login form
            lg.Show();//show login form
            this.Hide();//hide this form
        }

        private void bunifuCheckBox1_CheckedChanged(object sender, Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs e)
        {
            if (ischeck.Checked)
            {
                userid.Enabled = false;
                password.Enabled = false;
                userid.Text = "";
                password.Text = "";
            }
            else
            {
                userid.Enabled = true;
                password.Enabled = true;
            }
        }

        private void bunifuButton3_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|All Files (*.*)|*.*";
            dlg.Title = "Select Image";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                img = dlg.FileName.ToString();
                userimage.ImageLocation = img;
            }
        }

        private void Information_Load(object sender, EventArgs e)
        {
            //try
            //{
            //    SqlCommand cmd = new SqlCommand("show_image", DBMain.con);
            //    cmd.CommandType = CommandType.StoredProcedure;
            //    DBMain.con.Open();
            //    SqlDataReader rd = cmd.ExecuteReader();
            //    if (rd.HasRows)
            //    {
            //        byte[] img = (byte[])(rd[0]);
            //        if (img == null)
            //        {
            //            userimage.Image = null;
            //        }
            //        else
            //        {
            //            MemoryStream ms = new MemoryStream();
            //            userimage.Image = Image.FromStream(ms);
            //        }
            //    }


            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //finally
            //{
            //    DBMain.con.Close();
            //}
        }
    }
}
