﻿namespace DigiShop
{
    partial class Additem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Additem));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.t2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.t1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.t4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.t3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.t5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuButton2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.label6 = new System.Windows.Forms.Label();
            this.expirypicker = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.bunifuFormDock1 = new Bunifu.UI.WinForms.BunifuFormDock();
            this.label7 = new System.Windows.Forms.Label();
            this.total = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // t2
            // 
            this.t2.AcceptsReturn = false;
            this.t2.AcceptsTab = false;
            this.t2.AnimationSpeed = 200;
            this.t2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.t2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.t2.BackColor = System.Drawing.Color.Transparent;
            this.t2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("t2.BackgroundImage")));
            this.t2.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.t2.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.t2.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.t2.BorderColorIdle = System.Drawing.Color.Silver;
            this.t2.BorderRadius = 35;
            this.t2.BorderThickness = 1;
            this.t2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.t2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t2.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.t2.DefaultText = "";
            this.t2.FillColor = System.Drawing.Color.White;
            this.t2.HideSelection = true;
            this.t2.IconLeft = null;
            this.t2.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.t2.IconPadding = 10;
            this.t2.IconRight = null;
            this.t2.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.t2.Lines = new string[0];
            this.t2.Location = new System.Drawing.Point(352, 82);
            this.t2.MaxLength = 32767;
            this.t2.MinimumSize = new System.Drawing.Size(1, 1);
            this.t2.Modified = false;
            this.t2.Multiline = false;
            this.t2.Name = "t2";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t2.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t2.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t2.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t2.OnIdleState = stateProperties4;
            this.t2.PasswordChar = '\0';
            this.t2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t2.PlaceholderText = "";
            this.t2.ReadOnly = false;
            this.t2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.t2.SelectedText = "";
            this.t2.SelectionLength = 0;
            this.t2.SelectionStart = 0;
            this.t2.ShortcutsEnabled = true;
            this.t2.Size = new System.Drawing.Size(246, 35);
            this.t2.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.t2.TabIndex = 1;
            this.t2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.t2.TextMarginBottom = 0;
            this.t2.TextMarginLeft = 5;
            this.t2.TextMarginTop = 0;
            this.t2.TextPlaceholder = "";
            this.t2.UseSystemPasswordChar = false;
            this.t2.WordWrap = true;
            // 
            // t1
            // 
            this.t1.AcceptsReturn = false;
            this.t1.AcceptsTab = false;
            this.t1.AnimationSpeed = 200;
            this.t1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.t1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.t1.BackColor = System.Drawing.Color.Transparent;
            this.t1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("t1.BackgroundImage")));
            this.t1.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.t1.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.t1.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.t1.BorderColorIdle = System.Drawing.Color.Silver;
            this.t1.BorderRadius = 35;
            this.t1.BorderThickness = 1;
            this.t1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.t1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t1.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.t1.DefaultText = "";
            this.t1.FillColor = System.Drawing.Color.White;
            this.t1.HideSelection = true;
            this.t1.IconLeft = null;
            this.t1.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.t1.IconPadding = 10;
            this.t1.IconRight = null;
            this.t1.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.t1.Lines = new string[0];
            this.t1.Location = new System.Drawing.Point(47, 82);
            this.t1.MaxLength = 32767;
            this.t1.MinimumSize = new System.Drawing.Size(1, 1);
            this.t1.Modified = false;
            this.t1.Multiline = false;
            this.t1.Name = "t1";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t1.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t1.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t1.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t1.OnIdleState = stateProperties8;
            this.t1.PasswordChar = '\0';
            this.t1.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t1.PlaceholderText = "";
            this.t1.ReadOnly = false;
            this.t1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.t1.SelectedText = "";
            this.t1.SelectionLength = 0;
            this.t1.SelectionStart = 0;
            this.t1.ShortcutsEnabled = true;
            this.t1.Size = new System.Drawing.Size(246, 35);
            this.t1.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.t1.TabIndex = 0;
            this.t1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.t1.TextMarginBottom = 0;
            this.t1.TextMarginLeft = 5;
            this.t1.TextMarginTop = 0;
            this.t1.TextPlaceholder = "";
            this.t1.UseSystemPasswordChar = false;
            this.t1.WordWrap = true;
            // 
            // t4
            // 
            this.t4.AcceptsReturn = false;
            this.t4.AcceptsTab = false;
            this.t4.AnimationSpeed = 200;
            this.t4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.t4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.t4.BackColor = System.Drawing.Color.Transparent;
            this.t4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("t4.BackgroundImage")));
            this.t4.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.t4.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.t4.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.t4.BorderColorIdle = System.Drawing.Color.Silver;
            this.t4.BorderRadius = 35;
            this.t4.BorderThickness = 1;
            this.t4.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.t4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t4.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.t4.DefaultText = "";
            this.t4.FillColor = System.Drawing.Color.White;
            this.t4.HideSelection = true;
            this.t4.IconLeft = null;
            this.t4.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.t4.IconPadding = 10;
            this.t4.IconRight = null;
            this.t4.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.t4.Lines = new string[0];
            this.t4.Location = new System.Drawing.Point(352, 160);
            this.t4.MaxLength = 32767;
            this.t4.MinimumSize = new System.Drawing.Size(1, 1);
            this.t4.Modified = false;
            this.t4.Multiline = false;
            this.t4.Name = "t4";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t4.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Empty;
            stateProperties10.FillColor = System.Drawing.Color.White;
            stateProperties10.ForeColor = System.Drawing.Color.Empty;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t4.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t4.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t4.OnIdleState = stateProperties12;
            this.t4.PasswordChar = '\0';
            this.t4.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t4.PlaceholderText = "";
            this.t4.ReadOnly = false;
            this.t4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.t4.SelectedText = "";
            this.t4.SelectionLength = 0;
            this.t4.SelectionStart = 0;
            this.t4.ShortcutsEnabled = true;
            this.t4.Size = new System.Drawing.Size(246, 35);
            this.t4.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.t4.TabIndex = 2;
            this.t4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.t4.TextMarginBottom = 0;
            this.t4.TextMarginLeft = 5;
            this.t4.TextMarginTop = 0;
            this.t4.TextPlaceholder = "";
            this.t4.UseSystemPasswordChar = false;
            this.t4.WordWrap = true;
            // 
            // t3
            // 
            this.t3.AcceptsReturn = false;
            this.t3.AcceptsTab = false;
            this.t3.AnimationSpeed = 200;
            this.t3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.t3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.t3.BackColor = System.Drawing.Color.Transparent;
            this.t3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("t3.BackgroundImage")));
            this.t3.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.t3.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.t3.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.t3.BorderColorIdle = System.Drawing.Color.Silver;
            this.t3.BorderRadius = 35;
            this.t3.BorderThickness = 1;
            this.t3.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.t3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t3.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.t3.DefaultText = "";
            this.t3.FillColor = System.Drawing.Color.White;
            this.t3.HideSelection = true;
            this.t3.IconLeft = null;
            this.t3.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.t3.IconPadding = 10;
            this.t3.IconRight = null;
            this.t3.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.t3.Lines = new string[0];
            this.t3.Location = new System.Drawing.Point(47, 160);
            this.t3.MaxLength = 32767;
            this.t3.MinimumSize = new System.Drawing.Size(1, 1);
            this.t3.Modified = false;
            this.t3.Multiline = false;
            this.t3.Name = "t3";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t3.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.Empty;
            stateProperties14.FillColor = System.Drawing.Color.White;
            stateProperties14.ForeColor = System.Drawing.Color.Empty;
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t3.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t3.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t3.OnIdleState = stateProperties16;
            this.t3.PasswordChar = '\0';
            this.t3.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t3.PlaceholderText = "";
            this.t3.ReadOnly = false;
            this.t3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.t3.SelectedText = "";
            this.t3.SelectionLength = 0;
            this.t3.SelectionStart = 0;
            this.t3.ShortcutsEnabled = true;
            this.t3.Size = new System.Drawing.Size(246, 35);
            this.t3.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.t3.TabIndex = 3;
            this.t3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.t3.TextMarginBottom = 0;
            this.t3.TextMarginLeft = 5;
            this.t3.TextMarginTop = 0;
            this.t3.TextPlaceholder = "";
            this.t3.UseSystemPasswordChar = false;
            this.t3.WordWrap = true;
            // 
            // t5
            // 
            this.t5.AcceptsReturn = false;
            this.t5.AcceptsTab = false;
            this.t5.AnimationSpeed = 200;
            this.t5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.t5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.t5.BackColor = System.Drawing.Color.Transparent;
            this.t5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("t5.BackgroundImage")));
            this.t5.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.t5.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.t5.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.t5.BorderColorIdle = System.Drawing.Color.Silver;
            this.t5.BorderRadius = 35;
            this.t5.BorderThickness = 1;
            this.t5.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.t5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t5.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.t5.DefaultText = "";
            this.t5.FillColor = System.Drawing.Color.White;
            this.t5.HideSelection = true;
            this.t5.IconLeft = null;
            this.t5.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.t5.IconPadding = 10;
            this.t5.IconRight = null;
            this.t5.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.t5.Lines = new string[0];
            this.t5.Location = new System.Drawing.Point(47, 242);
            this.t5.MaxLength = 32767;
            this.t5.MinimumSize = new System.Drawing.Size(1, 1);
            this.t5.Modified = false;
            this.t5.Multiline = false;
            this.t5.Name = "t5";
            stateProperties17.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t5.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.Empty;
            stateProperties18.FillColor = System.Drawing.Color.White;
            stateProperties18.ForeColor = System.Drawing.Color.Empty;
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t5.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t5.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.Silver;
            stateProperties20.FillColor = System.Drawing.Color.White;
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t5.OnIdleState = stateProperties20;
            this.t5.PasswordChar = '\0';
            this.t5.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t5.PlaceholderText = "";
            this.t5.ReadOnly = false;
            this.t5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.t5.SelectedText = "";
            this.t5.SelectionLength = 0;
            this.t5.SelectionStart = 0;
            this.t5.ShortcutsEnabled = true;
            this.t5.Size = new System.Drawing.Size(246, 35);
            this.t5.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.t5.TabIndex = 4;
            this.t5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.t5.TextMarginBottom = 0;
            this.t5.TextMarginLeft = 5;
            this.t5.TextMarginTop = 0;
            this.t5.TextPlaceholder = "";
            this.t5.UseSystemPasswordChar = false;
            this.t5.WordWrap = true;
            this.t5.TextChanged += new System.EventHandler(this.t5_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(61, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(368, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Product Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(368, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Quantity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(61, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Profit";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(61, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Price";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bunifuButton2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(684, 35);
            this.panel1.TabIndex = 6;
            // 
            // bunifuButton2
            // 
            this.bunifuButton2.AllowToggling = false;
            this.bunifuButton2.AnimationSpeed = 200;
            this.bunifuButton2.AutoGenerateColors = false;
            this.bunifuButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton2.BackColor1 = System.Drawing.Color.White;
            this.bunifuButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.BackgroundImage")));
            this.bunifuButton2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.ButtonText = "";
            this.bunifuButton2.ButtonTextMarginLeft = 0;
            this.bunifuButton2.ColorContrastOnClick = 45;
            this.bunifuButton2.ColorContrastOnHover = 45;
            this.bunifuButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.bunifuButton2.CustomizableEdges = borderEdges1;
            this.bunifuButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton2.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton2.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton2.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton2.Dock = System.Windows.Forms.DockStyle.Right;
            this.bunifuButton2.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IconMarginLeft = 11;
            this.bunifuButton2.IconPadding = 10;
            this.bunifuButton2.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IdleBorderColor = System.Drawing.Color.White;
            this.bunifuButton2.IdleBorderRadius = 3;
            this.bunifuButton2.IdleBorderThickness = 1;
            this.bunifuButton2.IdleFillColor = System.Drawing.Color.White;
            this.bunifuButton2.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.IdleIconLeftImage")));
            this.bunifuButton2.IdleIconRightImage = null;
            this.bunifuButton2.IndicateFocus = false;
            this.bunifuButton2.Location = new System.Drawing.Point(648, 0);
            this.bunifuButton2.Name = "bunifuButton2";
            this.bunifuButton2.onHoverState.BorderColor = System.Drawing.Color.Gray;
            this.bunifuButton2.onHoverState.BorderRadius = 3;
            this.bunifuButton2.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.onHoverState.BorderThickness = 1;
            this.bunifuButton2.onHoverState.FillColor = System.Drawing.Color.Gray;
            this.bunifuButton2.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.onHoverState.IconLeftImage = null;
            this.bunifuButton2.onHoverState.IconRightImage = null;
            this.bunifuButton2.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.bunifuButton2.OnIdleState.BorderRadius = 3;
            this.bunifuButton2.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.OnIdleState.BorderThickness = 1;
            this.bunifuButton2.OnIdleState.FillColor = System.Drawing.Color.White;
            this.bunifuButton2.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.OnIdleState.IconLeftImage")));
            this.bunifuButton2.OnIdleState.IconRightImage = null;
            this.bunifuButton2.OnPressedState.BorderColor = System.Drawing.Color.Gray;
            this.bunifuButton2.OnPressedState.BorderRadius = 3;
            this.bunifuButton2.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.OnPressedState.BorderThickness = 1;
            this.bunifuButton2.OnPressedState.FillColor = System.Drawing.Color.Gray;
            this.bunifuButton2.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.OnPressedState.IconLeftImage = null;
            this.bunifuButton2.OnPressedState.IconRightImage = null;
            this.bunifuButton2.Size = new System.Drawing.Size(36, 35);
            this.bunifuButton2.TabIndex = 8;
            this.bunifuButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton2.TextMarginLeft = 0;
            this.bunifuButton2.UseDefaultRadiusAndThickness = true;
            this.bunifuButton2.Click += new System.EventHandler(this.bunifuButton2_Click);
            // 
            // btn
            // 
            this.btn.AllowToggling = false;
            this.btn.AnimationSpeed = 200;
            this.btn.AutoGenerateColors = false;
            this.btn.BackColor = System.Drawing.Color.Transparent;
            this.btn.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn.BackgroundImage")));
            this.btn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn.ButtonText = "Done";
            this.btn.ButtonTextMarginLeft = 0;
            this.btn.ColorContrastOnClick = 45;
            this.btn.ColorContrastOnHover = 45;
            this.btn.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btn.CustomizableEdges = borderEdges2;
            this.btn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btn.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btn.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.btn.ForeColor = System.Drawing.Color.White;
            this.btn.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.btn.IconMarginLeft = 11;
            this.btn.IconPadding = 10;
            this.btn.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.btn.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btn.IdleBorderRadius = 35;
            this.btn.IdleBorderThickness = 1;
            this.btn.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btn.IdleIconLeftImage = null;
            this.btn.IdleIconRightImage = null;
            this.btn.IndicateFocus = false;
            this.btn.Location = new System.Drawing.Point(455, 331);
            this.btn.Name = "btn";
            this.btn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btn.onHoverState.BorderRadius = 35;
            this.btn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn.onHoverState.BorderThickness = 1;
            this.btn.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btn.onHoverState.IconLeftImage = null;
            this.btn.onHoverState.IconRightImage = null;
            this.btn.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btn.OnIdleState.BorderRadius = 35;
            this.btn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn.OnIdleState.BorderThickness = 1;
            this.btn.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btn.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btn.OnIdleState.IconLeftImage = null;
            this.btn.OnIdleState.IconRightImage = null;
            this.btn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btn.OnPressedState.BorderRadius = 35;
            this.btn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btn.OnPressedState.BorderThickness = 1;
            this.btn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btn.OnPressedState.IconLeftImage = null;
            this.btn.OnPressedState.IconRightImage = null;
            this.btn.Size = new System.Drawing.Size(143, 38);
            this.btn.TabIndex = 7;
            this.btn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn.TextMarginLeft = 0;
            this.btn.UseDefaultRadiusAndThickness = true;
            this.btn.Click += new System.EventHandler(this.btn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(368, 223);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Expiry";
            // 
            // expirypicker
            // 
            this.expirypicker.BorderRadius = 13;
            this.expirypicker.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.expirypicker.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thick;
            this.expirypicker.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.expirypicker.DisabledColor = System.Drawing.Color.Gray;
            this.expirypicker.DisplayWeekNumbers = false;
            this.expirypicker.DPHeight = 0;
            this.expirypicker.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.expirypicker.FillDatePicker = false;
            this.expirypicker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.expirypicker.Icon = ((System.Drawing.Image)(resources.GetObject("expirypicker.Icon")));
            this.expirypicker.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.expirypicker.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.expirypicker.Location = new System.Drawing.Point(352, 242);
            this.expirypicker.MinimumSize = new System.Drawing.Size(246, 35);
            this.expirypicker.Name = "expirypicker";
            this.expirypicker.Size = new System.Drawing.Size(246, 35);
            this.expirypicker.TabIndex = 8;
            // 
            // bunifuFormDock1
            // 
            this.bunifuFormDock1.AllowFormDragging = false;
            this.bunifuFormDock1.AllowFormDropShadow = true;
            this.bunifuFormDock1.AllowFormResizing = false;
            this.bunifuFormDock1.AllowHidingBottomRegion = true;
            this.bunifuFormDock1.AllowOpacityChangesWhileDragging = false;
            this.bunifuFormDock1.BorderOptions.BottomBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.BottomBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.BottomBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.LeftBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.LeftBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.LeftBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.RightBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.RightBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.RightBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.TopBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.TopBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.TopBorder.ShowBorder = true;
            this.bunifuFormDock1.ContainerControl = this;
            this.bunifuFormDock1.DockingIndicatorsColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(215)))), ((int)(((byte)(233)))));
            this.bunifuFormDock1.DockingIndicatorsOpacity = 0.5D;
            this.bunifuFormDock1.DockingOptions.DockAll = true;
            this.bunifuFormDock1.DockingOptions.DockBottomLeft = true;
            this.bunifuFormDock1.DockingOptions.DockBottomRight = true;
            this.bunifuFormDock1.DockingOptions.DockFullScreen = true;
            this.bunifuFormDock1.DockingOptions.DockLeft = true;
            this.bunifuFormDock1.DockingOptions.DockRight = true;
            this.bunifuFormDock1.DockingOptions.DockTopLeft = true;
            this.bunifuFormDock1.DockingOptions.DockTopRight = true;
            this.bunifuFormDock1.FormDraggingOpacity = 0.9D;
            this.bunifuFormDock1.ParentForm = this;
            this.bunifuFormDock1.ShowCursorChanges = false;
            this.bunifuFormDock1.ShowDockingIndicators = false;
            this.bunifuFormDock1.TitleBarOptions.AllowFormDragging = true;
            this.bunifuFormDock1.TitleBarOptions.BunifuFormDock = this.bunifuFormDock1;
            this.bunifuFormDock1.TitleBarOptions.DoubleClickToExpandWindow = true;
            this.bunifuFormDock1.TitleBarOptions.TitleBarControl = null;
            this.bunifuFormDock1.TitleBarOptions.UseBackColorOnDockingIndicators = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(44, 331);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 31);
            this.label7.TabIndex = 9;
            this.label7.Text = "Sel Price";
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total.Location = new System.Drawing.Point(169, 341);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(66, 18);
            this.total.TabIndex = 5;
            this.total.Text = "00.0000";
            // 
            // Additem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.ClientSize = new System.Drawing.Size(684, 514);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.expirypicker);
            this.Controls.Add(this.btn);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.total);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.t5);
            this.Controls.Add(this.t3);
            this.Controls.Add(this.t4);
            this.Controls.Add(this.t2);
            this.Controls.Add(this.t1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Additem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "additeam";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btn;
        public Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox t1;
        public Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox t2;
        public Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox t4;
        public Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox t3;
        public Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox t5;
        private System.Windows.Forms.Label label6;
        private Bunifu.UI.WinForms.BunifuDatePicker expirypicker;
        private Bunifu.UI.WinForms.BunifuFormDock bunifuFormDock1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label total;
    }
}