﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using kp.Toaster;

namespace DigiShop
{
    public partial class Form1 : Form
    {
        private int rowIndex = 0;
        Selection s = new Selection();
        Updation u = new Updation();
        Regex qty = new Regex("^[0-9]*[1-9][0-9]*$");//qty
        Regex digit = new Regex("^[0-9]+$");
        Regex moneyy = new Regex(@"^[0-9]*(?:\.[0-9]*)?$");//
        Regex alphabets = new Regex(@"^[\p{L}]+$");
        public Form1()
        {
            InitializeComponent();
            (new Core.DropShaddow()).ApplyShadows(this);
            //bunifuFormDock1.SubscribeControlToDragEvents(navigation,true);
            //s.showIteams(dataGridView1, c1, c2, c3, c4, c5, c6, c7);
        }
        void CalculateSelPrice()
        {
            //if (!string.IsNullOrEmpty(t5.Text))
            //{
            float profit = Convert.ToSingle(t5.Text);//for profit //convert string into float
            float money = Convert.ToSingle(t3.Text);//for price //convert string into float
            profit = (100 + profit) / 100;
            money = profit * money;
            total.Text = Convert.ToString(money);//convert float into string

        }
        void SelPrice()
        {
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                //float price = Convert.ToSingle(dataGridView1.);
            }
        }
        void MoveIndicator(Control control)
        {
            indicator.Top = control.Top;
            indicator.Height = control.Height;
        }
        void LeftIndicator(Control lft)
        {

            indicator1.Left = lft.Left;
            indicator1.Width = lft.Width;
        }
        void LeftIndicator3(Control lft3)
        {

            indicator3.Left = lft3.Left;
            indicator3.Width = lft3.Width;
        }
        void LeftIndicator4(Control lft3)
        {

            //indicator4.Left = lft3.Left;
            //indicator4.Width = lft3.Width;
        }

        private void menu_Click(object sender, EventArgs e)
        {
            if (slide.Width == 180)
            {
                slide.Width = 50;
                slide.Visible = true;
                invoice.Text = "";
                inventroy.Text = "";
                report.Text = "";
                stock.Text = "";
                payment.Text = "";
                setting.Text = "";
            }
            else
            {
                slide.Width = 180;
                slide.Visible = true;
                invoice.Text = "    Invoice";
                inventroy.Text = "    Inventory";
                report.Text = "    Report";
                stock.Text = "    Stock";
                payment.Text = "    Payment";
                setting.Text = "    Setting";
            }
        }

        private void invoice_Click(object sender, EventArgs e)
        {
            MoveIndicator((Control)sender);
            bunifuPages1.SetPage("invoice");
        }

        private void inventroy_Click(object sender, EventArgs e)
        {
            MoveIndicator((Control)sender);
            bunifuPages1.SetPage("inventroy");
        }

        private void report_Click(object sender, EventArgs e)
        {
            MoveIndicator((Control)sender);
            bunifuPages1.SetPage("report");
        }

        private void stock_Click(object sender, EventArgs e)
        {
            MoveIndicator((Control)sender);
            bunifuPages1.SetPage("stock");
        }

        private void payment_Click(object sender, EventArgs e)
        {
            MoveIndicator((Control)sender);
            bunifuPages1.SetPage("payment");
        }

        private void setting_Click(object sender, EventArgs e)
        {
            MoveIndicator((Control)sender);
            bunifuPages1.SetPage("setting");
        }

        private void close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void maxnormal_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
                WindowState = FormWindowState.Maximized;
            else
                WindowState = FormWindowState.Normal;
        }

        private void minimum_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void addbtn_Click(object sender, EventArgs e)
        {
            //Additem add = new Additem();
            //add.Show();
            bunifuPages1.SetPage("additeam");
            t1.Text = "";
            t2.Text = "";
            t3.Text = "";
            t4.Text = "";
            t5.Text = "";
            qtyerror.Visible = false;
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView1.CurrentRow != null)
                {
                    DBMain.con.Open();
                    DataGridViewRow dgvRow = dataGridView1.CurrentRow;
                    SqlCommand cmd = new SqlCommand("up_iteam", DBMain.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@itmID", Convert.ToInt32(dgvRow.Cells["c7"].Value == DBNull.Value ? "" : dgvRow.Cells["c7"].Value.ToString()));
                    cmd.Parameters.AddWithValue("@code", dgvRow.Cells["c1"].Value == DBNull.Value ? "" : dgvRow.Cells["c1"].Value.ToString());
                    cmd.Parameters.AddWithValue("@name", dgvRow.Cells["c2"].Value == DBNull.Value ? "" : dgvRow.Cells["c2"].Value.ToString());
                    cmd.Parameters.AddWithValue("@price", Convert.ToSingle(dgvRow.Cells["c3"].Value == DBNull.Value ? "" : dgvRow.Cells["c3"].Value.ToString()));
                    cmd.Parameters.AddWithValue("@qty", Convert.ToInt32(dgvRow.Cells["c4"].Value == DBNull.Value ? "" : dgvRow.Cells["c4"].Value.ToString()));
                    cmd.Parameters.AddWithValue("@profit", Convert.ToSingle(dgvRow.Cells["c5"].Value == DBNull.Value ? "" : dgvRow.Cells["c5"].Value.ToString()));
                    cmd.Parameters.AddWithValue("@expiry", dgvRow.Cells["c6"].Value == DBNull.Value ? "" : dgvRow.Cells["c6"].Value.ToString());
                    cmd.ExecuteNonQuery();
                    s.showIteams(dataGridView1, c1, c2, c3, c4, c5, c6, c7, c8);
                }
            }
            catch (Exception ex)
            {
                //Toast.show(this, "error", ex.Message, ToastType.ERROR, ToastDuration.SHORT);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
        }

        private void btn_Click(object sender, EventArgs e)
        {
            //DataGridViewRow dgvRow = dataGridView1.CurrentRow;
            //dgvRow.Cells["c1"].
            s.showIteams(dataGridView1, c1, c2, c3, c4, c5, c6, c7, c8);
        }

        private void searchiteam_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(searchiteam.Text))
            {
                s.showIteams(dataGridView1, c1, c2, c3, c4, c5, c6, c7, c8, searchiteam.Text);
            }
            else
            {
                s.showIteams(dataGridView1, c1, c2, c3, c4, c5, c6, c7, c8);
            }
        }

        private void btnreport_Click(object sender, EventArgs e)
        {
            LeftIndicator((Control)sender);//indicator left
            bunifuPages2.SetPage("report");
        }

        private void returnreport_Click(object sender, EventArgs e)
        {
            LeftIndicator((Control)sender);
            bunifuPages2.SetPage("return");
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            bunifuPages2.SetPage("user");
        }

        private void t5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(t5.Text))
            {
                if (moneyy.Match(t5.Text).Success)
                {
                    if (!string.IsNullOrEmpty(t3.Text)) {
                        double profit = Convert.ToSingle(t5.Text);//for profit //convert string into float
                        double money = Convert.ToSingle(t3.Text);//for price //convert string into float
                        profit = (100.0 + profit) / 100;
                        money = profit * money;
                        total.Text = Convert.ToString(money);//convert float into string
                                                             //CalculateSelPrice();
                        profiterror.Visible = false;
                    }
                    else
                    {
                        profiterror.Text = "Fisrt input the price";
                        profiterror.Visible = true;
                        t5.SelectAll();
                    }
                    
                }
                else
                {
                    profiterror.Visible = true;
                    t5.SelectAll();
                }
            }
            else
            {
                profiterror.Visible = false;
                total.Text = "00.0000";//if profit text box is emply it show
            }
        }

        private void t3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(t3.Text))
            {

                if (moneyy.Match(t3.Text).Success)
                {
                    priceerror.Visible = false;
                    total.Text = Convert.ToString(t3.Text);//convert float into string
                }
                else
                {
                    priceerror.Visible = true;
                    t3.SelectAll();
                }
            }
            else
            {
                priceerror.Visible = false;
                total.Text = "00.0000";
            }

        }

        private void bunifuButton6_Click(object sender, EventArgs e)
        {
            Insertion i = new Insertion(); //insert data into sql server (insertion is globel class) 
            i.add_iteam(t2.Text, t1.Text, Convert.ToSingle(t3.Text), expirypicker.Value, Convert.ToInt32(t4.Text), Convert.ToSingle(t5.Text), Convert.ToSingle(total.Text));//call insertion method for insert data 
            t1.Text = "";
            t2.Text = "";
            t3.Text = "";
            t4.Text = "";
            t5.Text = "";
            qtyerror.Visible = false;
        }

        private void back_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage("inventroy");
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

        }

        private void stkbtn_Click(object sender, EventArgs e)
        {
            s.showStockIteams(dataGridView3, scode, sname, sqty, sdue, sprice);
        }

        private void stcksearch_TextChanged(object sender, EventArgs e)
        {
            //hi
            if (!string.IsNullOrEmpty(stcksearch.Text))
            {
                s.showStockIteams(dataGridView3, scode, sname, sqty, sdue, sprice, stcksearch.Text);
            }
            else
            {
                s.showStockIteams(dataGridView3, scode, sname, sqty, sdue, sprice);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void empty_Click(object sender, EventArgs e)
        {
            s.showEmptyIteams(dataGridView2, ecode, ename, eqty, edue, eprice);
        }

        private void bunifuButton7_Click(object sender, EventArgs e)
        {
            bunifuPages4.SetPage("stockava");
            LeftIndicator3((Control)sender);
        }

        private void btnemp_Click(object sender, EventArgs e)
        {
            bunifuPages4.SetPage("empty");
            LeftIndicator3((Control)sender);
        }

        private void searchempty_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(searchempty.Text))
            {
                s.showEmptyIteams(dataGridView2, ecode, ename, eqty, edue, eprice, searchempty.Text);
            }
            else
            {
                s.showEmptyIteams(dataGridView2, ecode, ename, eqty, edue, eprice);
            }
        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!this.dataGridView1.Rows[this.rowIndex].IsNewRow) //datagridview1
                {

                    if (dataGridView1.CurrentRow != null)
                    {
                        DBMain.con.Open();
                        DataGridViewRow dgvRow = dataGridView1.CurrentRow;
                        SqlCommand cmd = new SqlCommand("delete_iteam", DBMain.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgvRow.Cells["c7"].Value));
                        cmd.ExecuteNonQuery();
                        DBMain.con.Close();
                        this.dataGridView1.Rows.RemoveAt(this.rowIndex);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage("inventroy");
        }

        private void dataGridView1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.dataGridView1.Rows[e.RowIndex].Selected = true;
                this.rowIndex = e.RowIndex;
                this.dataGridView1.CurrentCell = this.dataGridView1.Rows[e.RowIndex].Cells[1];
                this.contextMenuStrip1.Show(this.dataGridView1, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void givebtn_Click(object sender, EventArgs e)
        {
            LeftIndicator4((Control)sender);
            bunifuPages5.SetPage("give");
        }

        private void takebtn_Click(object sender, EventArgs e)
        {
            LeftIndicator4((Control)sender);
            bunifuPages5.SetPage("take");
        }

        private void tabPage17_Click(object sender, EventArgs e)
        {

        }

        private void bunifuButton9_Click(object sender, EventArgs e)
        {
            Insertion i = new Insertion(); //insert data into sql server (insertion is globel class) 
            i.add_giveMoney(gt1.Text, gt3.Text, Convert.ToSingle(gt5.Text), Convert.ToSingle(remaning.Text), Convert.ToSingle(gt4.Text), Convert.ToInt64(gt2.Text));
            gt1.Text = "";
            gt2.Text = "";
            gt3.Text = "";
            gt4.Text = "";
            gt5.Text = "";
        }

        private void gt5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(gt5.Text))
            {
                if (moneyy.Match(gt5.Text).Success)
                {
                    if (!string.IsNullOrEmpty(gt5.Text)) {
                        giveerror.Visible = false;
                        float a = Convert.ToSingle(gt4.Text);
                        float b = Convert.ToSingle(gt5.Text);
                        float reman = a - b;
                        remaning.Text = Convert.ToString(reman);
                    }
                    else
                    {
                        giveerror.Text = "Fisrt input the Loan";
                        giveerror.Visible = true;
                        gt5.SelectAll();
                    }
                   
                }
                else
                {
                    giveerror.Visible = true;
                    gt5.SelectAll();
                }

            }
            else
            {
                giveerror.Visible = false;
                total.Text = "00.0000";//if profit text box is emply it show
            }
        }

        private void gt4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(gt4.Text))
            {
                if (moneyy.Match(gt4.Text).Success)
                {
                    loanerror.Visible = false;
                    remaning.Text = gt4.Text;
                }
                else
                {
                    loanerror.Visible = true;
                    gt4.SelectAll();
                }
            }
            else
            {
                loanerror.Visible = false;
                remaning.Text = "00.0000";
            }

        }

        private void gt3_TextChanged(object sender, EventArgs e)
        {

        }

        private void addloan_Click(object sender, EventArgs e)
        {
            bunifuPages5.SetPage("add_give");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            bunifuPages5.SetPage("give");
        }

        private void loanrefresh_Click(object sender, EventArgs e)
        {
            s.showLoan(dataGridView4, g1, g2, g3, g4, g5, g6, g7);
        }

        private void bunifuPictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void t4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(t4.Text))
            {

                if (qty.Match(t4.Text).Success)
                {
                    qtyerror.Visible = true;
                    qtyerror.Text = "Good";
                    qtyerror.ForeColor = Color.Green;

                }
                else
                {
                    qtyerror.Text = "Intput Digits example(01234...)";
                    qtyerror.ForeColor = Color.Red;
                    qtyerror.Visible = true;
                    t4.SelectAll();
                }
            }
            else
                qtyerror.Visible = false;

        }

        private void gt2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(gt2.Text))
            {

                if (digit.Match(gt2.Text).Success)
                {
                    noerror.Visible = true;
                    noerror.Text = "Good";
                    noerror.ForeColor = Color.Green;

                }
                else
                {
                    noerror.Text = "Intput Digits example(01234...)";
                    noerror.ForeColor = Color.Red;
                    noerror.Visible = true;
                    gt2.SelectAll();
                }
            }
            else
                noerror.Visible = false;
        }

        private void bunifuButton10_Click(object sender, EventArgs e)
        {
            if (cb1.Checked == true)
            {
                ut1.Text = "Hi";
            }
            else 
            {
                byte[] imgg = null;
                if (!string.IsNullOrEmpty(img))
                {
                    FileStream fs = new FileStream(img, FileMode.Open, FileAccess.Read);
                    Insertion i = new Insertion();
                    BinaryReader br = new BinaryReader(fs);
                    imgg = br.ReadBytes(Convert.ToInt32(fs.Length));
                    Updation u = new Updation();
                    u.Update_user(ut1.Text, ut2.Text, imgg);
                    ut1.Text = "";
                    ut2.Text = "";
                }
                else
                {
                    Updation u = new Updation();
                    u.Update_userwithoutimage(ut1.Text, ut2.Text);
                    ut1.Text = "";
                    ut2.Text = "";
                }
                byte[] image = s.showimage();
                if (image == null)
                {
                    userimage.Image = null;
                }
                else
                {
                    MemoryStream ms = new MemoryStream(image);
                    userimage.Image = Image.FromStream(ms);
                    circularpicture1.Image = Image.FromStream(ms);
                }

            }


        }

        private void barcode_TextChanged(object sender, EventArgs e)
        {

        }
        //int productid;
        string[] prodARR = new string[4];
        //int quan;
        float totall, gross;

        private void dataGridView4_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView4.CurrentRow != null)
                {
                    DBMain.con.Open();
                    DataGridViewRow dgvRow = dataGridView4.CurrentRow;
                    SqlCommand cmd = new SqlCommand("up_loan", DBMain.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgvRow.Cells["g7"].Value == DBNull.Value ? "" : dgvRow.Cells["g7"].Value.ToString()));
                    cmd.Parameters.AddWithValue("@name", dgvRow.Cells["g1"].Value == DBNull.Value ? "" : dgvRow.Cells["g1"].Value.ToString());
                    cmd.Parameters.AddWithValue("@no", Convert.ToInt64(dgvRow.Cells["g2"].Value == DBNull.Value ? "" : dgvRow.Cells["g2"].Value.ToString()));
                    cmd.Parameters.AddWithValue("@give", Convert.ToSingle(dgvRow.Cells["g5"].Value == DBNull.Value ? "" : dgvRow.Cells["g5"].Value.ToString()));
                    cmd.Parameters.AddWithValue("@loan", Convert.ToSingle(dgvRow.Cells["g4"].Value == DBNull.Value ? "" : dgvRow.Cells["g4"].Value.ToString()));
                    cmd.Parameters.AddWithValue("@remaining", Convert.ToSingle(dgvRow.Cells["g6"].Value == DBNull.Value ? "" : dgvRow.Cells["g6"].Value.ToString()));
                    cmd.Parameters.AddWithValue("@title", dgvRow.Cells["g3"].Value == DBNull.Value ? "" : dgvRow.Cells["g3"].Value.ToString());
                    cmd.ExecuteNonQuery();
                    s.showLoan(dataGridView4, g1, g2, g3, g4, g5, g6, g7);
                }
            }
            catch (Exception ex)
            {
                //Toast.show(this, "error", ex.Message, ToastType.ERROR, ToastDuration.SHORT);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {

        }
        bool checkpro;

        private void dataGridView4_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.dataGridView4.Rows[e.RowIndex].Selected = true;
                this.rowIndex = e.RowIndex;
                this.dataGridView4.CurrentCell = this.dataGridView4.Rows[e.RowIndex].Cells[1];
                this.contextMenuStrip2.Show(this.dataGridView4, e.Location);
                contextMenuStrip2.Show(Cursor.Position);
            }
        }

        private void dataGridView5_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            float gt,tot;
            if (e.RowIndex != -1 && e.ColumnIndex != -1)
            {
                if (e.ColumnIndex == 5)
                {
                    DataGridViewRow row = dataGridView5.Rows[e.RowIndex];
                    int q = Convert.ToInt32(row.Cells["iquantity"].Value.ToString());
                    if (q == 1)
                    {
                        gt = Convert.ToSingle(grosstotal.Text);
                        gt = gt - Convert.ToSingle(row.Cells["itotal"].Value.ToString());
                        grosstotal.Text = gt.ToString();
                        dataGridView5.Rows.Remove(row);
                    }
                    else if (q > 1)
                    {
                        q--;
                        gt = Convert.ToSingle(grosstotal.Text);
                        tot = Convert.ToSingle(row.Cells["itotal"].Value.ToString()) - Convert.ToSingle(row.Cells["iprice"].Value.ToString());
                        row.Cells["itotal"].Value = tot;
                        gt = gt - Convert.ToSingle(row.Cells["iprice"].Value.ToString());
                        grosstotal.Text = gt.ToString();
                        row.Cells["iquantity"].Value = q;
                    }
                }
            }
        }

        private void bunifuButton8_Click(object sender, EventArgs e)
        {
            
        }

        private void checkbtn_Click(object sender, EventArgs e)
        {
            if (dataGridView5.Rows.Count >0)
            {
                float gro=0;
                foreach(DataGridViewRow row in dataGridView5.Rows)
                {
                    gro += Convert.ToSingle(row.Cells["itotal"].Value.ToString()); 
                }
                totaltxt.Text = gro.ToString();
            }
        }

        private void giventext_TextChanged(object sender, EventArgs e)
        {
            if (!moneyy.Match(giventext.Text).Success)
            {
                gerror.Visible = true;
                giventext.SelectAll();
            }
            else
            {
               
                if (giventext.Text != "")
                {
                    float ammountgiven = Convert.ToSingle(giventext.Text);
                    float returnAmmount = ammountgiven - Convert.ToSingle(grosstotal.Text);
                    changetxt.Text = returnAmmount.ToString();
                }
                else
                {
                    gerror.Visible = false;
                    changetxt.Text = "";
                }
                
            }
        }

        private void giventext_Validating(object sender, CancelEventArgs e)
        {
            if(giventext.Text!="" && grosstotal.Text != "")
            {
                if (!(Convert.ToSingle(grosstotal.Text) <= Convert.ToSingle(giventext.Text)))
                {
                    giventext.Text = "";
                    giventext.Focus();
                }
            }
        }
        Insertion i = new Insertion();
        private void paybtn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(grosstotal.Text) && !string.IsNullOrEmpty(totaltxt.Text) && !string.IsNullOrEmpty(giventext.Text) && !string.IsNullOrEmpty(changetxt.Text))
            {
                DialogResult dr = MessageBox.Show("\n\n\tTotal Ammount : " + grosstotal.Text + "\n\tGiven Ammount : " + giventext.Text + "\n\tChange Ammount : " + changetxt.Text+"\n\tAre you sure,submit current sale?", "Questions...", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr==DialogResult.Yes) {
                    i.insertsales(dataGridView5, "idgv", "iquantity","iprice","itotal", DateTime.Now, Convert.ToSingle(grosstotal.Text), Convert.ToSingle(giventext.Text), Convert.ToSingle(changetxt.Text));
                    giventext.Text = "";
                    changetxt.Text = "";
                    totaltxt.Text = "";
                    dataGridView5.Rows.Clear();
                    grosstotal.Text = "00.0000";
                    ReportView rw = new ReportView();
                    rw.Show();
                }
            }
            else
            {
                MessageBox.Show("Please provide complete information", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;
            this.WindowState = FormWindowState.Maximized;
            byte[] image = s.showimage();
            if (image == null)
            {
                userimage.Image = null;
            }
            else
            {
                MemoryStream ms = new MemoryStream(image);
                userimage.Image = Image.FromStream(ms);
                circularpicture1.Image = Image.FromStream(ms);
            }

        }

        private void loadbtn_Click(object sender, EventArgs e)
        {
            s.showsales(bunifuDatePicker1.Value, dataGridView6, s1, s2, s3, s4,s5);
        }

        private void contextMenuStrip2_Click(object sender, EventArgs e)
        {
            try
            {
                if (!this.dataGridView4.Rows[this.rowIndex].IsNewRow) //datagridview1
                {

                    if (dataGridView4.CurrentRow != null)
                    {
                        DBMain.con.Open();
                        DataGridViewRow dgvRow = dataGridView4.CurrentRow;
                        SqlCommand cmd = new SqlCommand("delete_loan", DBMain.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgvRow.Cells["g7"].Value));
                        cmd.ExecuteNonQuery();
                        DBMain.con.Close();
                        this.dataGridView4.Rows.RemoveAt(this.rowIndex);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lrbtn_Click(object sender, EventArgs e)
        {
            if (saleidtxt.Text != "")
            {
                if (digit.Match(saleidtxt.Text).Success)
                {
                    saleiderror.Visible = false;
                    s.showreturns(Convert.ToInt64(saleidtxt.Text),dataGridView7,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11);
                    bunifuDatePicker2.Value = Convert.ToDateTime(dataGridView7.Rows[0].Cells["r9"].Value.ToString());
                    tammounttxt.Text = dataGridView7.Rows[0].Cells["r5"].Value.ToString();
                    recodetxt.Focus();
                }
                else
                {
                    saleiderror.Visible = true;
                    saleidtxt.Text="";
                }
            }
            else
            {
                saleiderror.Visible = false;
            }
        }

        private void rebtn_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage("return");
        }

        private void backinvoice_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage("invoice");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        float ammount_refund = 0;
        Hashtable ht = new Hashtable();
        private void recodetxt_Validating(object sender, CancelEventArgs e)
        {
            if (!string.IsNullOrEmpty(recodetxt.Text))
            {
                if (dataGridView7.Rows.Count > 0)
                {
                    foreach(DataGridViewRow row in dataGridView7.Rows)
                    {
                        if (recodetxt.Text == row.Cells["r2"].Value.ToString())
                        {
                            DialogResult dr = MessageBox.Show("Are you sure you to return "+row.Cells["r3"].Value.ToString(),"Question..",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
                            if (dr == DialogResult.Yes)
                            {
                                
                                Int64 product_id = Convert.ToInt64(row.Cells["r11"].Value.ToString());
                                float product_price = Convert.ToSingle(row.Cells["r4"].Value.ToString());
                                int product_quantity = Convert.ToInt32(row.Cells["r8"].Value.ToString())-1;
                                ammount_refund += product_price;
                                refundtxt.Text = Math.Round(ammount_refund,0).ToString();
                                if (product_quantity == 0)
                                {
                                    if (ht.ContainsKey(row.Cells["r11"].Value))
                                    {
                                        Int64 proidht = Convert.ToInt64(row.Cells["r11"].Value.ToString());
                                        ht[proidht] = Convert.ToInt32(ht[proidht])-1;
                                    }
                                    else
                                    {
                                        ht.Add(row.Cells["r11"].Value,1);
                                    }
                                    dataGridView7.Rows.Remove(row);
                                }
                                else
                                {
                                    row.Cells["r8"].Value = product_quantity;
                                    row.Cells["r10"].Value = Convert.ToSingle(row.Cells["r4"].Value)*Convert.ToInt32(row.Cells["r8"].Value.ToString());
                                    if (ht.ContainsKey(row.Cells["r11"].Value))
                                    {
                                        Int64 proidht = Convert.ToInt64(row.Cells["r11"].Value.ToString());
                                        ht[proidht] = Convert.ToInt32(ht[proidht]) + 1;
                                    }
                                    else
                                    {
                                        ht.Add(row.Cells["r11"].Value, 1);
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
              
            }
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(recodetxt.Text)&& ht.Count>0 && !string.IsNullOrEmpty(saleidtxt.Text))
            {
                DialogResult dr = MessageBox.Show("Are you sure, you want to proced ?","Question..?",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    int x = 0;
                    foreach(DictionaryEntry de in ht)
                    {
                        x+=i.add_Refund(Convert.ToInt64(saleidtxt.Text),DateTime.Now,Convert.ToInt32(de.Key),Convert.ToInt32(de.Value),Convert.ToSingle(refundtxt.Text));
                        int currentqty = s.getqtyfromsd(Convert.ToInt32(de.Key));
                        int finalqty = currentqty + Convert.ToInt32(de.Value);
                        u.update_quantity(Convert.ToInt32(de.Key), finalqty);
                       u.update_saledetails(Convert.ToInt64(saleidtxt.Text), Convert.ToInt32(de.Value), Convert.ToInt32(de.Key));
                       
                    }
                    //u.update_salerefund(dataGridView7, "r4", "r10",saleidtxt.Text);
                    if (x > 0)
                    {
                        MessageBox.Show("Return and Refund successfully","Sucess",MessageBoxButtons.OK,MessageBoxIcon.Information);
                        x = 0;
                        ht.Clear();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please provide complete information","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            refundtxt.Text = "";
            recodetxt.Text = "";
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void gt1_TextChanged(object sender, EventArgs e)
        {
            if (alphabets.Match(gt1.Text).Success)
            {
                naerror.Visible = false;
            }
            else
            {
                naerror.Visible = true;
                gt1.SelectAll();
            }
        }

        private void t2_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(t2.Text))
            {
                nameerror.Visible = false;
            }
            else
            {
                if (alphabets.Match(t2.Text).Success)
                {
                    nameerror.Visible = false;
                }
                else
                {
                    nameerror.Visible = true;
                    t2.SelectAll();
                }
            }
               
        }
        string img = "";
        private void bunifuButton3_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|All Files (*.*)|*.*";
            dlg.Title = "Select Image";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                img = dlg.FileName.ToString();
                userimage.ImageLocation = img;
            }
        }

        private void code_Validating(object sender, CancelEventArgs e)
        {
            invoiceerror.Visible = false;
            if (!string.IsNullOrEmpty(code.Text))
            {
                int qcount = 0,squan=0,ncount;
                prodARR = s.getProduct(code.Text);
                foreach(DataGridViewRow row in dataGridView5.Rows)
                {
                    if (prodARR[0] == row.Cells["idgv"].Value.ToString())
                    {
                        qcount=qcount+Convert.ToInt32(row.Cells["iquantity"].Value.ToString());
                    }
                }
                squan=Convert.ToInt32( s.getquantity(Convert.ToInt32(prodARR[0])));
                ncount = squan - qcount;
                if (ncount <=0)
                {
                    if (prodARR[0] == null)
                    {
                        invoiceerror.Visible = true;
                        code.Focus();
                        code.Text = "";
                    }
                    else
                    {
                        code.Text = "";
                        //code.Focus();
                        MessageBox.Show("Stock is not avalaible", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }    
                }
                else
                {
                    if (prodARR[0] != null)
                    {
                        if (dataGridView5.RowCount == 0)
                        {
                            dataGridView5.Rows.Add(prodARR[1], 1, prodARR[3], prodARR[3], Convert.ToInt32(prodARR[0]));
                        }
                        else
                        {
                            foreach (DataGridViewRow row in dataGridView5.Rows)
                            {
                                if (row.Cells["idgv"].Value.ToString() == prodARR[0])
                                {
                                    checkpro = true;
                                    break;

                                }
                                else
                                {
                                    checkpro = false;
                                }
                            }
                            if (checkpro == true)
                            {

                                foreach (DataGridViewRow row in dataGridView5.Rows)
                                {
                                    if (row.Cells["idgv"].Value.ToString() == prodARR[0])
                                    {
                                        row.Cells["iquantity"].Value = Convert.ToInt32(row.Cells["iquantity"].Value.ToString()) + 1;
                                        totall = Convert.ToSingle(row.Cells["iprice"].Value.ToString()) * Convert.ToInt32(row.Cells["iquantity"].Value.ToString());
                                        row.Cells["itotal"].Value = totall;
                                    }

                                }

                            }
                            else
                            {
                                dataGridView5.Rows.Add(prodARR[1], 1, prodARR[3], prodARR[3], Convert.ToInt32(prodARR[0]));
                            }
                        }
                        foreach (DataGridViewRow row in dataGridView5.Rows)
                        {
                            gross += Convert.ToSingle(row.Cells["itotal"].Value.ToString());
                        }
                        grosstotal.Text = gross.ToString();
                        gross = 0;
                        code.Focus();
                        code.Text = "";
                    }
                    else
                    {
                        invoiceerror.Visible = true;
                        code.Focus();
                        code.Text = "";
                    }
                    
                }


                Array.Clear(prodARR, 0, prodARR.Length);
            }
        }
    }
}   





