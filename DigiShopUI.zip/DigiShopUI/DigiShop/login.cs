﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using kp.Toaster;
namespace DigiShop
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
            //add shadow
            (new Core.DropShaddow()).ApplyShadows(this);
        }
        private void login_Load(object sender, EventArgs e)
        {

        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            //exit  the application completly
            Application.Exit();
        }

        private void singin_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrEmpty(user.Text) || string.IsNullOrEmpty(pass.Text)) 
            {
                Toast.show(this, "Eror", "Incomplete information", ToastType.ERROR, ToastDuration.SHORT, ToastTheme.LIGHT);
               
            }
            else if (Selection.GetDetail(user.Text, pass.Text))
            {
                Form1 fm = new Form1();
                fm.Show();
                this.Hide();
            }
                //Toast.show(this, "Error", "Username or Password is incorrect", ToastType.ERROR, ToastDuration.SHORT, ToastTheme.LIGHT);
                //user.Text = "";
                //pass.Text = "";
                //user.Focus();
           
            //else if (user.Text == Selection.UserName && pass.Text != Selection.Password)
            //{
            //    Toast.show(this, "Error", "Username is incorrect", ToastType.ERROR, ToastDuration.SHORT, ToastTheme.LIGHT);
            //}

        }

        private void username_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void password_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
