﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using kp.Toaster;
using System.Windows.Forms;
using System.Transactions;

namespace DigiShop
{
    class Insertion
    {
        public void InsertUser(string name, string password ,byte[] imgg)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("sg_insertLongin", DBMain.con);//(sg_insertLongin) procedure name and DBMain is sql connection
                cmd.CommandType = CommandType.StoredProcedure;//select command type
                cmd.Parameters.AddWithValue("@name",name);//pass perameter first is database colummn name and second is text box name
                cmd.Parameters.AddWithValue("@password",password);//pass perameter first is database colummn name and second is text box name
                cmd.Parameters.AddWithValue("@image",imgg);//pass perameter first is database colummn name and second is text box name
                DBMain.con.Open();//open sql connection
                cmd.ExecuteNonQuery();//it is power full method for execution of insert update and delete method
              
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Information info = new Information();

                //Toast.show(info,"Error",ex.Message,ToastType.ERROR,ToastDuration.SHORT,ToastTheme.LIGHT);
            }
            finally// final run either try terminate or catch terminat
            {
                DBMain.con.Close();//close the connection
            }
        }
        public void InsertUserwim(string name, string password )
        {
            try
            {
                SqlCommand cmd = new SqlCommand("sg_insert", DBMain.con);//(sg_insertLongin) procedure name and DBMain is sql connection
                cmd.CommandType = CommandType.StoredProcedure;//select command type
                cmd.Parameters.AddWithValue("@name",name);//pass perameter first is database colummn name and second is text box name
                cmd.Parameters.AddWithValue("@password",password);//pass perameter first is database colummn name and second is text box name
                DBMain.con.Open();//open sql connection
                cmd.ExecuteNonQuery();//it is power full method for execution of insert update and delete method
              
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Information info = new Information();

                //Toast.show(info,"Error",ex.Message,ToastType.ERROR,ToastDuration.SHORT,ToastTheme.LIGHT);
            }
            finally// final run either try terminate or catch terminat
            {
                DBMain.con.Close();//close the connection
            }
        }
        public void add_iteam(string name, string code, float price, DateTime? expiry, int qty, float profit,float total)
        {
            Additem ad = new Additem();
            try
            {
                SqlCommand cmd = new SqlCommand("add_iteam", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@code", code);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@expiry", expiry);
                cmd.Parameters.AddWithValue("@price", price);
                cmd.Parameters.AddWithValue("@qty", qty);
                cmd.Parameters.AddWithValue("@profit", profit);
                cmd.Parameters.AddWithValue("@selprice", total);
                DBMain.con.Open();
                
                //Toast.show(ad, "Done", "Done sucessfully", ToastType.INFO, ToastDuration.LONG, ToastTheme.LIGHT);
                cmd.ExecuteNonQuery();
            DBMain.con.Close();
            }
           catch(Exception ex)
            {
                //Toast.show(ad, "Error", ex.Message, ToastType.ERROR, ToastDuration.LONG, ToastTheme.LIGHT);
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
        }
        public int add_Refund(Int64 saleid, DateTime now,int proid, int qty ,float total)
        {
            int re=0;
            //Additem ad = new Additem();
            try
            {
                SqlCommand cmd = new SqlCommand("ins_refund", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@saleid", saleid);
                cmd.Parameters.AddWithValue("@date", now);
                cmd.Parameters.AddWithValue("@proid", proid);
                cmd.Parameters.AddWithValue("@qty", qty);
                cmd.Parameters.AddWithValue("@ammount", total);
                DBMain.con.Open();
                
                //Toast.show(ad, "Done", "Done sucessfully", ToastType.INFO, ToastDuration.LONG, ToastTheme.LIGHT);
              re=  cmd.ExecuteNonQuery();
            DBMain.con.Close();
            }
           catch(Exception ex)
            {
                //Toast.show(ad, "Error", ex.Message, ToastType.ERROR, ToastDuration.LONG, ToastTheme.LIGHT);
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
            return re;
        }
        public void add_giveMoney(string name, string title, float price, float remaning,float loan, Int64 no)
        {
            Additem ad = new Additem();
            try
            {
                SqlCommand cmd = new SqlCommand("ins_loan", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@give", price);
                cmd.Parameters.AddWithValue("@remaning", remaning);
                cmd.Parameters.AddWithValue("@loan", loan);
                cmd.Parameters.AddWithValue("@no", no);
                DBMain.con.Open();
                
               // Toast.show(ad, "Done", "Done sucessfully", ToastType.ERROR, ToastDuration.LONG, ToastTheme.LIGHT);
                cmd.ExecuteNonQuery();
            DBMain.con.Close();
            }
           catch(Exception ex)
            {
                //Toast.show(ad, "Error", ex.Message, ToastType.ERROR, ToastDuration.LONG, ToastTheme.LIGHT);
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
        }
        int salcount = 0;
        Int64 salid = 0;
        Selection s = new Selection();
        Updation u = new Updation();
        public void insertsales(DataGridView gv,string idgv,string iquantity,string iprice,string itotal,DateTime dt,float total,float given,float change)
        {
            //Additem ad = new Additem();
            try
            {
                //using (TransactionScope sc =new TransactionScope())
                //{

                    SqlCommand cmd = new SqlCommand("ins_sales", DBMain.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@date", dt);
                    cmd.Parameters.AddWithValue("@totamt", total);
                    cmd.Parameters.AddWithValue("@given", given);
                    cmd.Parameters.AddWithValue("@return", change);
                    DBMain.con.Open();
                    // Toast.show(ad, "Done", "Done sucessfully", ToastType.INFO, ToastDuration.LONG, ToastTheme.LIGHT);
                    salcount = cmd.ExecuteNonQuery();
                    if (salcount > 0)
                    {
                        SqlCommand cmd2 = new SqlCommand("getsalesid", DBMain.con);
                        cmd2.CommandType = CommandType.StoredProcedure;
                        salid = Convert.ToInt64(cmd2.ExecuteScalar());
                        foreach (DataGridViewRow row in gv.Rows)
                        {
                            SqlCommand cmd3 = new SqlCommand("insertsalesdetails", DBMain.con);
                            cmd3.CommandType = CommandType.StoredProcedure;
                            cmd3.Parameters.AddWithValue("@salid", salid);
                            cmd3.Parameters.AddWithValue("@proid", Convert.ToInt64(row.Cells[idgv].Value.ToString()));
                            cmd3.Parameters.AddWithValue("@quan", Convert.ToInt32(row.Cells[iquantity].Value.ToString()));
                            cmd3.Parameters.AddWithValue("@price", Convert.ToSingle(row.Cells[iprice].Value.ToString()));
                            cmd3.Parameters.AddWithValue("@totalper", Convert.ToSingle(row.Cells[itotal].Value.ToString()));
                            cmd3.ExecuteNonQuery();
                            int stockofproduct = Convert.ToInt32(s.withgetquantity(Convert.ToInt32(row.Cells[idgv].Value.ToString())));
                            int currentquantity= Convert.ToInt32(row.Cells[iquantity].Value.ToString());
                            int finalproduct = stockofproduct - currentquantity;
                            u.update_Stockiteam(Convert.ToInt32(row.Cells[idgv].Value.ToString()),finalproduct);
                        }
                    }
                    MessageBox.Show("Sale successfull","Sucess",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    //
               // }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error..", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
        }

    }
}
