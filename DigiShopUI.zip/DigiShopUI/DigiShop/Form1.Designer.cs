﻿namespace DigiShop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
            
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Utilities.BunifuPages.BunifuAnimatorNS.Animation animation4 = new Utilities.BunifuPages.BunifuAnimatorNS.Animation();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties17 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties18 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties19 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties20 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges7 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Utilities.BunifuPages.BunifuAnimatorNS.Animation animation1 = new Utilities.BunifuPages.BunifuAnimatorNS.Animation();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges8 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties31 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties32 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Utilities.BunifuPages.BunifuAnimatorNS.Animation animation2 = new Utilities.BunifuPages.BunifuAnimatorNS.Animation();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties33 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties34 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties35 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties36 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties37 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties38 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties39 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties40 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges13 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Utilities.BunifuPages.BunifuAnimatorNS.Animation animation3 = new Utilities.BunifuPages.BunifuAnimatorNS.Animation();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties41 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties42 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties43 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties44 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges14 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties45 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties46 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties47 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties48 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties49 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties50 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties51 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties52 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties53 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties54 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties55 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties56 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties57 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties58 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties59 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties60 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties61 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties62 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties63 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties64 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges15 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges16 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties65 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties66 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties67 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties68 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties69 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties70 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties71 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties72 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges17 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties73 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties74 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties75 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties76 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties77 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties78 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties79 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties80 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties81 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties82 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties83 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties84 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties85 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties86 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties87 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties88 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties89 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties90 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties91 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties92 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges18 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges19 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties93 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties94 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties95 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties96 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties97 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties98 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties99 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties100 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties101 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties102 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties103 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties104 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties105 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties106 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties107 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties108 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            this.navigation = new System.Windows.Forms.Panel();
            this.circularpicture1 = new DigiShop.Circularpicture();
            this.minimum = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.maxnormal = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.close = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.slide = new System.Windows.Forms.Panel();
            this.indicator = new System.Windows.Forms.PictureBox();
            this.setting = new Bunifu.Framework.UI.BunifuFlatButton();
            this.payment = new Bunifu.Framework.UI.BunifuFlatButton();
            this.stock = new Bunifu.Framework.UI.BunifuFlatButton();
            this.report = new Bunifu.Framework.UI.BunifuFlatButton();
            this.inventroy = new Bunifu.Framework.UI.BunifuFlatButton();
            this.invoice = new Bunifu.Framework.UI.BunifuFlatButton();
            this.menu = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuPages1 = new Bunifu.UI.WinForms.BunifuPages();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.rebtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.checkbtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.gerror = new System.Windows.Forms.Label();
            this.changetxt = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuTextBox5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuTextBox4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.giventext = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.totaltxt = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.paybtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.invoiceerror = new System.Windows.Forms.Label();
            this.bunifuSeparator5 = new Bunifu.Framework.UI.BunifuSeparator();
            this.code = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.grosstotal = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.iproduct = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iquantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idgv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.actionbtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.bunifuSeparator7 = new Bunifu.Framework.UI.BunifuSeparator();
            this.searchiteam = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.btn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.c1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addbtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.bunifuSeparator8 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator4 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuPages2 = new Bunifu.UI.WinForms.BunifuPages();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.loadbtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuDatePicker1 = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.s1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.s2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.s3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.s4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.s5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.searchreport = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.bunifuDataGridView1 = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.indicator1 = new System.Windows.Forms.Panel();
            this.returnreport = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnreport = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.bunifuSeparator9 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.indicator3 = new System.Windows.Forms.Panel();
            this.btnemp = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuPages4 = new Bunifu.UI.WinForms.BunifuPages();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.scode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sqty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sdue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stcksearch = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.stkbtn = new System.Windows.Forms.Button();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.searchempty = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.ecode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ename = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eqty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.edue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.empty = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.bunifuButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.bunifuSeparator10 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.addloan = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuPages5 = new Bunifu.UI.WinForms.BunifuPages();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.bunifuTextBox2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.loanrefresh = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.g1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.g2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.g3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.g4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.g5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.g6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.g7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.naerror = new System.Windows.Forms.Label();
            this.giveerror = new System.Windows.Forms.Label();
            this.loanerror = new System.Windows.Forms.Label();
            this.noerror = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.remaning = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.bunifuButton9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.gt4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.gt2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.gt5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.gt3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.gt1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.userimage = new DigiShop.Circularpicture();
            this.bunifuButton3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuSeparator11 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuButton10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.ut2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.ut1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.bunifuSeparator12 = new Bunifu.Framework.UI.BunifuSeparator();
            this.profiterror = new System.Windows.Forms.Label();
            this.nameerror = new System.Windows.Forms.Label();
            this.priceerror = new System.Windows.Forms.Label();
            this.qtyerror = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.expirypicker = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.bunifuButton6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.total = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.t5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.t3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.t4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.t2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.t1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.saleiderror = new System.Windows.Forms.Label();
            this.backinvoice = new System.Windows.Forms.PictureBox();
            this.bunifuDatePicker2 = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.lrbtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bunifuButton2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.label33 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.refundtxt = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.recodetxt = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.tammounttxt = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuSeparator6 = new Bunifu.Framework.UI.BunifuSeparator();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.saleidtxt = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.r1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.r11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deleteRowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cb1 = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.label34 = new System.Windows.Forms.Label();
            this.navigation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.circularpicture1)).BeginInit();
            this.slide.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.indicator)).BeginInit();
            this.bunifuPages1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.bunifuPages2.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuDataGridView1)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.bunifuPages4.SuspendLayout();
            this.tabPage14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.bunifuPages5.SuspendLayout();
            this.tabPage16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userimage)).BeginInit();
            this.tabPage13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backinvoice)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // navigation
            // 
            this.navigation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.navigation.Controls.Add(this.circularpicture1);
            this.navigation.Controls.Add(this.minimum);
            this.navigation.Controls.Add(this.maxnormal);
            this.navigation.Controls.Add(this.close);
            this.navigation.Dock = System.Windows.Forms.DockStyle.Top;
            this.navigation.Location = new System.Drawing.Point(180, 0);
            this.navigation.Name = "navigation";
            this.navigation.Size = new System.Drawing.Size(884, 35);
            this.navigation.TabIndex = 0;
            // 
            // circularpicture1
            // 
            this.circularpicture1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.circularpicture1.Image = ((System.Drawing.Image)(resources.GetObject("circularpicture1.Image")));
            this.circularpicture1.Location = new System.Drawing.Point(715, 0);
            this.circularpicture1.Name = "circularpicture1";
            this.circularpicture1.Size = new System.Drawing.Size(36, 33);
            this.circularpicture1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.circularpicture1.TabIndex = 21;
            this.circularpicture1.TabStop = false;
            // 
            // minimum
            // 
            this.minimum.AllowToggling = false;
            this.minimum.AnimationSpeed = 200;
            this.minimum.AutoGenerateColors = false;
            this.minimum.BackColor = System.Drawing.Color.Transparent;
            this.minimum.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.minimum.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("minimum.BackgroundImage")));
            this.minimum.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.minimum.ButtonText = "";
            this.minimum.ButtonTextMarginLeft = 0;
            this.minimum.ColorContrastOnClick = 45;
            this.minimum.ColorContrastOnHover = 45;
            this.minimum.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.minimum.CustomizableEdges = borderEdges1;
            this.minimum.DialogResult = System.Windows.Forms.DialogResult.None;
            this.minimum.DisabledBorderColor = System.Drawing.Color.Empty;
            this.minimum.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.minimum.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.minimum.Dock = System.Windows.Forms.DockStyle.Right;
            this.minimum.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.minimum.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.minimum.ForeColor = System.Drawing.Color.White;
            this.minimum.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.minimum.IconMarginLeft = 11;
            this.minimum.IconPadding = 10;
            this.minimum.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.minimum.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.minimum.IdleBorderRadius = 3;
            this.minimum.IdleBorderThickness = 1;
            this.minimum.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.minimum.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("minimum.IdleIconLeftImage")));
            this.minimum.IdleIconRightImage = null;
            this.minimum.IndicateFocus = false;
            this.minimum.Location = new System.Drawing.Point(773, 0);
            this.minimum.Name = "minimum";
            this.minimum.onHoverState.BorderColor = System.Drawing.Color.Gray;
            this.minimum.onHoverState.BorderRadius = 3;
            this.minimum.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.minimum.onHoverState.BorderThickness = 1;
            this.minimum.onHoverState.FillColor = System.Drawing.Color.Gray;
            this.minimum.onHoverState.ForeColor = System.Drawing.Color.White;
            this.minimum.onHoverState.IconLeftImage = null;
            this.minimum.onHoverState.IconRightImage = null;
            this.minimum.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.minimum.OnIdleState.BorderRadius = 3;
            this.minimum.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.minimum.OnIdleState.BorderThickness = 1;
            this.minimum.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.minimum.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.minimum.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("minimum.OnIdleState.IconLeftImage")));
            this.minimum.OnIdleState.IconRightImage = null;
            this.minimum.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.minimum.OnPressedState.BorderRadius = 3;
            this.minimum.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.minimum.OnPressedState.BorderThickness = 1;
            this.minimum.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.minimum.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.minimum.OnPressedState.IconLeftImage = null;
            this.minimum.OnPressedState.IconRightImage = null;
            this.minimum.Size = new System.Drawing.Size(37, 35);
            this.minimum.TabIndex = 2;
            this.minimum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.minimum.TextMarginLeft = 0;
            this.minimum.UseDefaultRadiusAndThickness = true;
            this.minimum.Click += new System.EventHandler(this.minimum_Click);
            // 
            // maxnormal
            // 
            this.maxnormal.AllowToggling = false;
            this.maxnormal.AnimationSpeed = 200;
            this.maxnormal.AutoGenerateColors = false;
            this.maxnormal.BackColor = System.Drawing.Color.Transparent;
            this.maxnormal.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.maxnormal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("maxnormal.BackgroundImage")));
            this.maxnormal.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.maxnormal.ButtonText = "";
            this.maxnormal.ButtonTextMarginLeft = 0;
            this.maxnormal.ColorContrastOnClick = 45;
            this.maxnormal.ColorContrastOnHover = 45;
            this.maxnormal.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.maxnormal.CustomizableEdges = borderEdges2;
            this.maxnormal.DialogResult = System.Windows.Forms.DialogResult.None;
            this.maxnormal.DisabledBorderColor = System.Drawing.Color.Empty;
            this.maxnormal.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.maxnormal.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.maxnormal.Dock = System.Windows.Forms.DockStyle.Right;
            this.maxnormal.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.maxnormal.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.maxnormal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.maxnormal.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.maxnormal.IconMarginLeft = 11;
            this.maxnormal.IconPadding = 10;
            this.maxnormal.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.maxnormal.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.maxnormal.IdleBorderRadius = 3;
            this.maxnormal.IdleBorderThickness = 1;
            this.maxnormal.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.maxnormal.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("maxnormal.IdleIconLeftImage")));
            this.maxnormal.IdleIconRightImage = null;
            this.maxnormal.IndicateFocus = false;
            this.maxnormal.Location = new System.Drawing.Point(810, 0);
            this.maxnormal.Name = "maxnormal";
            this.maxnormal.onHoverState.BorderColor = System.Drawing.Color.Gray;
            this.maxnormal.onHoverState.BorderRadius = 3;
            this.maxnormal.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.maxnormal.onHoverState.BorderThickness = 1;
            this.maxnormal.onHoverState.FillColor = System.Drawing.Color.Gray;
            this.maxnormal.onHoverState.ForeColor = System.Drawing.Color.White;
            this.maxnormal.onHoverState.IconLeftImage = null;
            this.maxnormal.onHoverState.IconRightImage = null;
            this.maxnormal.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.maxnormal.OnIdleState.BorderRadius = 3;
            this.maxnormal.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.maxnormal.OnIdleState.BorderThickness = 1;
            this.maxnormal.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.maxnormal.OnIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.maxnormal.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("maxnormal.OnIdleState.IconLeftImage")));
            this.maxnormal.OnIdleState.IconRightImage = null;
            this.maxnormal.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.maxnormal.OnPressedState.BorderRadius = 3;
            this.maxnormal.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.maxnormal.OnPressedState.BorderThickness = 1;
            this.maxnormal.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.maxnormal.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.maxnormal.OnPressedState.IconLeftImage = null;
            this.maxnormal.OnPressedState.IconRightImage = null;
            this.maxnormal.Size = new System.Drawing.Size(37, 35);
            this.maxnormal.TabIndex = 1;
            this.maxnormal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.maxnormal.TextMarginLeft = 0;
            this.maxnormal.UseDefaultRadiusAndThickness = true;
            this.maxnormal.Click += new System.EventHandler(this.maxnormal_Click);
            // 
            // close
            // 
            this.close.AllowToggling = false;
            this.close.AnimationSpeed = 200;
            this.close.AutoGenerateColors = false;
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("close.BackgroundImage")));
            this.close.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.close.ButtonText = "";
            this.close.ButtonTextMarginLeft = 0;
            this.close.ColorContrastOnClick = 45;
            this.close.ColorContrastOnHover = 45;
            this.close.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.close.CustomizableEdges = borderEdges3;
            this.close.DialogResult = System.Windows.Forms.DialogResult.None;
            this.close.DisabledBorderColor = System.Drawing.Color.Empty;
            this.close.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.close.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.close.Dock = System.Windows.Forms.DockStyle.Right;
            this.close.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.close.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.close.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.close.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.close.IconMarginLeft = 11;
            this.close.IconPadding = 10;
            this.close.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.close.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.close.IdleBorderRadius = 3;
            this.close.IdleBorderThickness = 1;
            this.close.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.close.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("close.IdleIconLeftImage")));
            this.close.IdleIconRightImage = null;
            this.close.IndicateFocus = false;
            this.close.Location = new System.Drawing.Point(847, 0);
            this.close.Name = "close";
            this.close.onHoverState.BorderColor = System.Drawing.Color.Gray;
            this.close.onHoverState.BorderRadius = 3;
            this.close.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.close.onHoverState.BorderThickness = 1;
            this.close.onHoverState.FillColor = System.Drawing.Color.Gray;
            this.close.onHoverState.ForeColor = System.Drawing.Color.White;
            this.close.onHoverState.IconLeftImage = null;
            this.close.onHoverState.IconRightImage = null;
            this.close.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.close.OnIdleState.BorderRadius = 3;
            this.close.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.close.OnIdleState.BorderThickness = 1;
            this.close.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.close.OnIdleState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.close.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("close.OnIdleState.IconLeftImage")));
            this.close.OnIdleState.IconRightImage = null;
            this.close.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.close.OnPressedState.BorderRadius = 3;
            this.close.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.close.OnPressedState.BorderThickness = 1;
            this.close.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.close.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.close.OnPressedState.IconLeftImage = null;
            this.close.OnPressedState.IconRightImage = null;
            this.close.Size = new System.Drawing.Size(37, 35);
            this.close.TabIndex = 0;
            this.close.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.close.TextMarginLeft = 0;
            this.close.UseDefaultRadiusAndThickness = true;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // slide
            // 
            this.slide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.slide.Controls.Add(this.indicator);
            this.slide.Controls.Add(this.setting);
            this.slide.Controls.Add(this.payment);
            this.slide.Controls.Add(this.stock);
            this.slide.Controls.Add(this.report);
            this.slide.Controls.Add(this.inventroy);
            this.slide.Controls.Add(this.invoice);
            this.slide.Controls.Add(this.menu);
            this.slide.Dock = System.Windows.Forms.DockStyle.Left;
            this.slide.Location = new System.Drawing.Point(0, 0);
            this.slide.Name = "slide";
            this.slide.Size = new System.Drawing.Size(180, 580);
            this.slide.TabIndex = 1;
            // 
            // indicator
            // 
            this.indicator.BackColor = System.Drawing.Color.DarkSlateGray;
            this.indicator.Location = new System.Drawing.Point(-4, 44);
            this.indicator.Name = "indicator";
            this.indicator.Size = new System.Drawing.Size(8, 44);
            this.indicator.TabIndex = 2;
            this.indicator.TabStop = false;
            // 
            // setting
            // 
            this.setting.Active = false;
            this.setting.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.setting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.setting.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.setting.BorderRadius = 0;
            this.setting.ButtonText = "    Setting";
            this.setting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.setting.DisabledColor = System.Drawing.Color.Gray;
            this.setting.Dock = System.Windows.Forms.DockStyle.Top;
            this.setting.Iconcolor = System.Drawing.Color.Transparent;
            this.setting.Iconimage = ((System.Drawing.Image)(resources.GetObject("setting.Iconimage")));
            this.setting.Iconimage_right = null;
            this.setting.Iconimage_right_Selected = null;
            this.setting.Iconimage_Selected = null;
            this.setting.IconMarginLeft = 0;
            this.setting.IconMarginRight = 0;
            this.setting.IconRightVisible = true;
            this.setting.IconRightZoom = 0D;
            this.setting.IconVisible = true;
            this.setting.IconZoom = 50D;
            this.setting.IsTab = false;
            this.setting.Location = new System.Drawing.Point(0, 264);
            this.setting.Name = "setting";
            this.setting.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.setting.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.setting.OnHoverTextColor = System.Drawing.Color.White;
            this.setting.selected = false;
            this.setting.Size = new System.Drawing.Size(180, 44);
            this.setting.TabIndex = 6;
            this.setting.Text = "    Setting";
            this.setting.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.setting.Textcolor = System.Drawing.Color.Black;
            this.setting.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.setting.Click += new System.EventHandler(this.setting_Click);
            // 
            // payment
            // 
            this.payment.Active = false;
            this.payment.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.payment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.payment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.payment.BorderRadius = 0;
            this.payment.ButtonText = "    Payment";
            this.payment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.payment.DisabledColor = System.Drawing.Color.Gray;
            this.payment.Dock = System.Windows.Forms.DockStyle.Top;
            this.payment.Iconcolor = System.Drawing.Color.Transparent;
            this.payment.Iconimage = ((System.Drawing.Image)(resources.GetObject("payment.Iconimage")));
            this.payment.Iconimage_right = null;
            this.payment.Iconimage_right_Selected = null;
            this.payment.Iconimage_Selected = null;
            this.payment.IconMarginLeft = 0;
            this.payment.IconMarginRight = 0;
            this.payment.IconRightVisible = true;
            this.payment.IconRightZoom = 0D;
            this.payment.IconVisible = true;
            this.payment.IconZoom = 40D;
            this.payment.IsTab = false;
            this.payment.Location = new System.Drawing.Point(0, 220);
            this.payment.Name = "payment";
            this.payment.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.payment.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.payment.OnHoverTextColor = System.Drawing.Color.White;
            this.payment.selected = false;
            this.payment.Size = new System.Drawing.Size(180, 44);
            this.payment.TabIndex = 5;
            this.payment.Text = "    Payment";
            this.payment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.payment.Textcolor = System.Drawing.Color.Black;
            this.payment.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.payment.Click += new System.EventHandler(this.payment_Click);
            // 
            // stock
            // 
            this.stock.Active = false;
            this.stock.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.stock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.stock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stock.BorderRadius = 0;
            this.stock.ButtonText = "    Stock";
            this.stock.Cursor = System.Windows.Forms.Cursors.Hand;
            this.stock.DisabledColor = System.Drawing.Color.Gray;
            this.stock.Dock = System.Windows.Forms.DockStyle.Top;
            this.stock.Iconcolor = System.Drawing.Color.Transparent;
            this.stock.Iconimage = ((System.Drawing.Image)(resources.GetObject("stock.Iconimage")));
            this.stock.Iconimage_right = null;
            this.stock.Iconimage_right_Selected = null;
            this.stock.Iconimage_Selected = null;
            this.stock.IconMarginLeft = 0;
            this.stock.IconMarginRight = 0;
            this.stock.IconRightVisible = true;
            this.stock.IconRightZoom = 0D;
            this.stock.IconVisible = true;
            this.stock.IconZoom = 40D;
            this.stock.IsTab = false;
            this.stock.Location = new System.Drawing.Point(0, 176);
            this.stock.Name = "stock";
            this.stock.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.stock.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.stock.OnHoverTextColor = System.Drawing.Color.White;
            this.stock.selected = false;
            this.stock.Size = new System.Drawing.Size(180, 44);
            this.stock.TabIndex = 4;
            this.stock.Text = "    Stock";
            this.stock.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.stock.Textcolor = System.Drawing.Color.Black;
            this.stock.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stock.Click += new System.EventHandler(this.stock_Click);
            // 
            // report
            // 
            this.report.Active = false;
            this.report.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.report.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.report.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.report.BorderRadius = 0;
            this.report.ButtonText = "    Report";
            this.report.Cursor = System.Windows.Forms.Cursors.Hand;
            this.report.DisabledColor = System.Drawing.Color.Gray;
            this.report.Dock = System.Windows.Forms.DockStyle.Top;
            this.report.Iconcolor = System.Drawing.Color.Transparent;
            this.report.Iconimage = ((System.Drawing.Image)(resources.GetObject("report.Iconimage")));
            this.report.Iconimage_right = null;
            this.report.Iconimage_right_Selected = null;
            this.report.Iconimage_Selected = null;
            this.report.IconMarginLeft = 0;
            this.report.IconMarginRight = 0;
            this.report.IconRightVisible = true;
            this.report.IconRightZoom = 0D;
            this.report.IconVisible = true;
            this.report.IconZoom = 59D;
            this.report.IsTab = false;
            this.report.Location = new System.Drawing.Point(0, 132);
            this.report.Name = "report";
            this.report.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.report.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.report.OnHoverTextColor = System.Drawing.Color.White;
            this.report.selected = false;
            this.report.Size = new System.Drawing.Size(180, 44);
            this.report.TabIndex = 3;
            this.report.Text = "    Report";
            this.report.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.report.Textcolor = System.Drawing.Color.Black;
            this.report.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.report.Click += new System.EventHandler(this.report_Click);
            // 
            // inventroy
            // 
            this.inventroy.Active = false;
            this.inventroy.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.inventroy.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.inventroy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.inventroy.BorderRadius = 0;
            this.inventroy.ButtonText = "    Inventroy";
            this.inventroy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.inventroy.DisabledColor = System.Drawing.Color.Gray;
            this.inventroy.Dock = System.Windows.Forms.DockStyle.Top;
            this.inventroy.Iconcolor = System.Drawing.Color.Transparent;
            this.inventroy.Iconimage = ((System.Drawing.Image)(resources.GetObject("inventroy.Iconimage")));
            this.inventroy.Iconimage_right = null;
            this.inventroy.Iconimage_right_Selected = null;
            this.inventroy.Iconimage_Selected = null;
            this.inventroy.IconMarginLeft = 0;
            this.inventroy.IconMarginRight = 0;
            this.inventroy.IconRightVisible = true;
            this.inventroy.IconRightZoom = 0D;
            this.inventroy.IconVisible = true;
            this.inventroy.IconZoom = 50D;
            this.inventroy.IsTab = false;
            this.inventroy.Location = new System.Drawing.Point(0, 88);
            this.inventroy.Name = "inventroy";
            this.inventroy.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.inventroy.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.inventroy.OnHoverTextColor = System.Drawing.Color.White;
            this.inventroy.selected = false;
            this.inventroy.Size = new System.Drawing.Size(180, 44);
            this.inventroy.TabIndex = 2;
            this.inventroy.Text = "    Inventroy";
            this.inventroy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.inventroy.Textcolor = System.Drawing.Color.Black;
            this.inventroy.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inventroy.Click += new System.EventHandler(this.inventroy_Click);
            // 
            // invoice
            // 
            this.invoice.Active = false;
            this.invoice.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.invoice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.invoice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.invoice.BorderRadius = 0;
            this.invoice.ButtonText = "    Invoice";
            this.invoice.Cursor = System.Windows.Forms.Cursors.Hand;
            this.invoice.DisabledColor = System.Drawing.Color.Gray;
            this.invoice.Dock = System.Windows.Forms.DockStyle.Top;
            this.invoice.Iconcolor = System.Drawing.Color.Transparent;
            this.invoice.Iconimage = ((System.Drawing.Image)(resources.GetObject("invoice.Iconimage")));
            this.invoice.Iconimage_right = null;
            this.invoice.Iconimage_right_Selected = null;
            this.invoice.Iconimage_Selected = null;
            this.invoice.IconMarginLeft = 0;
            this.invoice.IconMarginRight = 0;
            this.invoice.IconRightVisible = true;
            this.invoice.IconRightZoom = 0D;
            this.invoice.IconVisible = true;
            this.invoice.IconZoom = 50D;
            this.invoice.IsTab = false;
            this.invoice.Location = new System.Drawing.Point(0, 44);
            this.invoice.Name = "invoice";
            this.invoice.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.invoice.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.invoice.OnHoverTextColor = System.Drawing.Color.White;
            this.invoice.selected = false;
            this.invoice.Size = new System.Drawing.Size(180, 44);
            this.invoice.TabIndex = 1;
            this.invoice.Text = "    Invoice";
            this.invoice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.invoice.Textcolor = System.Drawing.Color.Black;
            this.invoice.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invoice.Click += new System.EventHandler(this.invoice_Click);
            // 
            // menu
            // 
            this.menu.Active = false;
            this.menu.Activecolor = System.Drawing.Color.Silver;
            this.menu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menu.BorderRadius = 0;
            this.menu.ButtonText = "     Menu";
            this.menu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menu.DisabledColor = System.Drawing.Color.Gray;
            this.menu.Dock = System.Windows.Forms.DockStyle.Top;
            this.menu.Iconcolor = System.Drawing.Color.Transparent;
            this.menu.Iconimage = ((System.Drawing.Image)(resources.GetObject("menu.Iconimage")));
            this.menu.Iconimage_right = null;
            this.menu.Iconimage_right_Selected = null;
            this.menu.Iconimage_Selected = null;
            this.menu.IconMarginLeft = 0;
            this.menu.IconMarginRight = 0;
            this.menu.IconRightVisible = true;
            this.menu.IconRightZoom = 0D;
            this.menu.IconVisible = true;
            this.menu.IconZoom = 35D;
            this.menu.IsTab = false;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.menu.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.menu.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.menu.selected = false;
            this.menu.Size = new System.Drawing.Size(180, 44);
            this.menu.TabIndex = 0;
            this.menu.Text = "     Menu";
            this.menu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.menu.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.menu.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu.Click += new System.EventHandler(this.menu_Click);
            // 
            // bunifuPages1
            // 
            this.bunifuPages1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.bunifuPages1.AllowTransitions = false;
            this.bunifuPages1.Controls.Add(this.tabPage1);
            this.bunifuPages1.Controls.Add(this.tabPage2);
            this.bunifuPages1.Controls.Add(this.tabPage3);
            this.bunifuPages1.Controls.Add(this.tabPage4);
            this.bunifuPages1.Controls.Add(this.tabPage5);
            this.bunifuPages1.Controls.Add(this.tabPage6);
            this.bunifuPages1.Controls.Add(this.tabPage13);
            this.bunifuPages1.Controls.Add(this.tabPage9);
            this.bunifuPages1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuPages1.Location = new System.Drawing.Point(180, 35);
            this.bunifuPages1.Multiline = true;
            this.bunifuPages1.Name = "bunifuPages1";
            this.bunifuPages1.Page = this.tabPage6;
            this.bunifuPages1.PageIndex = 5;
            this.bunifuPages1.PageName = "tabPage6";
            this.bunifuPages1.PageTitle = "setting";
            this.bunifuPages1.SelectedIndex = 0;
            this.bunifuPages1.Size = new System.Drawing.Size(884, 545);
            this.bunifuPages1.TabIndex = 2;
            animation4.AnimateOnlyDifferences = false;
            animation4.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.BlindCoeff")));
            animation4.LeafCoeff = 0F;
            animation4.MaxTime = 1F;
            animation4.MinTime = 0F;
            animation4.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.MosaicCoeff")));
            animation4.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation4.MosaicShift")));
            animation4.MosaicSize = 0;
            animation4.Padding = new System.Windows.Forms.Padding(0);
            animation4.RotateCoeff = 0F;
            animation4.RotateLimit = 0F;
            animation4.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.ScaleCoeff")));
            animation4.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation4.SlideCoeff")));
            animation4.TimeCoeff = 0F;
            animation4.TransparencyCoeff = 0F;
            this.bunifuPages1.Transition = animation4;
            this.bunifuPages1.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.Custom;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.tabPage1.Controls.Add(this.rebtn);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.invoiceerror);
            this.tabPage1.Controls.Add(this.bunifuSeparator5);
            this.tabPage1.Controls.Add(this.code);
            this.tabPage1.Controls.Add(this.grosstotal);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.dataGridView5);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(876, 519);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "invoice";
            // 
            // rebtn
            // 
            this.rebtn.AllowToggling = false;
            this.rebtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.rebtn.AnimationSpeed = 200;
            this.rebtn.AutoGenerateColors = false;
            this.rebtn.BackColor = System.Drawing.Color.Transparent;
            this.rebtn.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.rebtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("rebtn.BackgroundImage")));
            this.rebtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.rebtn.ButtonText = "Return";
            this.rebtn.ButtonTextMarginLeft = 0;
            this.rebtn.ColorContrastOnClick = 45;
            this.rebtn.ColorContrastOnHover = 45;
            this.rebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.rebtn.CustomizableEdges = borderEdges4;
            this.rebtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.rebtn.DisabledBorderColor = System.Drawing.Color.Empty;
            this.rebtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.rebtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.rebtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.rebtn.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.rebtn.ForeColor = System.Drawing.Color.White;
            this.rebtn.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.rebtn.IconMarginLeft = 11;
            this.rebtn.IconPadding = 10;
            this.rebtn.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.rebtn.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.rebtn.IdleBorderRadius = 30;
            this.rebtn.IdleBorderThickness = 1;
            this.rebtn.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.rebtn.IdleIconLeftImage = null;
            this.rebtn.IdleIconRightImage = null;
            this.rebtn.IndicateFocus = false;
            this.rebtn.Location = new System.Drawing.Point(758, 68);
            this.rebtn.Name = "rebtn";
            this.rebtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.rebtn.onHoverState.BorderRadius = 30;
            this.rebtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.rebtn.onHoverState.BorderThickness = 1;
            this.rebtn.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.rebtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.rebtn.onHoverState.IconLeftImage = null;
            this.rebtn.onHoverState.IconRightImage = null;
            this.rebtn.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.rebtn.OnIdleState.BorderRadius = 30;
            this.rebtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.rebtn.OnIdleState.BorderThickness = 1;
            this.rebtn.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.rebtn.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.rebtn.OnIdleState.IconLeftImage = null;
            this.rebtn.OnIdleState.IconRightImage = null;
            this.rebtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.rebtn.OnPressedState.BorderRadius = 30;
            this.rebtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.rebtn.OnPressedState.BorderThickness = 1;
            this.rebtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.rebtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.rebtn.OnPressedState.IconLeftImage = null;
            this.rebtn.OnPressedState.IconRightImage = null;
            this.rebtn.Size = new System.Drawing.Size(110, 35);
            this.rebtn.TabIndex = 19;
            this.rebtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.rebtn.TextMarginLeft = 0;
            this.rebtn.UseDefaultRadiusAndThickness = true;
            this.rebtn.Click += new System.EventHandler(this.rebtn_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.checkbtn);
            this.groupBox1.Controls.Add(this.gerror);
            this.groupBox1.Controls.Add(this.changetxt);
            this.groupBox1.Controls.Add(this.bunifuTextBox5);
            this.groupBox1.Controls.Add(this.bunifuTextBox4);
            this.groupBox1.Controls.Add(this.giventext);
            this.groupBox1.Controls.Add(this.totaltxt);
            this.groupBox1.Controls.Add(this.paybtn);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox1.Location = new System.Drawing.Point(3, 424);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(870, 92);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Payment";
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(432, 15);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(79, 13);
            this.label28.TabIndex = 18;
            this.label28.Text = "Change to give";
            // 
            // label27
            // 
            this.label27.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(250, 15);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(80, 13);
            this.label27.TabIndex = 18;
            this.label27.Text = "Ammount given";
            // 
            // label23
            // 
            this.label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(55, 15);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(77, 13);
            this.label23.TabIndex = 18;
            this.label23.Text = "Total ammount";
            // 
            // checkbtn
            // 
            this.checkbtn.AllowToggling = false;
            this.checkbtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkbtn.AnimationSpeed = 200;
            this.checkbtn.AutoGenerateColors = false;
            this.checkbtn.BackColor = System.Drawing.Color.Transparent;
            this.checkbtn.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.checkbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("checkbtn.BackgroundImage")));
            this.checkbtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.checkbtn.ButtonText = "Checkout";
            this.checkbtn.ButtonTextMarginLeft = 0;
            this.checkbtn.ColorContrastOnClick = 45;
            this.checkbtn.ColorContrastOnHover = 45;
            this.checkbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges5.BottomLeft = true;
            borderEdges5.BottomRight = true;
            borderEdges5.TopLeft = true;
            borderEdges5.TopRight = true;
            this.checkbtn.CustomizableEdges = borderEdges5;
            this.checkbtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.checkbtn.DisabledBorderColor = System.Drawing.Color.Empty;
            this.checkbtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.checkbtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.checkbtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.checkbtn.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.checkbtn.ForeColor = System.Drawing.Color.White;
            this.checkbtn.IconLeftCursor = System.Windows.Forms.Cursors.WaitCursor;
            this.checkbtn.IconMarginLeft = 11;
            this.checkbtn.IconPadding = 10;
            this.checkbtn.IconRightCursor = System.Windows.Forms.Cursors.WaitCursor;
            this.checkbtn.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.checkbtn.IdleBorderRadius = 30;
            this.checkbtn.IdleBorderThickness = 1;
            this.checkbtn.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.checkbtn.IdleIconLeftImage = null;
            this.checkbtn.IdleIconRightImage = null;
            this.checkbtn.IndicateFocus = false;
            this.checkbtn.Location = new System.Drawing.Point(603, 30);
            this.checkbtn.Name = "checkbtn";
            this.checkbtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.checkbtn.onHoverState.BorderRadius = 30;
            this.checkbtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.checkbtn.onHoverState.BorderThickness = 1;
            this.checkbtn.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.checkbtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.checkbtn.onHoverState.IconLeftImage = null;
            this.checkbtn.onHoverState.IconRightImage = null;
            this.checkbtn.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.checkbtn.OnIdleState.BorderRadius = 30;
            this.checkbtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.checkbtn.OnIdleState.BorderThickness = 1;
            this.checkbtn.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.checkbtn.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.checkbtn.OnIdleState.IconLeftImage = null;
            this.checkbtn.OnIdleState.IconRightImage = null;
            this.checkbtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.checkbtn.OnPressedState.BorderRadius = 30;
            this.checkbtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.checkbtn.OnPressedState.BorderThickness = 1;
            this.checkbtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.checkbtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.checkbtn.OnPressedState.IconLeftImage = null;
            this.checkbtn.OnPressedState.IconRightImage = null;
            this.checkbtn.Size = new System.Drawing.Size(104, 35);
            this.checkbtn.TabIndex = 1;
            this.checkbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkbtn.TextMarginLeft = 0;
            this.checkbtn.UseDefaultRadiusAndThickness = true;
            this.checkbtn.Click += new System.EventHandler(this.checkbtn_Click);
            // 
            // gerror
            // 
            this.gerror.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gerror.AutoSize = true;
            this.gerror.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gerror.ForeColor = System.Drawing.Color.Red;
            this.gerror.Location = new System.Drawing.Point(240, 70);
            this.gerror.Name = "gerror";
            this.gerror.Size = new System.Drawing.Size(98, 16);
            this.gerror.TabIndex = 17;
            this.gerror.Text = "Incorrect input";
            this.gerror.Visible = false;
            // 
            // changetxt
            // 
            this.changetxt.AcceptsReturn = false;
            this.changetxt.AcceptsTab = false;
            this.changetxt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.changetxt.AnimationSpeed = 200;
            this.changetxt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.changetxt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.changetxt.BackColor = System.Drawing.Color.Transparent;
            this.changetxt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("changetxt.BackgroundImage")));
            this.changetxt.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.changetxt.BorderColorDisabled = System.Drawing.Color.DimGray;
            this.changetxt.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.changetxt.BorderColorIdle = System.Drawing.Color.DimGray;
            this.changetxt.BorderRadius = 30;
            this.changetxt.BorderThickness = 2;
            this.changetxt.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.changetxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.changetxt.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.changetxt.DefaultText = "";
            this.changetxt.Enabled = false;
            this.changetxt.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.changetxt.HideSelection = true;
            this.changetxt.IconLeft = null;
            this.changetxt.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.changetxt.IconPadding = 10;
            this.changetxt.IconRight = null;
            this.changetxt.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.changetxt.Lines = new string[0];
            this.changetxt.Location = new System.Drawing.Point(417, 30);
            this.changetxt.MaxLength = 32767;
            this.changetxt.MinimumSize = new System.Drawing.Size(1, 1);
            this.changetxt.Modified = false;
            this.changetxt.Multiline = false;
            this.changetxt.Name = "changetxt";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.changetxt.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.DimGray;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.changetxt.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.changetxt.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.DimGray;
            stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.changetxt.OnIdleState = stateProperties4;
            this.changetxt.PasswordChar = '\0';
            this.changetxt.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.changetxt.PlaceholderText = "";
            this.changetxt.ReadOnly = false;
            this.changetxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.changetxt.SelectedText = "";
            this.changetxt.SelectionLength = 0;
            this.changetxt.SelectionStart = 0;
            this.changetxt.ShortcutsEnabled = true;
            this.changetxt.Size = new System.Drawing.Size(180, 35);
            this.changetxt.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.changetxt.TabIndex = 3;
            this.changetxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.changetxt.TextMarginBottom = 0;
            this.changetxt.TextMarginLeft = 5;
            this.changetxt.TextMarginTop = 0;
            this.changetxt.TextPlaceholder = "";
            this.changetxt.UseSystemPasswordChar = false;
            this.changetxt.WordWrap = true;
            // 
            // bunifuTextBox5
            // 
            this.bunifuTextBox5.AcceptsReturn = false;
            this.bunifuTextBox5.AcceptsTab = false;
            this.bunifuTextBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuTextBox5.AnimationSpeed = 200;
            this.bunifuTextBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox5.BackgroundImage")));
            this.bunifuTextBox5.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuTextBox5.BorderColorDisabled = System.Drawing.Color.DimGray;
            this.bunifuTextBox5.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuTextBox5.BorderColorIdle = System.Drawing.Color.DimGray;
            this.bunifuTextBox5.BorderRadius = 30;
            this.bunifuTextBox5.BorderThickness = 2;
            this.bunifuTextBox5.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox5.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuTextBox5.DefaultText = "";
            this.bunifuTextBox5.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox5.HideSelection = true;
            this.bunifuTextBox5.IconLeft = null;
            this.bunifuTextBox5.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox5.IconPadding = 10;
            this.bunifuTextBox5.IconRight = null;
            this.bunifuTextBox5.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox5.Lines = new string[0];
            this.bunifuTextBox5.Location = new System.Drawing.Point(603, 762);
            this.bunifuTextBox5.MaxLength = 32767;
            this.bunifuTextBox5.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox5.Modified = false;
            this.bunifuTextBox5.Multiline = false;
            this.bunifuTextBox5.Name = "bunifuTextBox5";
            stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox5.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.DimGray;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox5.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox5.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.DimGray;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox5.OnIdleState = stateProperties8;
            this.bunifuTextBox5.PasswordChar = '\0';
            this.bunifuTextBox5.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox5.PlaceholderText = "Ammount Given";
            this.bunifuTextBox5.ReadOnly = false;
            this.bunifuTextBox5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox5.SelectedText = "";
            this.bunifuTextBox5.SelectionLength = 0;
            this.bunifuTextBox5.SelectionStart = 0;
            this.bunifuTextBox5.ShortcutsEnabled = true;
            this.bunifuTextBox5.Size = new System.Drawing.Size(180, 35);
            this.bunifuTextBox5.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox5.TabIndex = 0;
            this.bunifuTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox5.TextMarginBottom = 0;
            this.bunifuTextBox5.TextMarginLeft = 5;
            this.bunifuTextBox5.TextMarginTop = 0;
            this.bunifuTextBox5.TextPlaceholder = "Ammount Given";
            this.bunifuTextBox5.UseSystemPasswordChar = false;
            this.bunifuTextBox5.WordWrap = true;
            this.bunifuTextBox5.TextChanged += new System.EventHandler(this.giventext_TextChanged);
            // 
            // bunifuTextBox4
            // 
            this.bunifuTextBox4.AcceptsReturn = false;
            this.bunifuTextBox4.AcceptsTab = false;
            this.bunifuTextBox4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuTextBox4.AnimationSpeed = 200;
            this.bunifuTextBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox4.BackgroundImage")));
            this.bunifuTextBox4.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuTextBox4.BorderColorDisabled = System.Drawing.Color.DimGray;
            this.bunifuTextBox4.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuTextBox4.BorderColorIdle = System.Drawing.Color.DimGray;
            this.bunifuTextBox4.BorderRadius = 30;
            this.bunifuTextBox4.BorderThickness = 2;
            this.bunifuTextBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox4.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuTextBox4.DefaultText = "";
            this.bunifuTextBox4.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox4.HideSelection = true;
            this.bunifuTextBox4.IconLeft = null;
            this.bunifuTextBox4.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox4.IconPadding = 10;
            this.bunifuTextBox4.IconRight = null;
            this.bunifuTextBox4.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox4.Lines = new string[0];
            this.bunifuTextBox4.Location = new System.Drawing.Point(417, 399);
            this.bunifuTextBox4.MaxLength = 32767;
            this.bunifuTextBox4.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox4.Modified = false;
            this.bunifuTextBox4.Multiline = false;
            this.bunifuTextBox4.Name = "bunifuTextBox4";
            stateProperties9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox4.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.DimGray;
            stateProperties10.FillColor = System.Drawing.Color.White;
            stateProperties10.ForeColor = System.Drawing.Color.Empty;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox4.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox4.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.DimGray;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox4.OnIdleState = stateProperties12;
            this.bunifuTextBox4.PasswordChar = '\0';
            this.bunifuTextBox4.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox4.PlaceholderText = "Ammount Given";
            this.bunifuTextBox4.ReadOnly = false;
            this.bunifuTextBox4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox4.SelectedText = "";
            this.bunifuTextBox4.SelectionLength = 0;
            this.bunifuTextBox4.SelectionStart = 0;
            this.bunifuTextBox4.ShortcutsEnabled = true;
            this.bunifuTextBox4.Size = new System.Drawing.Size(180, 35);
            this.bunifuTextBox4.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox4.TabIndex = 0;
            this.bunifuTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox4.TextMarginBottom = 0;
            this.bunifuTextBox4.TextMarginLeft = 5;
            this.bunifuTextBox4.TextMarginTop = 0;
            this.bunifuTextBox4.TextPlaceholder = "Ammount Given";
            this.bunifuTextBox4.UseSystemPasswordChar = false;
            this.bunifuTextBox4.WordWrap = true;
            this.bunifuTextBox4.TextChanged += new System.EventHandler(this.giventext_TextChanged);
            // 
            // giventext
            // 
            this.giventext.AcceptsReturn = false;
            this.giventext.AcceptsTab = false;
            this.giventext.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.giventext.AnimationSpeed = 200;
            this.giventext.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.giventext.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.giventext.BackColor = System.Drawing.Color.Transparent;
            this.giventext.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("giventext.BackgroundImage")));
            this.giventext.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.giventext.BorderColorDisabled = System.Drawing.Color.DimGray;
            this.giventext.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.giventext.BorderColorIdle = System.Drawing.Color.DimGray;
            this.giventext.BorderRadius = 30;
            this.giventext.BorderThickness = 2;
            this.giventext.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.giventext.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.giventext.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.giventext.DefaultText = "";
            this.giventext.FillColor = System.Drawing.Color.White;
            this.giventext.HideSelection = true;
            this.giventext.IconLeft = null;
            this.giventext.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.giventext.IconPadding = 10;
            this.giventext.IconRight = null;
            this.giventext.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.giventext.Lines = new string[0];
            this.giventext.Location = new System.Drawing.Point(231, 30);
            this.giventext.MaxLength = 32767;
            this.giventext.MinimumSize = new System.Drawing.Size(1, 1);
            this.giventext.Modified = false;
            this.giventext.Multiline = false;
            this.giventext.Name = "giventext";
            stateProperties13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.giventext.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.DimGray;
            stateProperties14.FillColor = System.Drawing.Color.White;
            stateProperties14.ForeColor = System.Drawing.Color.Empty;
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.giventext.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.giventext.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.DimGray;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.giventext.OnIdleState = stateProperties16;
            this.giventext.PasswordChar = '\0';
            this.giventext.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.giventext.PlaceholderText = "";
            this.giventext.ReadOnly = false;
            this.giventext.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.giventext.SelectedText = "";
            this.giventext.SelectionLength = 0;
            this.giventext.SelectionStart = 0;
            this.giventext.ShortcutsEnabled = true;
            this.giventext.Size = new System.Drawing.Size(180, 35);
            this.giventext.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.giventext.TabIndex = 0;
            this.giventext.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.giventext.TextMarginBottom = 0;
            this.giventext.TextMarginLeft = 5;
            this.giventext.TextMarginTop = 0;
            this.giventext.TextPlaceholder = "";
            this.giventext.UseSystemPasswordChar = false;
            this.giventext.WordWrap = true;
            this.giventext.TextChanged += new System.EventHandler(this.giventext_TextChanged);
            this.giventext.Validating += new System.ComponentModel.CancelEventHandler(this.giventext_Validating);
            // 
            // totaltxt
            // 
            this.totaltxt.AcceptsReturn = false;
            this.totaltxt.AcceptsTab = false;
            this.totaltxt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.totaltxt.AnimationSpeed = 200;
            this.totaltxt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.totaltxt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.totaltxt.BackColor = System.Drawing.Color.Transparent;
            this.totaltxt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("totaltxt.BackgroundImage")));
            this.totaltxt.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.totaltxt.BorderColorDisabled = System.Drawing.Color.DimGray;
            this.totaltxt.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.totaltxt.BorderColorIdle = System.Drawing.Color.DimGray;
            this.totaltxt.BorderRadius = 30;
            this.totaltxt.BorderThickness = 2;
            this.totaltxt.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.totaltxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.totaltxt.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.totaltxt.DefaultText = "";
            this.totaltxt.Enabled = false;
            this.totaltxt.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.totaltxt.HideSelection = true;
            this.totaltxt.IconLeft = null;
            this.totaltxt.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.totaltxt.IconPadding = 10;
            this.totaltxt.IconRight = null;
            this.totaltxt.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.totaltxt.Lines = new string[0];
            this.totaltxt.Location = new System.Drawing.Point(45, 30);
            this.totaltxt.MaxLength = 32767;
            this.totaltxt.MinimumSize = new System.Drawing.Size(1, 1);
            this.totaltxt.Modified = false;
            this.totaltxt.Multiline = false;
            this.totaltxt.Name = "totaltxt";
            stateProperties17.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties17.FillColor = System.Drawing.Color.Empty;
            stateProperties17.ForeColor = System.Drawing.Color.Empty;
            stateProperties17.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.totaltxt.OnActiveState = stateProperties17;
            stateProperties18.BorderColor = System.Drawing.Color.DimGray;
            stateProperties18.FillColor = System.Drawing.Color.White;
            stateProperties18.ForeColor = System.Drawing.Color.Empty;
            stateProperties18.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.totaltxt.OnDisabledState = stateProperties18;
            stateProperties19.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties19.FillColor = System.Drawing.Color.Empty;
            stateProperties19.ForeColor = System.Drawing.Color.Empty;
            stateProperties19.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.totaltxt.OnHoverState = stateProperties19;
            stateProperties20.BorderColor = System.Drawing.Color.DimGray;
            stateProperties20.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties20.ForeColor = System.Drawing.Color.Empty;
            stateProperties20.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.totaltxt.OnIdleState = stateProperties20;
            this.totaltxt.PasswordChar = '\0';
            this.totaltxt.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.totaltxt.PlaceholderText = "";
            this.totaltxt.ReadOnly = false;
            this.totaltxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.totaltxt.SelectedText = "";
            this.totaltxt.SelectionLength = 0;
            this.totaltxt.SelectionStart = 0;
            this.totaltxt.ShortcutsEnabled = true;
            this.totaltxt.Size = new System.Drawing.Size(180, 35);
            this.totaltxt.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.totaltxt.TabIndex = 0;
            this.totaltxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.totaltxt.TextMarginBottom = 0;
            this.totaltxt.TextMarginLeft = 5;
            this.totaltxt.TextMarginTop = 0;
            this.totaltxt.TextPlaceholder = "";
            this.totaltxt.UseSystemPasswordChar = false;
            this.totaltxt.WordWrap = true;
            // 
            // paybtn
            // 
            this.paybtn.AllowToggling = false;
            this.paybtn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.paybtn.AnimationSpeed = 200;
            this.paybtn.AutoGenerateColors = false;
            this.paybtn.BackColor = System.Drawing.Color.Transparent;
            this.paybtn.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.paybtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("paybtn.BackgroundImage")));
            this.paybtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.paybtn.ButtonText = "Pay";
            this.paybtn.ButtonTextMarginLeft = 0;
            this.paybtn.ColorContrastOnClick = 45;
            this.paybtn.ColorContrastOnHover = 45;
            this.paybtn.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges6.BottomLeft = true;
            borderEdges6.BottomRight = true;
            borderEdges6.TopLeft = true;
            borderEdges6.TopRight = true;
            this.paybtn.CustomizableEdges = borderEdges6;
            this.paybtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.paybtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.paybtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.paybtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.paybtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.paybtn.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.paybtn.ForeColor = System.Drawing.Color.White;
            this.paybtn.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.paybtn.IconMarginLeft = 11;
            this.paybtn.IconPadding = 10;
            this.paybtn.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.paybtn.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.paybtn.IdleBorderRadius = 30;
            this.paybtn.IdleBorderThickness = 1;
            this.paybtn.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.paybtn.IdleIconLeftImage = null;
            this.paybtn.IdleIconRightImage = null;
            this.paybtn.IndicateFocus = false;
            this.paybtn.Location = new System.Drawing.Point(713, 30);
            this.paybtn.Name = "paybtn";
            this.paybtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.paybtn.onHoverState.BorderRadius = 30;
            this.paybtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.paybtn.onHoverState.BorderThickness = 1;
            this.paybtn.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.paybtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.paybtn.onHoverState.IconLeftImage = null;
            this.paybtn.onHoverState.IconRightImage = null;
            this.paybtn.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.paybtn.OnIdleState.BorderRadius = 30;
            this.paybtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.paybtn.OnIdleState.BorderThickness = 1;
            this.paybtn.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.paybtn.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.paybtn.OnIdleState.IconLeftImage = null;
            this.paybtn.OnIdleState.IconRightImage = null;
            this.paybtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.paybtn.OnPressedState.BorderRadius = 30;
            this.paybtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.paybtn.OnPressedState.BorderThickness = 1;
            this.paybtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.paybtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.paybtn.OnPressedState.IconLeftImage = null;
            this.paybtn.OnPressedState.IconRightImage = null;
            this.paybtn.Size = new System.Drawing.Size(104, 35);
            this.paybtn.TabIndex = 2;
            this.paybtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.paybtn.TextMarginLeft = 0;
            this.paybtn.UseDefaultRadiusAndThickness = true;
            this.paybtn.Click += new System.EventHandler(this.paybtn_Click);
            // 
            // invoiceerror
            // 
            this.invoiceerror.AutoSize = true;
            this.invoiceerror.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invoiceerror.ForeColor = System.Drawing.Color.Red;
            this.invoiceerror.Location = new System.Drawing.Point(8, 106);
            this.invoiceerror.Name = "invoiceerror";
            this.invoiceerror.Size = new System.Drawing.Size(175, 16);
            this.invoiceerror.TabIndex = 17;
            this.invoiceerror.Text = "Pleace input valid barcode";
            this.invoiceerror.Visible = false;
            // 
            // bunifuSeparator5
            // 
            this.bunifuSeparator5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator5.LineThickness = 1;
            this.bunifuSeparator5.Location = new System.Drawing.Point(19, 29);
            this.bunifuSeparator5.Name = "bunifuSeparator5";
            this.bunifuSeparator5.Size = new System.Drawing.Size(50, 10);
            this.bunifuSeparator5.TabIndex = 16;
            this.bunifuSeparator5.Transparency = 255;
            this.bunifuSeparator5.Vertical = false;
            // 
            // code
            // 
            this.code.AcceptsReturn = false;
            this.code.AcceptsTab = false;
            this.code.AnimationSpeed = 200;
            this.code.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.code.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.code.BackColor = System.Drawing.Color.Transparent;
            this.code.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("code.BackgroundImage")));
            this.code.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.code.BorderColorDisabled = System.Drawing.Color.DimGray;
            this.code.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.code.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.code.BorderRadius = 30;
            this.code.BorderThickness = 2;
            this.code.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.code.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.code.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.code.DefaultText = "";
            this.code.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.code.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.code.HideSelection = true;
            this.code.IconLeft = null;
            this.code.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.code.IconPadding = 10;
            this.code.IconRight = null;
            this.code.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.code.Lines = new string[0];
            this.code.Location = new System.Drawing.Point(2, 68);
            this.code.MaxLength = 32767;
            this.code.MinimumSize = new System.Drawing.Size(1, 1);
            this.code.Modified = false;
            this.code.Multiline = false;
            this.code.Name = "code";
            stateProperties21.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.code.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.DimGray;
            stateProperties22.FillColor = System.Drawing.Color.White;
            stateProperties22.ForeColor = System.Drawing.Color.Empty;
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.code.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.code.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties24.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            stateProperties24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.code.OnIdleState = stateProperties24;
            this.code.PasswordChar = '\0';
            this.code.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.code.PlaceholderText = "Enter Code";
            this.code.ReadOnly = false;
            this.code.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.code.SelectedText = "";
            this.code.SelectionLength = 0;
            this.code.SelectionStart = 0;
            this.code.ShortcutsEnabled = true;
            this.code.Size = new System.Drawing.Size(200, 35);
            this.code.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.code.TabIndex = 0;
            this.code.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.code.TextMarginBottom = 0;
            this.code.TextMarginLeft = 5;
            this.code.TextMarginTop = 0;
            this.code.TextPlaceholder = "Enter Code";
            this.code.UseSystemPasswordChar = false;
            this.code.WordWrap = true;
            this.code.Validating += new System.ComponentModel.CancelEventHandler(this.code_Validating);
            // 
            // grosstotal
            // 
            this.grosstotal.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.grosstotal.AutoSize = true;
            this.grosstotal.Font = new System.Drawing.Font("Arial Narrow", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grosstotal.Location = new System.Drawing.Point(282, 398);
            this.grosstotal.Name = "grosstotal";
            this.grosstotal.Size = new System.Drawing.Size(68, 23);
            this.grosstotal.TabIndex = 12;
            this.grosstotal.Text = "00.0000";
            // 
            // label22
            // 
            this.label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial Narrow", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(111, 392);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(162, 31);
            this.label22.TabIndex = 11;
            this.label22.Text = "Total Ammount";
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToAddRows = false;
            this.dataGridView5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView5.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.dataGridView5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView5.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView5.ColumnHeadersHeight = 30;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iproduct,
            this.iquantity,
            this.iprice,
            this.itotal,
            this.idgv,
            this.actionbtn});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.MediumTurquoise;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView5.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView5.EnableHeadersVisualStyles = false;
            this.dataGridView5.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.dataGridView5.Location = new System.Drawing.Point(2, 127);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            this.dataGridView5.RowHeadersVisible = false;
            this.dataGridView5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView5.Size = new System.Drawing.Size(870, 262);
            this.dataGridView5.TabIndex = 10;
            this.dataGridView5.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellClick);
            // 
            // iproduct
            // 
            this.iproduct.HeaderText = "Product";
            this.iproduct.Name = "iproduct";
            this.iproduct.ReadOnly = true;
            // 
            // iquantity
            // 
            this.iquantity.HeaderText = "Quantity";
            this.iquantity.Name = "iquantity";
            this.iquantity.ReadOnly = true;
            // 
            // iprice
            // 
            this.iprice.HeaderText = "Per Unit Price";
            this.iprice.Name = "iprice";
            this.iprice.ReadOnly = true;
            // 
            // itotal
            // 
            dataGridViewCellStyle2.Format = "N2";
            dataGridViewCellStyle2.NullValue = null;
            this.itotal.DefaultCellStyle = dataGridViewCellStyle2;
            this.itotal.HeaderText = "Total";
            this.itotal.Name = "itotal";
            this.itotal.ReadOnly = true;
            // 
            // idgv
            // 
            this.idgv.HeaderText = "Productid";
            this.idgv.Name = "idgv";
            this.idgv.ReadOnly = true;
            this.idgv.Visible = false;
            // 
            // actionbtn
            // 
            this.actionbtn.ContextMenuStrip = this.contextMenuStrip1;
            this.actionbtn.DataPropertyName = "Remove";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.actionbtn.DefaultCellStyle = dataGridViewCellStyle3;
            this.actionbtn.HeaderText = "Action";
            this.actionbtn.Name = "actionbtn";
            this.actionbtn.ReadOnly = true;
            this.actionbtn.Text = "Remove";
            this.actionbtn.ToolTipText = "Remove the quantity";
            this.actionbtn.UseColumnTextForButtonValue = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(134, 26);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.deleteToolStripMenuItem.Text = "Delete Row";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(2, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 35);
            this.label3.TabIndex = 1;
            this.label3.Text = "Invoice";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.bunifuSeparator7);
            this.tabPage2.Controls.Add(this.searchiteam);
            this.tabPage2.Controls.Add(this.btn);
            this.tabPage2.Controls.Add(this.dataGridView1);
            this.tabPage2.Controls.Add(this.addbtn);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(876, 519);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "inventroy";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // bunifuSeparator7
            // 
            this.bunifuSeparator7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator7.LineThickness = 1;
            this.bunifuSeparator7.Location = new System.Drawing.Point(29, 36);
            this.bunifuSeparator7.Name = "bunifuSeparator7";
            this.bunifuSeparator7.Size = new System.Drawing.Size(59, 10);
            this.bunifuSeparator7.TabIndex = 17;
            this.bunifuSeparator7.Transparency = 255;
            this.bunifuSeparator7.Vertical = false;
            // 
            // searchiteam
            // 
            this.searchiteam.AcceptsReturn = false;
            this.searchiteam.AcceptsTab = false;
            this.searchiteam.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.searchiteam.AnimationSpeed = 200;
            this.searchiteam.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.searchiteam.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.searchiteam.BackColor = System.Drawing.Color.Transparent;
            this.searchiteam.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("searchiteam.BackgroundImage")));
            this.searchiteam.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.searchiteam.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.searchiteam.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.searchiteam.BorderColorIdle = System.Drawing.Color.Silver;
            this.searchiteam.BorderRadius = 30;
            this.searchiteam.BorderThickness = 2;
            this.searchiteam.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.searchiteam.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.searchiteam.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.searchiteam.DefaultText = "";
            this.searchiteam.FillColor = System.Drawing.Color.White;
            this.searchiteam.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.searchiteam.HideSelection = true;
            this.searchiteam.IconLeft = null;
            this.searchiteam.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.searchiteam.IconPadding = 10;
            this.searchiteam.IconRight = ((System.Drawing.Image)(resources.GetObject("searchiteam.IconRight")));
            this.searchiteam.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.searchiteam.Lines = new string[0];
            this.searchiteam.Location = new System.Drawing.Point(644, 128);
            this.searchiteam.MaxLength = 32767;
            this.searchiteam.MinimumSize = new System.Drawing.Size(1, 1);
            this.searchiteam.Modified = false;
            this.searchiteam.Multiline = false;
            this.searchiteam.Name = "searchiteam";
            stateProperties25.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.searchiteam.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.Empty;
            stateProperties26.FillColor = System.Drawing.Color.White;
            stateProperties26.ForeColor = System.Drawing.Color.Empty;
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.searchiteam.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.searchiteam.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Silver;
            stateProperties28.FillColor = System.Drawing.Color.White;
            stateProperties28.ForeColor = System.Drawing.SystemColors.ControlDark;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.searchiteam.OnIdleState = stateProperties28;
            this.searchiteam.PasswordChar = '\0';
            this.searchiteam.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.searchiteam.PlaceholderText = "Search";
            this.searchiteam.ReadOnly = false;
            this.searchiteam.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.searchiteam.SelectedText = "";
            this.searchiteam.SelectionLength = 0;
            this.searchiteam.SelectionStart = 0;
            this.searchiteam.ShortcutsEnabled = true;
            this.searchiteam.Size = new System.Drawing.Size(229, 35);
            this.searchiteam.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.searchiteam.TabIndex = 4;
            this.searchiteam.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.searchiteam.TextMarginBottom = 0;
            this.searchiteam.TextMarginLeft = 5;
            this.searchiteam.TextMarginTop = 0;
            this.searchiteam.TextPlaceholder = "Search";
            this.searchiteam.UseSystemPasswordChar = false;
            this.searchiteam.WordWrap = true;
            this.searchiteam.TextChanged += new System.EventHandler(this.searchiteam_TextChanged);
            // 
            // btn
            // 
            this.btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn.BackgroundImage")));
            this.btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn.Location = new System.Drawing.Point(3, 137);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(48, 23);
            this.btn.TabIndex = 3;
            this.btn.UseVisualStyleBackColor = true;
            this.btn.Click += new System.EventHandler(this.btn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView1.ColumnHeadersHeight = 30;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.c1,
            this.c2,
            this.c3,
            this.c4,
            this.c5,
            this.c6,
            this.c7,
            this.c8});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Arrow;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Turquoise;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.DarkGray;
            this.dataGridView1.Location = new System.Drawing.Point(2, 163);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.SteelBlue;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(871, 353);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseUp);
            this.dataGridView1.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellValueChanged);
            // 
            // c1
            // 
            this.c1.DataPropertyName = "code";
            this.c1.HeaderText = "Code";
            this.c1.MaxInputLength = 327;
            this.c1.Name = "c1";
            // 
            // c2
            // 
            this.c2.DataPropertyName = "name";
            this.c2.HeaderText = "Product Name";
            this.c2.MaxInputLength = 327;
            this.c2.Name = "c2";
            // 
            // c3
            // 
            this.c3.DataPropertyName = "price";
            this.c3.HeaderText = "Price";
            this.c3.MaxInputLength = 327;
            this.c3.Name = "c3";
            // 
            // c4
            // 
            this.c4.DataPropertyName = "qty";
            this.c4.HeaderText = "Quantity";
            this.c4.MaxInputLength = 100;
            this.c4.Name = "c4";
            // 
            // c5
            // 
            this.c5.DataPropertyName = "profit";
            this.c5.HeaderText = "Profit";
            this.c5.MaxInputLength = 100;
            this.c5.Name = "c5";
            // 
            // c6
            // 
            this.c6.DataPropertyName = "expiry";
            this.c6.HeaderText = "Expiry";
            this.c6.Name = "c6";
            // 
            // c7
            // 
            this.c7.DataPropertyName = "id";
            this.c7.HeaderText = "iddgv";
            this.c7.Name = "c7";
            this.c7.Visible = false;
            // 
            // c8
            // 
            dataGridViewCellStyle6.NullValue = null;
            this.c8.DefaultCellStyle = dataGridViewCellStyle6;
            this.c8.HeaderText = "Sel Price";
            this.c8.MaxInputLength = 32;
            this.c8.Name = "c8";
            // 
            // addbtn
            // 
            this.addbtn.AllowToggling = false;
            this.addbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.addbtn.AnimationSpeed = 200;
            this.addbtn.AutoGenerateColors = false;
            this.addbtn.BackColor = System.Drawing.Color.Transparent;
            this.addbtn.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.addbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("addbtn.BackgroundImage")));
            this.addbtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.addbtn.ButtonText = "Add";
            this.addbtn.ButtonTextMarginLeft = 0;
            this.addbtn.ColorContrastOnClick = 45;
            this.addbtn.ColorContrastOnHover = 45;
            this.addbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges7.BottomLeft = true;
            borderEdges7.BottomRight = true;
            borderEdges7.TopLeft = true;
            borderEdges7.TopRight = true;
            this.addbtn.CustomizableEdges = borderEdges7;
            this.addbtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.addbtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.addbtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.addbtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.addbtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.addbtn.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.addbtn.ForeColor = System.Drawing.Color.White;
            this.addbtn.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.addbtn.IconMarginLeft = 11;
            this.addbtn.IconPadding = 10;
            this.addbtn.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.addbtn.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.addbtn.IdleBorderRadius = 30;
            this.addbtn.IdleBorderThickness = 1;
            this.addbtn.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.addbtn.IdleIconLeftImage = null;
            this.addbtn.IdleIconRightImage = null;
            this.addbtn.IndicateFocus = false;
            this.addbtn.Location = new System.Drawing.Point(764, 87);
            this.addbtn.Name = "addbtn";
            this.addbtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.addbtn.onHoverState.BorderRadius = 30;
            this.addbtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.addbtn.onHoverState.BorderThickness = 1;
            this.addbtn.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.addbtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.addbtn.onHoverState.IconLeftImage = null;
            this.addbtn.onHoverState.IconRightImage = null;
            this.addbtn.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.addbtn.OnIdleState.BorderRadius = 30;
            this.addbtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.addbtn.OnIdleState.BorderThickness = 1;
            this.addbtn.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.addbtn.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.addbtn.OnIdleState.IconLeftImage = null;
            this.addbtn.OnIdleState.IconRightImage = null;
            this.addbtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.addbtn.OnPressedState.BorderRadius = 30;
            this.addbtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.addbtn.OnPressedState.BorderThickness = 1;
            this.addbtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.addbtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.addbtn.OnPressedState.IconLeftImage = null;
            this.addbtn.OnPressedState.IconRightImage = null;
            this.addbtn.Size = new System.Drawing.Size(104, 35);
            this.addbtn.TabIndex = 1;
            this.addbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.addbtn.TextMarginLeft = 0;
            this.addbtn.UseDefaultRadiusAndThickness = true;
            this.addbtn.Click += new System.EventHandler(this.addbtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(2, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 35);
            this.label2.TabIndex = 0;
            this.label2.Text = "Inventroy";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.bunifuSeparator8);
            this.tabPage3.Controls.Add(this.bunifuSeparator4);
            this.tabPage3.Controls.Add(this.bunifuPages2);
            this.tabPage3.Controls.Add(this.indicator1);
            this.tabPage3.Controls.Add(this.returnreport);
            this.tabPage3.Controls.Add(this.btnreport);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Location = new System.Drawing.Point(4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(876, 519);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "report";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // bunifuSeparator8
            // 
            this.bunifuSeparator8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator8.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator8.LineThickness = 1;
            this.bunifuSeparator8.Location = new System.Drawing.Point(22, 38);
            this.bunifuSeparator8.Name = "bunifuSeparator8";
            this.bunifuSeparator8.Size = new System.Drawing.Size(50, 10);
            this.bunifuSeparator8.TabIndex = 17;
            this.bunifuSeparator8.Transparency = 255;
            this.bunifuSeparator8.Vertical = false;
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator4.LineThickness = 1;
            this.bunifuSeparator4.Location = new System.Drawing.Point(12, 108);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(835, 13);
            this.bunifuSeparator4.TabIndex = 7;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = false;
            // 
            // bunifuPages2
            // 
            this.bunifuPages2.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.bunifuPages2.AllowTransitions = true;
            this.bunifuPages2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuPages2.Controls.Add(this.tabPage7);
            this.bunifuPages2.Controls.Add(this.tabPage8);
            this.bunifuPages2.Location = new System.Drawing.Point(2, 127);
            this.bunifuPages2.Multiline = true;
            this.bunifuPages2.Name = "bunifuPages2";
            this.bunifuPages2.Page = this.tabPage7;
            this.bunifuPages2.PageIndex = 0;
            this.bunifuPages2.PageName = "tabPage7";
            this.bunifuPages2.PageTitle = "report";
            this.bunifuPages2.SelectedIndex = 0;
            this.bunifuPages2.Size = new System.Drawing.Size(874, 386);
            this.bunifuPages2.TabIndex = 6;
            animation1.AnimateOnlyDifferences = false;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.bunifuPages2.Transition = animation1;
            this.bunifuPages2.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.Custom;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.loadbtn);
            this.tabPage7.Controls.Add(this.bunifuDatePicker1);
            this.tabPage7.Controls.Add(this.dataGridView6);
            this.tabPage7.Location = new System.Drawing.Point(4, 4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(866, 360);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "report";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // loadbtn
            // 
            this.loadbtn.AllowToggling = false;
            this.loadbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.loadbtn.AnimationSpeed = 200;
            this.loadbtn.AutoGenerateColors = false;
            this.loadbtn.BackColor = System.Drawing.Color.Transparent;
            this.loadbtn.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.loadbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("loadbtn.BackgroundImage")));
            this.loadbtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.loadbtn.ButtonText = "Load";
            this.loadbtn.ButtonTextMarginLeft = 0;
            this.loadbtn.ColorContrastOnClick = 45;
            this.loadbtn.ColorContrastOnHover = 45;
            this.loadbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges8.BottomLeft = true;
            borderEdges8.BottomRight = true;
            borderEdges8.TopLeft = true;
            borderEdges8.TopRight = true;
            this.loadbtn.CustomizableEdges = borderEdges8;
            this.loadbtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.loadbtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.loadbtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.loadbtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.loadbtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.loadbtn.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.loadbtn.ForeColor = System.Drawing.Color.White;
            this.loadbtn.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.loadbtn.IconMarginLeft = 11;
            this.loadbtn.IconPadding = 10;
            this.loadbtn.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.loadbtn.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.loadbtn.IdleBorderRadius = 30;
            this.loadbtn.IdleBorderThickness = 1;
            this.loadbtn.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.loadbtn.IdleIconLeftImage = null;
            this.loadbtn.IdleIconRightImage = null;
            this.loadbtn.IndicateFocus = false;
            this.loadbtn.Location = new System.Drawing.Point(756, 9);
            this.loadbtn.Name = "loadbtn";
            this.loadbtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.loadbtn.onHoverState.BorderRadius = 30;
            this.loadbtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.loadbtn.onHoverState.BorderThickness = 1;
            this.loadbtn.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.loadbtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.loadbtn.onHoverState.IconLeftImage = null;
            this.loadbtn.onHoverState.IconRightImage = null;
            this.loadbtn.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.loadbtn.OnIdleState.BorderRadius = 30;
            this.loadbtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.loadbtn.OnIdleState.BorderThickness = 1;
            this.loadbtn.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.loadbtn.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.loadbtn.OnIdleState.IconLeftImage = null;
            this.loadbtn.OnIdleState.IconRightImage = null;
            this.loadbtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.loadbtn.OnPressedState.BorderRadius = 30;
            this.loadbtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.loadbtn.OnPressedState.BorderThickness = 1;
            this.loadbtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.loadbtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.loadbtn.OnPressedState.IconLeftImage = null;
            this.loadbtn.OnPressedState.IconRightImage = null;
            this.loadbtn.Size = new System.Drawing.Size(104, 35);
            this.loadbtn.TabIndex = 8;
            this.loadbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.loadbtn.TextMarginLeft = 0;
            this.loadbtn.UseDefaultRadiusAndThickness = true;
            this.loadbtn.Click += new System.EventHandler(this.loadbtn_Click);
            // 
            // bunifuDatePicker1
            // 
            this.bunifuDatePicker1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuDatePicker1.BorderRadius = 13;
            this.bunifuDatePicker1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuDatePicker1.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thick;
            this.bunifuDatePicker1.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.bunifuDatePicker1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuDatePicker1.DisplayWeekNumbers = false;
            this.bunifuDatePicker1.DPHeight = 0;
            this.bunifuDatePicker1.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.bunifuDatePicker1.FillDatePicker = false;
            this.bunifuDatePicker1.ForeColor = System.Drawing.Color.DimGray;
            this.bunifuDatePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.bunifuDatePicker1.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuDatePicker1.Icon")));
            this.bunifuDatePicker1.IconColor = System.Drawing.Color.DimGray;
            this.bunifuDatePicker1.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.bunifuDatePicker1.Location = new System.Drawing.Point(524, 12);
            this.bunifuDatePicker1.MinimumSize = new System.Drawing.Size(217, 32);
            this.bunifuDatePicker1.Name = "bunifuDatePicker1";
            this.bunifuDatePicker1.Size = new System.Drawing.Size(217, 32);
            this.bunifuDatePicker1.TabIndex = 12;
            // 
            // dataGridView6
            // 
            this.dataGridView6.AllowUserToAddRows = false;
            this.dataGridView6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView6.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView6.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.dataGridView6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView6.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView6.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView6.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView6.ColumnHeadersHeight = 30;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.s1,
            this.s2,
            this.s3,
            this.s4,
            this.s5});
            this.dataGridView6.EnableHeadersVisualStyles = false;
            this.dataGridView6.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.dataGridView6.Location = new System.Drawing.Point(4, 50);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.ReadOnly = true;
            this.dataGridView6.RowHeadersVisible = false;
            this.dataGridView6.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView6.Size = new System.Drawing.Size(860, 262);
            this.dataGridView6.TabIndex = 11;
            // 
            // s1
            // 
            this.s1.HeaderText = "Sale ID";
            this.s1.Name = "s1";
            this.s1.ReadOnly = true;
            // 
            // s2
            // 
            this.s2.HeaderText = "Total Ammount";
            this.s2.Name = "s2";
            this.s2.ReadOnly = true;
            // 
            // s3
            // 
            this.s3.HeaderText = "Given Ammount";
            this.s3.Name = "s3";
            this.s3.ReadOnly = true;
            // 
            // s4
            // 
            this.s4.HeaderText = "Return Ammount";
            this.s4.Name = "s4";
            this.s4.ReadOnly = true;
            // 
            // s5
            // 
            this.s5.HeaderText = "Refund";
            this.s5.Name = "s5";
            this.s5.ReadOnly = true;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.searchreport);
            this.tabPage8.Controls.Add(this.button1);
            this.tabPage8.Controls.Add(this.bunifuDataGridView1);
            this.tabPage8.Location = new System.Drawing.Point(4, 4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(866, 360);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "return";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // searchreport
            // 
            this.searchreport.AcceptsReturn = false;
            this.searchreport.AcceptsTab = false;
            this.searchreport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.searchreport.AnimationSpeed = 200;
            this.searchreport.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.searchreport.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.searchreport.BackColor = System.Drawing.Color.Transparent;
            this.searchreport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("searchreport.BackgroundImage")));
            this.searchreport.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.searchreport.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.searchreport.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.searchreport.BorderColorIdle = System.Drawing.Color.DimGray;
            this.searchreport.BorderRadius = 30;
            this.searchreport.BorderThickness = 2;
            this.searchreport.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.searchreport.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.searchreport.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.searchreport.DefaultText = "";
            this.searchreport.FillColor = System.Drawing.Color.White;
            this.searchreport.ForeColor = System.Drawing.Color.Black;
            this.searchreport.HideSelection = true;
            this.searchreport.IconLeft = null;
            this.searchreport.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.searchreport.IconPadding = 10;
            this.searchreport.IconRight = ((System.Drawing.Image)(resources.GetObject("searchreport.IconRight")));
            this.searchreport.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.searchreport.Lines = new string[0];
            this.searchreport.Location = new System.Drawing.Point(660, 3);
            this.searchreport.MaxLength = 32767;
            this.searchreport.MinimumSize = new System.Drawing.Size(1, 1);
            this.searchreport.Modified = false;
            this.searchreport.Multiline = false;
            this.searchreport.Name = "searchreport";
            stateProperties29.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties29.FillColor = System.Drawing.Color.Empty;
            stateProperties29.ForeColor = System.Drawing.Color.Black;
            stateProperties29.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.searchreport.OnActiveState = stateProperties29;
            stateProperties30.BorderColor = System.Drawing.Color.Empty;
            stateProperties30.FillColor = System.Drawing.Color.White;
            stateProperties30.ForeColor = System.Drawing.Color.Empty;
            stateProperties30.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.searchreport.OnDisabledState = stateProperties30;
            stateProperties31.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties31.FillColor = System.Drawing.Color.Empty;
            stateProperties31.ForeColor = System.Drawing.Color.Black;
            stateProperties31.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.searchreport.OnHoverState = stateProperties31;
            stateProperties32.BorderColor = System.Drawing.Color.DimGray;
            stateProperties32.FillColor = System.Drawing.Color.White;
            stateProperties32.ForeColor = System.Drawing.Color.Black;
            stateProperties32.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.searchreport.OnIdleState = stateProperties32;
            this.searchreport.PasswordChar = '\0';
            this.searchreport.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.searchreport.PlaceholderText = "Search";
            this.searchreport.ReadOnly = false;
            this.searchreport.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.searchreport.SelectedText = "";
            this.searchreport.SelectionLength = 0;
            this.searchreport.SelectionStart = 0;
            this.searchreport.ShortcutsEnabled = true;
            this.searchreport.Size = new System.Drawing.Size(200, 35);
            this.searchreport.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.searchreport.TabIndex = 2;
            this.searchreport.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.searchreport.TextMarginBottom = 0;
            this.searchreport.TextMarginLeft = 5;
            this.searchreport.TextMarginTop = 0;
            this.searchreport.TextPlaceholder = "Search";
            this.searchreport.UseSystemPasswordChar = false;
            this.searchreport.WordWrap = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(7, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bunifuDataGridView1
            // 
            this.bunifuDataGridView1.AllowCustomTheming = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.bunifuDataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuDataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.bunifuDataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.bunifuDataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bunifuDataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.bunifuDataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.bunifuDataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.bunifuDataGridView1.ColumnHeadersHeight = 40;
            this.bunifuDataGridView1.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView1.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView1.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView1.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView1.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView1.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.bunifuDataGridView1.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView1.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuDataGridView1.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView1.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView1.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.bunifuDataGridView1.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView1.CurrentTheme.Name = null;
            this.bunifuDataGridView1.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.bunifuDataGridView1.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.bunifuDataGridView1.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.bunifuDataGridView1.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView1.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.bunifuDataGridView1.DefaultCellStyle = dataGridViewCellStyle12;
            this.bunifuDataGridView1.EnableHeadersVisualStyles = false;
            this.bunifuDataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.bunifuDataGridView1.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuDataGridView1.HeaderBgColor = System.Drawing.Color.Empty;
            this.bunifuDataGridView1.HeaderForeColor = System.Drawing.Color.White;
            this.bunifuDataGridView1.Location = new System.Drawing.Point(6, 41);
            this.bunifuDataGridView1.Name = "bunifuDataGridView1";
            this.bunifuDataGridView1.RowHeadersVisible = false;
            this.bunifuDataGridView1.RowTemplate.Height = 40;
            this.bunifuDataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.bunifuDataGridView1.Size = new System.Drawing.Size(854, 319);
            this.bunifuDataGridView1.TabIndex = 0;
            this.bunifuDataGridView1.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // indicator1
            // 
            this.indicator1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.indicator1.Location = new System.Drawing.Point(12, 93);
            this.indicator1.Name = "indicator1";
            this.indicator1.Size = new System.Drawing.Size(100, 2);
            this.indicator1.TabIndex = 5;
            // 
            // returnreport
            // 
            this.returnreport.AllowToggling = false;
            this.returnreport.AnimationSpeed = 200;
            this.returnreport.AutoGenerateColors = false;
            this.returnreport.BackColor = System.Drawing.Color.Transparent;
            this.returnreport.BackColor1 = System.Drawing.Color.Transparent;
            this.returnreport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("returnreport.BackgroundImage")));
            this.returnreport.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.returnreport.ButtonText = "Return Detail";
            this.returnreport.ButtonTextMarginLeft = 0;
            this.returnreport.ColorContrastOnClick = 45;
            this.returnreport.ColorContrastOnHover = 45;
            this.returnreport.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges9.BottomLeft = true;
            borderEdges9.BottomRight = true;
            borderEdges9.TopLeft = true;
            borderEdges9.TopRight = true;
            this.returnreport.CustomizableEdges = borderEdges9;
            this.returnreport.DialogResult = System.Windows.Forms.DialogResult.None;
            this.returnreport.DisabledBorderColor = System.Drawing.Color.Empty;
            this.returnreport.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.returnreport.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.returnreport.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.returnreport.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.returnreport.ForeColor = System.Drawing.Color.Black;
            this.returnreport.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.returnreport.IconMarginLeft = 11;
            this.returnreport.IconPadding = 10;
            this.returnreport.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.returnreport.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.returnreport.IdleBorderRadius = 3;
            this.returnreport.IdleBorderThickness = 1;
            this.returnreport.IdleFillColor = System.Drawing.Color.Transparent;
            this.returnreport.IdleIconLeftImage = null;
            this.returnreport.IdleIconRightImage = null;
            this.returnreport.IndicateFocus = false;
            this.returnreport.Location = new System.Drawing.Point(123, 56);
            this.returnreport.Name = "returnreport";
            this.returnreport.onHoverState.BorderColor = System.Drawing.Color.Empty;
            this.returnreport.onHoverState.BorderRadius = 3;
            this.returnreport.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.returnreport.onHoverState.BorderThickness = 1;
            this.returnreport.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.returnreport.onHoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.returnreport.onHoverState.IconLeftImage = null;
            this.returnreport.onHoverState.IconRightImage = null;
            this.returnreport.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.returnreport.OnIdleState.BorderRadius = 3;
            this.returnreport.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.returnreport.OnIdleState.BorderThickness = 1;
            this.returnreport.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            this.returnreport.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.returnreport.OnIdleState.IconLeftImage = null;
            this.returnreport.OnIdleState.IconRightImage = null;
            this.returnreport.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.returnreport.OnPressedState.BorderRadius = 3;
            this.returnreport.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.returnreport.OnPressedState.BorderThickness = 1;
            this.returnreport.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.returnreport.OnPressedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.returnreport.OnPressedState.IconLeftImage = null;
            this.returnreport.OnPressedState.IconRightImage = null;
            this.returnreport.Size = new System.Drawing.Size(105, 45);
            this.returnreport.TabIndex = 3;
            this.returnreport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.returnreport.TextMarginLeft = 0;
            this.returnreport.UseDefaultRadiusAndThickness = true;
            this.returnreport.Visible = false;
            this.returnreport.Click += new System.EventHandler(this.returnreport_Click);
            // 
            // btnreport
            // 
            this.btnreport.AllowToggling = false;
            this.btnreport.AnimationSpeed = 200;
            this.btnreport.AutoGenerateColors = false;
            this.btnreport.BackColor = System.Drawing.Color.Transparent;
            this.btnreport.BackColor1 = System.Drawing.Color.Transparent;
            this.btnreport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnreport.BackgroundImage")));
            this.btnreport.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnreport.ButtonText = "Report";
            this.btnreport.ButtonTextMarginLeft = 0;
            this.btnreport.ColorContrastOnClick = 45;
            this.btnreport.ColorContrastOnHover = 45;
            this.btnreport.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges10.BottomLeft = true;
            borderEdges10.BottomRight = true;
            borderEdges10.TopLeft = true;
            borderEdges10.TopRight = true;
            this.btnreport.CustomizableEdges = borderEdges10;
            this.btnreport.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnreport.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnreport.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnreport.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnreport.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnreport.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreport.ForeColor = System.Drawing.Color.Black;
            this.btnreport.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.btnreport.IconMarginLeft = 11;
            this.btnreport.IconPadding = 10;
            this.btnreport.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.btnreport.IdleBorderColor = System.Drawing.Color.Transparent;
            this.btnreport.IdleBorderRadius = 3;
            this.btnreport.IdleBorderThickness = 1;
            this.btnreport.IdleFillColor = System.Drawing.Color.Transparent;
            this.btnreport.IdleIconLeftImage = null;
            this.btnreport.IdleIconRightImage = null;
            this.btnreport.IndicateFocus = false;
            this.btnreport.Location = new System.Drawing.Point(6, 57);
            this.btnreport.Name = "btnreport";
            this.btnreport.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnreport.onHoverState.BorderRadius = 3;
            this.btnreport.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnreport.onHoverState.BorderThickness = 1;
            this.btnreport.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnreport.onHoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btnreport.onHoverState.IconLeftImage = null;
            this.btnreport.onHoverState.IconRightImage = null;
            this.btnreport.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.btnreport.OnIdleState.BorderRadius = 3;
            this.btnreport.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnreport.OnIdleState.BorderThickness = 1;
            this.btnreport.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            this.btnreport.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.btnreport.OnIdleState.IconLeftImage = null;
            this.btnreport.OnIdleState.IconRightImage = null;
            this.btnreport.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnreport.OnPressedState.BorderRadius = 3;
            this.btnreport.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnreport.OnPressedState.BorderThickness = 1;
            this.btnreport.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.btnreport.OnPressedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btnreport.OnPressedState.IconLeftImage = null;
            this.btnreport.OnPressedState.IconRightImage = null;
            this.btnreport.Size = new System.Drawing.Size(111, 45);
            this.btnreport.TabIndex = 2;
            this.btnreport.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnreport.TextMarginLeft = 0;
            this.btnreport.UseDefaultRadiusAndThickness = true;
            this.btnreport.Visible = false;
            this.btnreport.Click += new System.EventHandler(this.btnreport_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 35);
            this.label6.TabIndex = 1;
            this.label6.Text = "Report";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.bunifuSeparator9);
            this.tabPage4.Controls.Add(this.bunifuSeparator1);
            this.tabPage4.Controls.Add(this.indicator3);
            this.tabPage4.Controls.Add(this.btnemp);
            this.tabPage4.Controls.Add(this.bunifuPages4);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.bunifuButton1);
            this.tabPage4.Location = new System.Drawing.Point(4, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(876, 519);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "stock";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // bunifuSeparator9
            // 
            this.bunifuSeparator9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator9.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator9.LineThickness = 1;
            this.bunifuSeparator9.Location = new System.Drawing.Point(14, 35);
            this.bunifuSeparator9.Name = "bunifuSeparator9";
            this.bunifuSeparator9.Size = new System.Drawing.Size(36, 10);
            this.bunifuSeparator9.TabIndex = 17;
            this.bunifuSeparator9.Transparency = 255;
            this.bunifuSeparator9.Vertical = false;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(10, 109);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(829, 2);
            this.bunifuSeparator1.TabIndex = 10;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // indicator3
            // 
            this.indicator3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.indicator3.Location = new System.Drawing.Point(12, 101);
            this.indicator3.Name = "indicator3";
            this.indicator3.Size = new System.Drawing.Size(100, 2);
            this.indicator3.TabIndex = 12;
            this.indicator3.Visible = false;
            // 
            // btnemp
            // 
            this.btnemp.AllowToggling = false;
            this.btnemp.AnimationSpeed = 200;
            this.btnemp.AutoGenerateColors = false;
            this.btnemp.BackColor = System.Drawing.Color.Transparent;
            this.btnemp.BackColor1 = System.Drawing.Color.White;
            this.btnemp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnemp.BackgroundImage")));
            this.btnemp.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnemp.ButtonText = "Empty";
            this.btnemp.ButtonTextMarginLeft = 0;
            this.btnemp.ColorContrastOnClick = 45;
            this.btnemp.ColorContrastOnHover = 45;
            this.btnemp.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges11.BottomLeft = true;
            borderEdges11.BottomRight = true;
            borderEdges11.TopLeft = true;
            borderEdges11.TopRight = true;
            this.btnemp.CustomizableEdges = borderEdges11;
            this.btnemp.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnemp.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnemp.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnemp.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnemp.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnemp.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.btnemp.ForeColor = System.Drawing.Color.Black;
            this.btnemp.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.btnemp.IconMarginLeft = 11;
            this.btnemp.IconPadding = 10;
            this.btnemp.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.btnemp.IdleBorderColor = System.Drawing.Color.White;
            this.btnemp.IdleBorderRadius = 3;
            this.btnemp.IdleBorderThickness = 1;
            this.btnemp.IdleFillColor = System.Drawing.Color.White;
            this.btnemp.IdleIconLeftImage = null;
            this.btnemp.IdleIconRightImage = null;
            this.btnemp.IndicateFocus = false;
            this.btnemp.Location = new System.Drawing.Point(140, 59);
            this.btnemp.Name = "btnemp";
            this.btnemp.onHoverState.BorderColor = System.Drawing.Color.White;
            this.btnemp.onHoverState.BorderRadius = 3;
            this.btnemp.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnemp.onHoverState.BorderThickness = 1;
            this.btnemp.onHoverState.FillColor = System.Drawing.Color.White;
            this.btnemp.onHoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btnemp.onHoverState.IconLeftImage = null;
            this.btnemp.onHoverState.IconRightImage = null;
            this.btnemp.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.btnemp.OnIdleState.BorderRadius = 3;
            this.btnemp.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnemp.OnIdleState.BorderThickness = 1;
            this.btnemp.OnIdleState.FillColor = System.Drawing.Color.White;
            this.btnemp.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.btnemp.OnIdleState.IconLeftImage = null;
            this.btnemp.OnIdleState.IconRightImage = null;
            this.btnemp.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.btnemp.OnPressedState.BorderRadius = 3;
            this.btnemp.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnemp.OnPressedState.BorderThickness = 1;
            this.btnemp.OnPressedState.FillColor = System.Drawing.Color.White;
            this.btnemp.OnPressedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.btnemp.OnPressedState.IconLeftImage = null;
            this.btnemp.OnPressedState.IconRightImage = null;
            this.btnemp.Size = new System.Drawing.Size(111, 45);
            this.btnemp.TabIndex = 11;
            this.btnemp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnemp.TextMarginLeft = 0;
            this.btnemp.UseDefaultRadiusAndThickness = true;
            this.btnemp.Click += new System.EventHandler(this.btnemp_Click);
            // 
            // bunifuPages4
            // 
            this.bunifuPages4.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.bunifuPages4.AllowTransitions = true;
            this.bunifuPages4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuPages4.Controls.Add(this.tabPage14);
            this.bunifuPages4.Controls.Add(this.tabPage15);
            this.bunifuPages4.Location = new System.Drawing.Point(2, 123);
            this.bunifuPages4.Multiline = true;
            this.bunifuPages4.Name = "bunifuPages4";
            this.bunifuPages4.Page = this.tabPage14;
            this.bunifuPages4.PageIndex = 0;
            this.bunifuPages4.PageName = "tabPage14";
            this.bunifuPages4.PageTitle = "stockava";
            this.bunifuPages4.SelectedIndex = 0;
            this.bunifuPages4.Size = new System.Drawing.Size(871, 390);
            this.bunifuPages4.TabIndex = 7;
            animation2.AnimateOnlyDifferences = false;
            animation2.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.BlindCoeff")));
            animation2.LeafCoeff = 0F;
            animation2.MaxTime = 1F;
            animation2.MinTime = 0F;
            animation2.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicCoeff")));
            animation2.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicShift")));
            animation2.MosaicSize = 0;
            animation2.Padding = new System.Windows.Forms.Padding(0);
            animation2.RotateCoeff = 0F;
            animation2.RotateLimit = 0F;
            animation2.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.ScaleCoeff")));
            animation2.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.SlideCoeff")));
            animation2.TimeCoeff = 0F;
            animation2.TransparencyCoeff = 0F;
            this.bunifuPages4.Transition = animation2;
            this.bunifuPages4.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.Custom;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.dataGridView3);
            this.tabPage14.Controls.Add(this.stcksearch);
            this.tabPage14.Controls.Add(this.stkbtn);
            this.tabPage14.Location = new System.Drawing.Point(4, 4);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(863, 364);
            this.tabPage14.TabIndex = 0;
            this.tabPage14.Text = "stockava";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.dataGridView3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView3.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView3.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView3.ColumnHeadersHeight = 35;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.scode,
            this.sname,
            this.sqty,
            this.sdue,
            this.sprice});
            this.dataGridView3.EnableHeadersVisualStyles = false;
            this.dataGridView3.GridColor = System.Drawing.Color.DarkGray;
            this.dataGridView3.Location = new System.Drawing.Point(2, 47);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersVisible = false;
            this.dataGridView3.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView3.Size = new System.Drawing.Size(855, 317);
            this.dataGridView3.TabIndex = 7;
            // 
            // scode
            // 
            this.scode.HeaderText = "Code";
            this.scode.Name = "scode";
            this.scode.ReadOnly = true;
            // 
            // sname
            // 
            this.sname.HeaderText = "Product";
            this.sname.Name = "sname";
            this.sname.ReadOnly = true;
            // 
            // sqty
            // 
            this.sqty.HeaderText = "Quantity";
            this.sqty.Name = "sqty";
            this.sqty.ReadOnly = true;
            // 
            // sdue
            // 
            this.sdue.HeaderText = "Expiry";
            this.sdue.Name = "sdue";
            this.sdue.ReadOnly = true;
            // 
            // sprice
            // 
            this.sprice.HeaderText = "Sel Price";
            this.sprice.Name = "sprice";
            this.sprice.ReadOnly = true;
            // 
            // stcksearch
            // 
            this.stcksearch.AcceptsReturn = false;
            this.stcksearch.AcceptsTab = false;
            this.stcksearch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.stcksearch.AnimationSpeed = 200;
            this.stcksearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.stcksearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.stcksearch.BackColor = System.Drawing.Color.Transparent;
            this.stcksearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stcksearch.BackgroundImage")));
            this.stcksearch.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.stcksearch.BorderColorDisabled = System.Drawing.Color.DimGray;
            this.stcksearch.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.stcksearch.BorderColorIdle = System.Drawing.Color.DimGray;
            this.stcksearch.BorderRadius = 30;
            this.stcksearch.BorderThickness = 2;
            this.stcksearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.stcksearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.stcksearch.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.stcksearch.DefaultText = "";
            this.stcksearch.FillColor = System.Drawing.Color.White;
            this.stcksearch.HideSelection = true;
            this.stcksearch.IconLeft = null;
            this.stcksearch.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.stcksearch.IconPadding = 10;
            this.stcksearch.IconRight = ((System.Drawing.Image)(resources.GetObject("stcksearch.IconRight")));
            this.stcksearch.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.stcksearch.Lines = new string[0];
            this.stcksearch.Location = new System.Drawing.Point(656, 10);
            this.stcksearch.MaxLength = 32767;
            this.stcksearch.MinimumSize = new System.Drawing.Size(1, 1);
            this.stcksearch.Modified = false;
            this.stcksearch.Multiline = false;
            this.stcksearch.Name = "stcksearch";
            stateProperties33.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties33.FillColor = System.Drawing.Color.Empty;
            stateProperties33.ForeColor = System.Drawing.Color.Empty;
            stateProperties33.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.stcksearch.OnActiveState = stateProperties33;
            stateProperties34.BorderColor = System.Drawing.Color.DimGray;
            stateProperties34.FillColor = System.Drawing.Color.White;
            stateProperties34.ForeColor = System.Drawing.Color.Empty;
            stateProperties34.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.stcksearch.OnDisabledState = stateProperties34;
            stateProperties35.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties35.FillColor = System.Drawing.Color.Empty;
            stateProperties35.ForeColor = System.Drawing.Color.Empty;
            stateProperties35.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.stcksearch.OnHoverState = stateProperties35;
            stateProperties36.BorderColor = System.Drawing.Color.DimGray;
            stateProperties36.FillColor = System.Drawing.Color.White;
            stateProperties36.ForeColor = System.Drawing.Color.Empty;
            stateProperties36.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.stcksearch.OnIdleState = stateProperties36;
            this.stcksearch.PasswordChar = '\0';
            this.stcksearch.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.stcksearch.PlaceholderText = "Search";
            this.stcksearch.ReadOnly = false;
            this.stcksearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.stcksearch.SelectedText = "";
            this.stcksearch.SelectionLength = 0;
            this.stcksearch.SelectionStart = 0;
            this.stcksearch.ShortcutsEnabled = true;
            this.stcksearch.Size = new System.Drawing.Size(200, 35);
            this.stcksearch.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.stcksearch.TabIndex = 6;
            this.stcksearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.stcksearch.TextMarginBottom = 0;
            this.stcksearch.TextMarginLeft = 5;
            this.stcksearch.TextMarginTop = 0;
            this.stcksearch.TextPlaceholder = "Search";
            this.stcksearch.UseSystemPasswordChar = false;
            this.stcksearch.WordWrap = true;
            this.stcksearch.TextChanged += new System.EventHandler(this.stcksearch_TextChanged);
            // 
            // stkbtn
            // 
            this.stkbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stkbtn.BackgroundImage")));
            this.stkbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.stkbtn.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.stkbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stkbtn.Location = new System.Drawing.Point(2, 21);
            this.stkbtn.Name = "stkbtn";
            this.stkbtn.Size = new System.Drawing.Size(48, 23);
            this.stkbtn.TabIndex = 5;
            this.stkbtn.UseVisualStyleBackColor = true;
            this.stkbtn.Click += new System.EventHandler(this.stkbtn_Click);
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.searchempty);
            this.tabPage15.Controls.Add(this.dataGridView2);
            this.tabPage15.Controls.Add(this.empty);
            this.tabPage15.Location = new System.Drawing.Point(4, 4);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(863, 364);
            this.tabPage15.TabIndex = 1;
            this.tabPage15.Text = "empty";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // searchempty
            // 
            this.searchempty.AcceptsReturn = false;
            this.searchempty.AcceptsTab = false;
            this.searchempty.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.searchempty.AnimationSpeed = 200;
            this.searchempty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.searchempty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.searchempty.BackColor = System.Drawing.Color.Transparent;
            this.searchempty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("searchempty.BackgroundImage")));
            this.searchempty.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.searchempty.BorderColorDisabled = System.Drawing.Color.DimGray;
            this.searchempty.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.searchempty.BorderColorIdle = System.Drawing.Color.DimGray;
            this.searchempty.BorderRadius = 30;
            this.searchempty.BorderThickness = 2;
            this.searchempty.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.searchempty.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.searchempty.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.searchempty.DefaultText = "";
            this.searchempty.FillColor = System.Drawing.Color.White;
            this.searchempty.HideSelection = true;
            this.searchempty.IconLeft = null;
            this.searchempty.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.searchempty.IconPadding = 10;
            this.searchempty.IconRight = ((System.Drawing.Image)(resources.GetObject("searchempty.IconRight")));
            this.searchempty.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.searchempty.Lines = new string[0];
            this.searchempty.Location = new System.Drawing.Point(656, 10);
            this.searchempty.MaxLength = 32767;
            this.searchempty.MinimumSize = new System.Drawing.Size(1, 1);
            this.searchempty.Modified = false;
            this.searchempty.Multiline = false;
            this.searchempty.Name = "searchempty";
            stateProperties37.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties37.FillColor = System.Drawing.Color.Empty;
            stateProperties37.ForeColor = System.Drawing.Color.Empty;
            stateProperties37.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.searchempty.OnActiveState = stateProperties37;
            stateProperties38.BorderColor = System.Drawing.Color.DimGray;
            stateProperties38.FillColor = System.Drawing.Color.White;
            stateProperties38.ForeColor = System.Drawing.Color.Empty;
            stateProperties38.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.searchempty.OnDisabledState = stateProperties38;
            stateProperties39.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties39.FillColor = System.Drawing.Color.Empty;
            stateProperties39.ForeColor = System.Drawing.Color.Empty;
            stateProperties39.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.searchempty.OnHoverState = stateProperties39;
            stateProperties40.BorderColor = System.Drawing.Color.DimGray;
            stateProperties40.FillColor = System.Drawing.Color.White;
            stateProperties40.ForeColor = System.Drawing.Color.Empty;
            stateProperties40.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.searchempty.OnIdleState = stateProperties40;
            this.searchempty.PasswordChar = '\0';
            this.searchempty.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.searchempty.PlaceholderText = "Search";
            this.searchempty.ReadOnly = false;
            this.searchempty.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.searchempty.SelectedText = "";
            this.searchempty.SelectionLength = 0;
            this.searchempty.SelectionStart = 0;
            this.searchempty.ShortcutsEnabled = true;
            this.searchempty.Size = new System.Drawing.Size(200, 35);
            this.searchempty.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.searchempty.TabIndex = 9;
            this.searchempty.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.searchempty.TextMarginBottom = 0;
            this.searchempty.TextMarginLeft = 5;
            this.searchempty.TextMarginTop = 0;
            this.searchempty.TextPlaceholder = "Search";
            this.searchempty.UseSystemPasswordChar = false;
            this.searchempty.WordWrap = true;
            this.searchempty.TextChanged += new System.EventHandler(this.searchempty_TextChanged);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView2.ColumnHeadersHeight = 30;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ecode,
            this.ename,
            this.eqty,
            this.edue,
            this.eprice});
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.GridColor = System.Drawing.Color.DarkGray;
            this.dataGridView2.Location = new System.Drawing.Point(-5, 46);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(865, 318);
            this.dataGridView2.TabIndex = 8;
            // 
            // ecode
            // 
            this.ecode.HeaderText = "Code";
            this.ecode.Name = "ecode";
            this.ecode.ReadOnly = true;
            // 
            // ename
            // 
            this.ename.HeaderText = "Product";
            this.ename.Name = "ename";
            this.ename.ReadOnly = true;
            // 
            // eqty
            // 
            this.eqty.HeaderText = "Quantity";
            this.eqty.Name = "eqty";
            this.eqty.ReadOnly = true;
            // 
            // edue
            // 
            this.edue.HeaderText = "Expiry";
            this.edue.Name = "edue";
            this.edue.ReadOnly = true;
            // 
            // eprice
            // 
            this.eprice.HeaderText = "Sel Price";
            this.eprice.Name = "eprice";
            this.eprice.ReadOnly = true;
            // 
            // empty
            // 
            this.empty.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("empty.BackgroundImage")));
            this.empty.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.empty.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.empty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.empty.Location = new System.Drawing.Point(2, 22);
            this.empty.Name = "empty";
            this.empty.Size = new System.Drawing.Size(48, 23);
            this.empty.TabIndex = 1;
            this.empty.UseVisualStyleBackColor = true;
            this.empty.Click += new System.EventHandler(this.empty_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 31);
            this.label4.TabIndex = 1;
            this.label4.Text = "Stock";
            // 
            // bunifuButton1
            // 
            this.bunifuButton1.AllowToggling = false;
            this.bunifuButton1.AnimationSpeed = 200;
            this.bunifuButton1.AutoGenerateColors = false;
            this.bunifuButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton1.BackColor1 = System.Drawing.Color.White;
            this.bunifuButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.BackgroundImage")));
            this.bunifuButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.ButtonText = "Stock";
            this.bunifuButton1.ButtonTextMarginLeft = 0;
            this.bunifuButton1.ColorContrastOnClick = 45;
            this.bunifuButton1.ColorContrastOnHover = 45;
            this.bunifuButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges12.BottomLeft = true;
            borderEdges12.BottomRight = true;
            borderEdges12.TopLeft = true;
            borderEdges12.TopRight = true;
            this.bunifuButton1.CustomizableEdges = borderEdges12;
            this.bunifuButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton1.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton1.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton1.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton1.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton1.ForeColor = System.Drawing.Color.Black;
            this.bunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton1.IconMarginLeft = 11;
            this.bunifuButton1.IconPadding = 10;
            this.bunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton1.IdleBorderColor = System.Drawing.Color.White;
            this.bunifuButton1.IdleBorderRadius = 3;
            this.bunifuButton1.IdleBorderThickness = 1;
            this.bunifuButton1.IdleFillColor = System.Drawing.Color.White;
            this.bunifuButton1.IdleIconLeftImage = null;
            this.bunifuButton1.IdleIconRightImage = null;
            this.bunifuButton1.IndicateFocus = false;
            this.bunifuButton1.Location = new System.Drawing.Point(5, 59);
            this.bunifuButton1.Name = "bunifuButton1";
            this.bunifuButton1.onHoverState.BorderColor = System.Drawing.Color.White;
            this.bunifuButton1.onHoverState.BorderRadius = 3;
            this.bunifuButton1.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.onHoverState.BorderThickness = 1;
            this.bunifuButton1.onHoverState.FillColor = System.Drawing.Color.White;
            this.bunifuButton1.onHoverState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton1.onHoverState.IconLeftImage = null;
            this.bunifuButton1.onHoverState.IconRightImage = null;
            this.bunifuButton1.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.bunifuButton1.OnIdleState.BorderRadius = 3;
            this.bunifuButton1.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.OnIdleState.BorderThickness = 1;
            this.bunifuButton1.OnIdleState.FillColor = System.Drawing.Color.White;
            this.bunifuButton1.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.bunifuButton1.OnIdleState.IconLeftImage = null;
            this.bunifuButton1.OnIdleState.IconRightImage = null;
            this.bunifuButton1.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.bunifuButton1.OnPressedState.BorderRadius = 3;
            this.bunifuButton1.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton1.OnPressedState.BorderThickness = 1;
            this.bunifuButton1.OnPressedState.FillColor = System.Drawing.Color.White;
            this.bunifuButton1.OnPressedState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton1.OnPressedState.IconLeftImage = null;
            this.bunifuButton1.OnPressedState.IconRightImage = null;
            this.bunifuButton1.Size = new System.Drawing.Size(111, 45);
            this.bunifuButton1.TabIndex = 13;
            this.bunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton1.TextMarginLeft = 0;
            this.bunifuButton1.UseDefaultRadiusAndThickness = true;
            this.bunifuButton1.Click += new System.EventHandler(this.bunifuButton7_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.bunifuSeparator10);
            this.tabPage5.Controls.Add(this.bunifuSeparator3);
            this.tabPage5.Controls.Add(this.addloan);
            this.tabPage5.Controls.Add(this.bunifuPages5);
            this.tabPage5.Controls.Add(this.label5);
            this.tabPage5.Location = new System.Drawing.Point(4, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(876, 519);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "payment";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // bunifuSeparator10
            // 
            this.bunifuSeparator10.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator10.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator10.LineThickness = 1;
            this.bunifuSeparator10.Location = new System.Drawing.Point(25, 39);
            this.bunifuSeparator10.Name = "bunifuSeparator10";
            this.bunifuSeparator10.Size = new System.Drawing.Size(56, 10);
            this.bunifuSeparator10.TabIndex = 17;
            this.bunifuSeparator10.Transparency = 255;
            this.bunifuSeparator10.Vertical = false;
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator3.LineThickness = 1;
            this.bunifuSeparator3.Location = new System.Drawing.Point(7, 64);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(844, 29);
            this.bunifuSeparator3.TabIndex = 6;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // addloan
            // 
            this.addloan.AllowToggling = false;
            this.addloan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.addloan.AnimationSpeed = 200;
            this.addloan.AutoGenerateColors = false;
            this.addloan.BackColor = System.Drawing.Color.Transparent;
            this.addloan.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.addloan.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("addloan.BackgroundImage")));
            this.addloan.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.addloan.ButtonText = "Add";
            this.addloan.ButtonTextMarginLeft = 0;
            this.addloan.ColorContrastOnClick = 45;
            this.addloan.ColorContrastOnHover = 45;
            this.addloan.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges13.BottomLeft = true;
            borderEdges13.BottomRight = true;
            borderEdges13.TopLeft = true;
            borderEdges13.TopRight = true;
            this.addloan.CustomizableEdges = borderEdges13;
            this.addloan.DialogResult = System.Windows.Forms.DialogResult.None;
            this.addloan.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.addloan.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.addloan.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.addloan.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.addloan.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.addloan.ForeColor = System.Drawing.Color.White;
            this.addloan.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.addloan.IconMarginLeft = 11;
            this.addloan.IconPadding = 10;
            this.addloan.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.addloan.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.addloan.IdleBorderRadius = 30;
            this.addloan.IdleBorderThickness = 1;
            this.addloan.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.addloan.IdleIconLeftImage = null;
            this.addloan.IdleIconRightImage = null;
            this.addloan.IndicateFocus = false;
            this.addloan.Location = new System.Drawing.Point(759, 16);
            this.addloan.Name = "addloan";
            this.addloan.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.addloan.onHoverState.BorderRadius = 30;
            this.addloan.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.addloan.onHoverState.BorderThickness = 1;
            this.addloan.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.addloan.onHoverState.ForeColor = System.Drawing.Color.White;
            this.addloan.onHoverState.IconLeftImage = null;
            this.addloan.onHoverState.IconRightImage = null;
            this.addloan.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.addloan.OnIdleState.BorderRadius = 30;
            this.addloan.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.addloan.OnIdleState.BorderThickness = 1;
            this.addloan.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.addloan.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.addloan.OnIdleState.IconLeftImage = null;
            this.addloan.OnIdleState.IconRightImage = null;
            this.addloan.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.addloan.OnPressedState.BorderRadius = 30;
            this.addloan.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.addloan.OnPressedState.BorderThickness = 1;
            this.addloan.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.addloan.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.addloan.OnPressedState.IconLeftImage = null;
            this.addloan.OnPressedState.IconRightImage = null;
            this.addloan.Size = new System.Drawing.Size(104, 33);
            this.addloan.TabIndex = 11;
            this.addloan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.addloan.TextMarginLeft = 0;
            this.addloan.UseDefaultRadiusAndThickness = true;
            this.addloan.Click += new System.EventHandler(this.addloan_Click);
            // 
            // bunifuPages5
            // 
            this.bunifuPages5.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.bunifuPages5.AllowTransitions = false;
            this.bunifuPages5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuPages5.Controls.Add(this.tabPage16);
            this.bunifuPages5.Controls.Add(this.tabPage18);
            this.bunifuPages5.Location = new System.Drawing.Point(3, 110);
            this.bunifuPages5.Multiline = true;
            this.bunifuPages5.Name = "bunifuPages5";
            this.bunifuPages5.Page = this.tabPage18;
            this.bunifuPages5.PageIndex = 1;
            this.bunifuPages5.PageName = "tabPage18";
            this.bunifuPages5.PageTitle = "add_give";
            this.bunifuPages5.SelectedIndex = 0;
            this.bunifuPages5.Size = new System.Drawing.Size(870, 409);
            this.bunifuPages5.TabIndex = 5;
            animation3.AnimateOnlyDifferences = true;
            animation3.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.BlindCoeff")));
            animation3.LeafCoeff = 0F;
            animation3.MaxTime = 1F;
            animation3.MinTime = 0F;
            animation3.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.MosaicCoeff")));
            animation3.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation3.MosaicShift")));
            animation3.MosaicSize = 0;
            animation3.Padding = new System.Windows.Forms.Padding(0, 0, 0, 0);
            animation3.RotateCoeff = 0F;
            animation3.RotateLimit = 0F;
            animation3.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.ScaleCoeff")));
            animation3.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation3.SlideCoeff")));
            animation3.TimeCoeff = 0F;
            animation3.TransparencyCoeff = 0F;
            this.bunifuPages5.Transition = animation3;
            this.bunifuPages5.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.VertSlide;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.bunifuTextBox2);
            this.tabPage16.Controls.Add(this.loanrefresh);
            this.tabPage16.Controls.Add(this.dataGridView4);
            this.tabPage16.Location = new System.Drawing.Point(4, 4);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(862, 383);
            this.tabPage16.TabIndex = 0;
            this.tabPage16.Text = "give";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // bunifuTextBox2
            // 
            this.bunifuTextBox2.AcceptsReturn = false;
            this.bunifuTextBox2.AcceptsTab = false;
            this.bunifuTextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuTextBox2.AnimationSpeed = 200;
            this.bunifuTextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox2.BackgroundImage")));
            this.bunifuTextBox2.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox2.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.bunifuTextBox2.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox2.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuTextBox2.BorderRadius = 30;
            this.bunifuTextBox2.BorderThickness = 2;
            this.bunifuTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox2.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuTextBox2.DefaultText = "";
            this.bunifuTextBox2.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox2.HideSelection = true;
            this.bunifuTextBox2.IconLeft = null;
            this.bunifuTextBox2.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox2.IconPadding = 10;
            this.bunifuTextBox2.IconRight = null;
            this.bunifuTextBox2.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox2.Lines = new string[0];
            this.bunifuTextBox2.Location = new System.Drawing.Point(659, 6);
            this.bunifuTextBox2.MaxLength = 32767;
            this.bunifuTextBox2.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox2.Modified = false;
            this.bunifuTextBox2.Multiline = false;
            this.bunifuTextBox2.Name = "bunifuTextBox2";
            stateProperties41.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties41.FillColor = System.Drawing.Color.Empty;
            stateProperties41.ForeColor = System.Drawing.Color.Empty;
            stateProperties41.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox2.OnActiveState = stateProperties41;
            stateProperties42.BorderColor = System.Drawing.Color.Empty;
            stateProperties42.FillColor = System.Drawing.Color.White;
            stateProperties42.ForeColor = System.Drawing.Color.Empty;
            stateProperties42.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox2.OnDisabledState = stateProperties42;
            stateProperties43.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties43.FillColor = System.Drawing.Color.Empty;
            stateProperties43.ForeColor = System.Drawing.Color.Empty;
            stateProperties43.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox2.OnHoverState = stateProperties43;
            stateProperties44.BorderColor = System.Drawing.Color.Silver;
            stateProperties44.FillColor = System.Drawing.Color.White;
            stateProperties44.ForeColor = System.Drawing.Color.Empty;
            stateProperties44.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox2.OnIdleState = stateProperties44;
            this.bunifuTextBox2.PasswordChar = '\0';
            this.bunifuTextBox2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox2.PlaceholderText = "Search";
            this.bunifuTextBox2.ReadOnly = false;
            this.bunifuTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox2.SelectedText = "";
            this.bunifuTextBox2.SelectionLength = 0;
            this.bunifuTextBox2.SelectionStart = 0;
            this.bunifuTextBox2.ShortcutsEnabled = true;
            this.bunifuTextBox2.Size = new System.Drawing.Size(200, 35);
            this.bunifuTextBox2.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox2.TabIndex = 12;
            this.bunifuTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox2.TextMarginBottom = 0;
            this.bunifuTextBox2.TextMarginLeft = 5;
            this.bunifuTextBox2.TextMarginTop = 0;
            this.bunifuTextBox2.TextPlaceholder = "Search";
            this.bunifuTextBox2.UseSystemPasswordChar = false;
            this.bunifuTextBox2.WordWrap = true;
            // 
            // loanrefresh
            // 
            this.loanrefresh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("loanrefresh.BackgroundImage")));
            this.loanrefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.loanrefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loanrefresh.Location = new System.Drawing.Point(6, 19);
            this.loanrefresh.Name = "loanrefresh";
            this.loanrefresh.Size = new System.Drawing.Size(48, 23);
            this.loanrefresh.TabIndex = 10;
            this.loanrefresh.UseVisualStyleBackColor = true;
            this.loanrefresh.Click += new System.EventHandler(this.loanrefresh_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView4.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.dataGridView4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView4.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView4.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridView4.ColumnHeadersHeight = 30;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.g1,
            this.g2,
            this.g3,
            this.g4,
            this.g5,
            this.g6,
            this.g7});
            this.dataGridView4.EnableHeadersVisualStyles = false;
            this.dataGridView4.GridColor = System.Drawing.Color.DarkGray;
            this.dataGridView4.Location = new System.Drawing.Point(4, 46);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersVisible = false;
            this.dataGridView4.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView4.Size = new System.Drawing.Size(855, 334);
            this.dataGridView4.TabIndex = 9;
            this.dataGridView4.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView4_CellMouseUp);
            this.dataGridView4.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellValueChanged);
            // 
            // g1
            // 
            this.g1.HeaderText = "Name";
            this.g1.Name = "g1";
            // 
            // g2
            // 
            this.g2.HeaderText = "Phon. No";
            this.g2.Name = "g2";
            // 
            // g3
            // 
            this.g3.HeaderText = "title";
            this.g3.Name = "g3";
            // 
            // g4
            // 
            this.g4.HeaderText = "Loan";
            this.g4.Name = "g4";
            // 
            // g5
            // 
            this.g5.HeaderText = "Give";
            this.g5.Name = "g5";
            // 
            // g6
            // 
            this.g6.HeaderText = "Remaning";
            this.g6.Name = "g6";
            // 
            // g7
            // 
            this.g7.HeaderText = "id";
            this.g7.Name = "g7";
            this.g7.ReadOnly = true;
            this.g7.Visible = false;
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.naerror);
            this.tabPage18.Controls.Add(this.giveerror);
            this.tabPage18.Controls.Add(this.loanerror);
            this.tabPage18.Controls.Add(this.noerror);
            this.tabPage18.Controls.Add(this.pictureBox2);
            this.tabPage18.Controls.Add(this.remaning);
            this.tabPage18.Controls.Add(this.label21);
            this.tabPage18.Controls.Add(this.bunifuButton9);
            this.tabPage18.Controls.Add(this.label20);
            this.tabPage18.Controls.Add(this.label19);
            this.tabPage18.Controls.Add(this.label18);
            this.tabPage18.Controls.Add(this.label17);
            this.tabPage18.Controls.Add(this.label16);
            this.tabPage18.Controls.Add(this.gt4);
            this.tabPage18.Controls.Add(this.gt2);
            this.tabPage18.Controls.Add(this.gt5);
            this.tabPage18.Controls.Add(this.gt3);
            this.tabPage18.Controls.Add(this.gt1);
            this.tabPage18.Location = new System.Drawing.Point(4, 4);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage18.Size = new System.Drawing.Size(862, 383);
            this.tabPage18.TabIndex = 2;
            this.tabPage18.Text = "add_give";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // naerror
            // 
            this.naerror.AutoSize = true;
            this.naerror.ForeColor = System.Drawing.Color.Red;
            this.naerror.Location = new System.Drawing.Point(129, 112);
            this.naerror.Name = "naerror";
            this.naerror.Size = new System.Drawing.Size(110, 13);
            this.naerror.TabIndex = 30;
            this.naerror.Text = "Please input Alphabet";
            this.naerror.Visible = false;
            // 
            // giveerror
            // 
            this.giveerror.AutoSize = true;
            this.giveerror.ForeColor = System.Drawing.Color.Red;
            this.giveerror.Location = new System.Drawing.Point(129, 276);
            this.giveerror.Name = "giveerror";
            this.giveerror.Size = new System.Drawing.Size(110, 13);
            this.giveerror.TabIndex = 30;
            this.giveerror.Text = "Do not input Alphabet";
            this.giveerror.Visible = false;
            // 
            // loanerror
            // 
            this.loanerror.AutoSize = true;
            this.loanerror.ForeColor = System.Drawing.Color.Red;
            this.loanerror.Location = new System.Drawing.Point(538, 189);
            this.loanerror.Name = "loanerror";
            this.loanerror.Size = new System.Drawing.Size(110, 13);
            this.loanerror.TabIndex = 29;
            this.loanerror.Text = "Do not input Alphabet";
            this.loanerror.Visible = false;
            // 
            // noerror
            // 
            this.noerror.AutoSize = true;
            this.noerror.ForeColor = System.Drawing.Color.Red;
            this.noerror.Location = new System.Drawing.Point(538, 112);
            this.noerror.Name = "noerror";
            this.noerror.Size = new System.Drawing.Size(150, 13);
            this.noerror.TabIndex = 28;
            this.noerror.Text = "Intput Digits example(01234...)";
            this.noerror.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(58, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 27;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // remaning
            // 
            this.remaning.AutoSize = true;
            this.remaning.Font = new System.Drawing.Font("Arial Narrow", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remaning.Location = new System.Drawing.Point(626, 247);
            this.remaning.Name = "remaning";
            this.remaning.Size = new System.Drawing.Size(54, 20);
            this.remaning.TabIndex = 7;
            this.remaning.Text = "00.0000";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Narrow", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(501, 238);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(119, 31);
            this.label21.TabIndex = 7;
            this.label21.Text = "Remaning ";
            // 
            // bunifuButton9
            // 
            this.bunifuButton9.AllowToggling = false;
            this.bunifuButton9.AnimationSpeed = 200;
            this.bunifuButton9.AutoGenerateColors = false;
            this.bunifuButton9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton9.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton9.BackgroundImage")));
            this.bunifuButton9.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton9.ButtonText = "Done";
            this.bunifuButton9.ButtonTextMarginLeft = 0;
            this.bunifuButton9.ColorContrastOnClick = 45;
            this.bunifuButton9.ColorContrastOnHover = 45;
            this.bunifuButton9.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges14.BottomLeft = true;
            borderEdges14.BottomRight = true;
            borderEdges14.TopLeft = true;
            borderEdges14.TopRight = true;
            this.bunifuButton9.CustomizableEdges = borderEdges14;
            this.bunifuButton9.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton9.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton9.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton9.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton9.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton9.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton9.ForeColor = System.Drawing.Color.White;
            this.bunifuButton9.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton9.IconMarginLeft = 11;
            this.bunifuButton9.IconPadding = 10;
            this.bunifuButton9.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton9.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton9.IdleBorderRadius = 30;
            this.bunifuButton9.IdleBorderThickness = 1;
            this.bunifuButton9.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton9.IdleIconLeftImage = null;
            this.bunifuButton9.IdleIconRightImage = null;
            this.bunifuButton9.IndicateFocus = false;
            this.bunifuButton9.Location = new System.Drawing.Point(635, 305);
            this.bunifuButton9.Name = "bunifuButton9";
            this.bunifuButton9.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton9.onHoverState.BorderRadius = 30;
            this.bunifuButton9.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton9.onHoverState.BorderThickness = 1;
            this.bunifuButton9.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton9.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton9.onHoverState.IconLeftImage = null;
            this.bunifuButton9.onHoverState.IconRightImage = null;
            this.bunifuButton9.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton9.OnIdleState.BorderRadius = 30;
            this.bunifuButton9.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton9.OnIdleState.BorderThickness = 1;
            this.bunifuButton9.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton9.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton9.OnIdleState.IconLeftImage = null;
            this.bunifuButton9.OnIdleState.IconRightImage = null;
            this.bunifuButton9.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton9.OnPressedState.BorderRadius = 30;
            this.bunifuButton9.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton9.OnPressedState.BorderThickness = 1;
            this.bunifuButton9.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton9.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton9.OnPressedState.IconLeftImage = null;
            this.bunifuButton9.OnPressedState.IconRightImage = null;
            this.bunifuButton9.Size = new System.Drawing.Size(119, 35);
            this.bunifuButton9.TabIndex = 5;
            this.bunifuButton9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton9.TextMarginLeft = 0;
            this.bunifuButton9.UseDefaultRadiusAndThickness = true;
            this.bunifuButton9.Click += new System.EventHandler(this.bunifuButton9_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(538, 135);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 13);
            this.label20.TabIndex = 5;
            this.label20.Text = "Loan";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(538, 54);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 13);
            this.label19.TabIndex = 5;
            this.label19.Text = "Phone";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(129, 222);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 13);
            this.label18.TabIndex = 5;
            this.label18.Text = "Give Money";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(129, 135);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(27, 13);
            this.label17.TabIndex = 5;
            this.label17.Text = "Title";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(129, 54);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 13);
            this.label16.TabIndex = 5;
            this.label16.Text = "Name";
            // 
            // gt4
            // 
            this.gt4.AcceptsReturn = false;
            this.gt4.AcceptsTab = false;
            this.gt4.AnimationSpeed = 200;
            this.gt4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.gt4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.gt4.BackColor = System.Drawing.Color.Transparent;
            this.gt4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gt4.BackgroundImage")));
            this.gt4.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.gt4.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.gt4.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.gt4.BorderColorIdle = System.Drawing.Color.DimGray;
            this.gt4.BorderRadius = 30;
            this.gt4.BorderThickness = 2;
            this.gt4.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.gt4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gt4.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.gt4.DefaultText = "";
            this.gt4.FillColor = System.Drawing.Color.White;
            this.gt4.HideSelection = true;
            this.gt4.IconLeft = null;
            this.gt4.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.gt4.IconPadding = 10;
            this.gt4.IconRight = null;
            this.gt4.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.gt4.Lines = new string[0];
            this.gt4.Location = new System.Drawing.Point(523, 151);
            this.gt4.MaxLength = 32767;
            this.gt4.MinimumSize = new System.Drawing.Size(1, 1);
            this.gt4.Modified = false;
            this.gt4.Multiline = false;
            this.gt4.Name = "gt4";
            stateProperties45.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties45.FillColor = System.Drawing.Color.Empty;
            stateProperties45.ForeColor = System.Drawing.Color.Empty;
            stateProperties45.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt4.OnActiveState = stateProperties45;
            stateProperties46.BorderColor = System.Drawing.Color.Empty;
            stateProperties46.FillColor = System.Drawing.Color.White;
            stateProperties46.ForeColor = System.Drawing.Color.Empty;
            stateProperties46.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.gt4.OnDisabledState = stateProperties46;
            stateProperties47.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties47.FillColor = System.Drawing.Color.Empty;
            stateProperties47.ForeColor = System.Drawing.Color.Empty;
            stateProperties47.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt4.OnHoverState = stateProperties47;
            stateProperties48.BorderColor = System.Drawing.Color.DimGray;
            stateProperties48.FillColor = System.Drawing.Color.White;
            stateProperties48.ForeColor = System.Drawing.Color.Empty;
            stateProperties48.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt4.OnIdleState = stateProperties48;
            this.gt4.PasswordChar = '\0';
            this.gt4.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.gt4.PlaceholderText = "";
            this.gt4.ReadOnly = false;
            this.gt4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.gt4.SelectedText = "";
            this.gt4.SelectionLength = 0;
            this.gt4.SelectionStart = 0;
            this.gt4.ShortcutsEnabled = true;
            this.gt4.Size = new System.Drawing.Size(231, 35);
            this.gt4.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.gt4.TabIndex = 3;
            this.gt4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.gt4.TextMarginBottom = 0;
            this.gt4.TextMarginLeft = 5;
            this.gt4.TextMarginTop = 0;
            this.gt4.TextPlaceholder = "";
            this.gt4.UseSystemPasswordChar = false;
            this.gt4.WordWrap = true;
            this.gt4.TextChanged += new System.EventHandler(this.gt4_TextChanged);
            // 
            // gt2
            // 
            this.gt2.AcceptsReturn = false;
            this.gt2.AcceptsTab = false;
            this.gt2.AnimationSpeed = 200;
            this.gt2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.gt2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.gt2.BackColor = System.Drawing.Color.Transparent;
            this.gt2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gt2.BackgroundImage")));
            this.gt2.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.gt2.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.gt2.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.gt2.BorderColorIdle = System.Drawing.Color.DimGray;
            this.gt2.BorderRadius = 30;
            this.gt2.BorderThickness = 2;
            this.gt2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.gt2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gt2.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.gt2.DefaultText = "";
            this.gt2.FillColor = System.Drawing.Color.White;
            this.gt2.HideSelection = true;
            this.gt2.IconLeft = null;
            this.gt2.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.gt2.IconPadding = 10;
            this.gt2.IconRight = null;
            this.gt2.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.gt2.Lines = new string[0];
            this.gt2.Location = new System.Drawing.Point(523, 74);
            this.gt2.MaxLength = 32767;
            this.gt2.MinimumSize = new System.Drawing.Size(1, 1);
            this.gt2.Modified = false;
            this.gt2.Multiline = false;
            this.gt2.Name = "gt2";
            stateProperties49.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties49.FillColor = System.Drawing.Color.Empty;
            stateProperties49.ForeColor = System.Drawing.Color.Empty;
            stateProperties49.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt2.OnActiveState = stateProperties49;
            stateProperties50.BorderColor = System.Drawing.Color.Empty;
            stateProperties50.FillColor = System.Drawing.Color.White;
            stateProperties50.ForeColor = System.Drawing.Color.Empty;
            stateProperties50.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.gt2.OnDisabledState = stateProperties50;
            stateProperties51.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties51.FillColor = System.Drawing.Color.Empty;
            stateProperties51.ForeColor = System.Drawing.Color.Empty;
            stateProperties51.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt2.OnHoverState = stateProperties51;
            stateProperties52.BorderColor = System.Drawing.Color.DimGray;
            stateProperties52.FillColor = System.Drawing.Color.White;
            stateProperties52.ForeColor = System.Drawing.Color.Empty;
            stateProperties52.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt2.OnIdleState = stateProperties52;
            this.gt2.PasswordChar = '\0';
            this.gt2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.gt2.PlaceholderText = "";
            this.gt2.ReadOnly = false;
            this.gt2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.gt2.SelectedText = "";
            this.gt2.SelectionLength = 0;
            this.gt2.SelectionStart = 0;
            this.gt2.ShortcutsEnabled = true;
            this.gt2.Size = new System.Drawing.Size(231, 35);
            this.gt2.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.gt2.TabIndex = 1;
            this.gt2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.gt2.TextMarginBottom = 0;
            this.gt2.TextMarginLeft = 5;
            this.gt2.TextMarginTop = 0;
            this.gt2.TextPlaceholder = "";
            this.gt2.UseSystemPasswordChar = false;
            this.gt2.WordWrap = true;
            this.gt2.TextChanged += new System.EventHandler(this.gt2_TextChanged);
            // 
            // gt5
            // 
            this.gt5.AcceptsReturn = false;
            this.gt5.AcceptsTab = false;
            this.gt5.AnimationSpeed = 200;
            this.gt5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.gt5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.gt5.BackColor = System.Drawing.Color.Transparent;
            this.gt5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gt5.BackgroundImage")));
            this.gt5.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.gt5.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.gt5.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.gt5.BorderColorIdle = System.Drawing.Color.DimGray;
            this.gt5.BorderRadius = 30;
            this.gt5.BorderThickness = 2;
            this.gt5.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.gt5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gt5.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.gt5.DefaultText = "";
            this.gt5.FillColor = System.Drawing.Color.White;
            this.gt5.HideSelection = true;
            this.gt5.IconLeft = null;
            this.gt5.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.gt5.IconPadding = 10;
            this.gt5.IconRight = null;
            this.gt5.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.gt5.Lines = new string[0];
            this.gt5.Location = new System.Drawing.Point(117, 238);
            this.gt5.MaxLength = 32767;
            this.gt5.MinimumSize = new System.Drawing.Size(1, 1);
            this.gt5.Modified = false;
            this.gt5.Multiline = false;
            this.gt5.Name = "gt5";
            stateProperties53.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties53.FillColor = System.Drawing.Color.Empty;
            stateProperties53.ForeColor = System.Drawing.Color.Empty;
            stateProperties53.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt5.OnActiveState = stateProperties53;
            stateProperties54.BorderColor = System.Drawing.Color.Empty;
            stateProperties54.FillColor = System.Drawing.Color.White;
            stateProperties54.ForeColor = System.Drawing.Color.Empty;
            stateProperties54.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.gt5.OnDisabledState = stateProperties54;
            stateProperties55.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties55.FillColor = System.Drawing.Color.Empty;
            stateProperties55.ForeColor = System.Drawing.Color.Empty;
            stateProperties55.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt5.OnHoverState = stateProperties55;
            stateProperties56.BorderColor = System.Drawing.Color.DimGray;
            stateProperties56.FillColor = System.Drawing.Color.White;
            stateProperties56.ForeColor = System.Drawing.Color.Empty;
            stateProperties56.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt5.OnIdleState = stateProperties56;
            this.gt5.PasswordChar = '\0';
            this.gt5.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.gt5.PlaceholderText = "";
            this.gt5.ReadOnly = false;
            this.gt5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.gt5.SelectedText = "";
            this.gt5.SelectionLength = 0;
            this.gt5.SelectionStart = 0;
            this.gt5.ShortcutsEnabled = true;
            this.gt5.Size = new System.Drawing.Size(231, 35);
            this.gt5.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.gt5.TabIndex = 4;
            this.gt5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.gt5.TextMarginBottom = 0;
            this.gt5.TextMarginLeft = 5;
            this.gt5.TextMarginTop = 0;
            this.gt5.TextPlaceholder = "";
            this.gt5.UseSystemPasswordChar = false;
            this.gt5.WordWrap = true;
            this.gt5.TextChanged += new System.EventHandler(this.gt5_TextChanged);
            // 
            // gt3
            // 
            this.gt3.AcceptsReturn = false;
            this.gt3.AcceptsTab = false;
            this.gt3.AnimationSpeed = 200;
            this.gt3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.gt3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.gt3.BackColor = System.Drawing.Color.Transparent;
            this.gt3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gt3.BackgroundImage")));
            this.gt3.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.gt3.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.gt3.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.gt3.BorderColorIdle = System.Drawing.Color.DimGray;
            this.gt3.BorderRadius = 30;
            this.gt3.BorderThickness = 2;
            this.gt3.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.gt3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gt3.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.gt3.DefaultText = "";
            this.gt3.FillColor = System.Drawing.Color.White;
            this.gt3.HideSelection = true;
            this.gt3.IconLeft = null;
            this.gt3.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.gt3.IconPadding = 10;
            this.gt3.IconRight = null;
            this.gt3.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.gt3.Lines = new string[0];
            this.gt3.Location = new System.Drawing.Point(117, 151);
            this.gt3.MaxLength = 32767;
            this.gt3.MinimumSize = new System.Drawing.Size(1, 1);
            this.gt3.Modified = false;
            this.gt3.Multiline = false;
            this.gt3.Name = "gt3";
            stateProperties57.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties57.FillColor = System.Drawing.Color.Empty;
            stateProperties57.ForeColor = System.Drawing.Color.Empty;
            stateProperties57.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt3.OnActiveState = stateProperties57;
            stateProperties58.BorderColor = System.Drawing.Color.Empty;
            stateProperties58.FillColor = System.Drawing.Color.White;
            stateProperties58.ForeColor = System.Drawing.Color.Empty;
            stateProperties58.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.gt3.OnDisabledState = stateProperties58;
            stateProperties59.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties59.FillColor = System.Drawing.Color.Empty;
            stateProperties59.ForeColor = System.Drawing.Color.Empty;
            stateProperties59.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt3.OnHoverState = stateProperties59;
            stateProperties60.BorderColor = System.Drawing.Color.DimGray;
            stateProperties60.FillColor = System.Drawing.Color.White;
            stateProperties60.ForeColor = System.Drawing.Color.Empty;
            stateProperties60.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt3.OnIdleState = stateProperties60;
            this.gt3.PasswordChar = '\0';
            this.gt3.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.gt3.PlaceholderText = "";
            this.gt3.ReadOnly = false;
            this.gt3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.gt3.SelectedText = "";
            this.gt3.SelectionLength = 0;
            this.gt3.SelectionStart = 0;
            this.gt3.ShortcutsEnabled = true;
            this.gt3.Size = new System.Drawing.Size(231, 35);
            this.gt3.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.gt3.TabIndex = 2;
            this.gt3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.gt3.TextMarginBottom = 0;
            this.gt3.TextMarginLeft = 5;
            this.gt3.TextMarginTop = 0;
            this.gt3.TextPlaceholder = "";
            this.gt3.UseSystemPasswordChar = false;
            this.gt3.WordWrap = true;
            this.gt3.TextChanged += new System.EventHandler(this.gt3_TextChanged);
            // 
            // gt1
            // 
            this.gt1.AcceptsReturn = false;
            this.gt1.AcceptsTab = false;
            this.gt1.AnimationSpeed = 200;
            this.gt1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.gt1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.gt1.BackColor = System.Drawing.Color.Transparent;
            this.gt1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gt1.BackgroundImage")));
            this.gt1.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.gt1.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.gt1.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.gt1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.gt1.BorderRadius = 30;
            this.gt1.BorderThickness = 2;
            this.gt1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.gt1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.gt1.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.gt1.DefaultText = "";
            this.gt1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gt1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.gt1.HideSelection = true;
            this.gt1.IconLeft = null;
            this.gt1.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.gt1.IconPadding = 10;
            this.gt1.IconRight = null;
            this.gt1.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.gt1.Lines = new string[0];
            this.gt1.Location = new System.Drawing.Point(117, 74);
            this.gt1.MaxLength = 32767;
            this.gt1.MinimumSize = new System.Drawing.Size(1, 1);
            this.gt1.Modified = false;
            this.gt1.Multiline = false;
            this.gt1.Name = "gt1";
            stateProperties61.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties61.FillColor = System.Drawing.Color.Empty;
            stateProperties61.ForeColor = System.Drawing.Color.Empty;
            stateProperties61.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt1.OnActiveState = stateProperties61;
            stateProperties62.BorderColor = System.Drawing.Color.Empty;
            stateProperties62.FillColor = System.Drawing.Color.White;
            stateProperties62.ForeColor = System.Drawing.Color.Empty;
            stateProperties62.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.gt1.OnDisabledState = stateProperties62;
            stateProperties63.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties63.FillColor = System.Drawing.Color.Empty;
            stateProperties63.ForeColor = System.Drawing.Color.Empty;
            stateProperties63.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt1.OnHoverState = stateProperties63;
            stateProperties64.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties64.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            stateProperties64.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            stateProperties64.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.gt1.OnIdleState = stateProperties64;
            this.gt1.PasswordChar = '\0';
            this.gt1.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gt1.PlaceholderText = "";
            this.gt1.ReadOnly = false;
            this.gt1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.gt1.SelectedText = "";
            this.gt1.SelectionLength = 0;
            this.gt1.SelectionStart = 0;
            this.gt1.ShortcutsEnabled = true;
            this.gt1.Size = new System.Drawing.Size(231, 35);
            this.gt1.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.gt1.TabIndex = 0;
            this.gt1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.gt1.TextMarginBottom = 0;
            this.gt1.TextMarginLeft = 5;
            this.gt1.TextMarginTop = 0;
            this.gt1.TextPlaceholder = "";
            this.gt1.UseSystemPasswordChar = false;
            this.gt1.WordWrap = true;
            this.gt1.TextChanged += new System.EventHandler(this.gt1_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(112, 35);
            this.label5.TabIndex = 1;
            this.label5.Text = "Payment";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.label34);
            this.tabPage6.Controls.Add(this.cb1);
            this.tabPage6.Controls.Add(this.userimage);
            this.tabPage6.Controls.Add(this.bunifuButton3);
            this.tabPage6.Controls.Add(this.bunifuSeparator11);
            this.tabPage6.Controls.Add(this.bunifuSeparator2);
            this.tabPage6.Controls.Add(this.bunifuButton10);
            this.tabPage6.Controls.Add(this.ut2);
            this.tabPage6.Controls.Add(this.ut1);
            this.tabPage6.Controls.Add(this.label25);
            this.tabPage6.Controls.Add(this.label26);
            this.tabPage6.Controls.Add(this.label24);
            this.tabPage6.Controls.Add(this.label7);
            this.tabPage6.Location = new System.Drawing.Point(4, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(876, 519);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "setting";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // userimage
            // 
            this.userimage.Image = ((System.Drawing.Image)(resources.GetObject("userimage.Image")));
            this.userimage.Location = new System.Drawing.Point(24, 154);
            this.userimage.Name = "userimage";
            this.userimage.Size = new System.Drawing.Size(177, 154);
            this.userimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.userimage.TabIndex = 20;
            this.userimage.TabStop = false;
            // 
            // bunifuButton3
            // 
            this.bunifuButton3.AllowToggling = false;
            this.bunifuButton3.AnimationSpeed = 200;
            this.bunifuButton3.AutoGenerateColors = false;
            this.bunifuButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton3.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton3.BackgroundImage")));
            this.bunifuButton3.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.ButtonText = "Change image";
            this.bunifuButton3.ButtonTextMarginLeft = 0;
            this.bunifuButton3.ColorContrastOnClick = 45;
            this.bunifuButton3.ColorContrastOnHover = 45;
            this.bunifuButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges15.BottomLeft = true;
            borderEdges15.BottomRight = true;
            borderEdges15.TopLeft = true;
            borderEdges15.TopRight = true;
            this.bunifuButton3.CustomizableEdges = borderEdges15;
            this.bunifuButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton3.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton3.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton3.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton3.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton3.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton3.IconMarginLeft = 11;
            this.bunifuButton3.IconPadding = 10;
            this.bunifuButton3.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton3.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton3.IdleBorderRadius = 30;
            this.bunifuButton3.IdleBorderThickness = 1;
            this.bunifuButton3.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton3.IdleIconLeftImage = null;
            this.bunifuButton3.IdleIconRightImage = null;
            this.bunifuButton3.IndicateFocus = false;
            this.bunifuButton3.Location = new System.Drawing.Point(201, 234);
            this.bunifuButton3.Name = "bunifuButton3";
            this.bunifuButton3.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton3.onHoverState.BorderRadius = 30;
            this.bunifuButton3.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.onHoverState.BorderThickness = 1;
            this.bunifuButton3.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton3.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.onHoverState.IconLeftImage = null;
            this.bunifuButton3.onHoverState.IconRightImage = null;
            this.bunifuButton3.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton3.OnIdleState.BorderRadius = 30;
            this.bunifuButton3.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.OnIdleState.BorderThickness = 1;
            this.bunifuButton3.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton3.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.OnIdleState.IconLeftImage = null;
            this.bunifuButton3.OnIdleState.IconRightImage = null;
            this.bunifuButton3.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton3.OnPressedState.BorderRadius = 30;
            this.bunifuButton3.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton3.OnPressedState.BorderThickness = 1;
            this.bunifuButton3.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton3.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton3.OnPressedState.IconLeftImage = null;
            this.bunifuButton3.OnPressedState.IconRightImage = null;
            this.bunifuButton3.Size = new System.Drawing.Size(110, 35);
            this.bunifuButton3.TabIndex = 19;
            this.bunifuButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton3.TextMarginLeft = 0;
            this.bunifuButton3.UseDefaultRadiusAndThickness = true;
            this.bunifuButton3.Click += new System.EventHandler(this.bunifuButton3_Click);
            // 
            // bunifuSeparator11
            // 
            this.bunifuSeparator11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator11.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator11.LineThickness = 1;
            this.bunifuSeparator11.Location = new System.Drawing.Point(20, 39);
            this.bunifuSeparator11.Name = "bunifuSeparator11";
            this.bunifuSeparator11.Size = new System.Drawing.Size(50, 10);
            this.bunifuSeparator11.TabIndex = 17;
            this.bunifuSeparator11.Transparency = 255;
            this.bunifuSeparator11.Vertical = false;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(13, 85);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(844, 8);
            this.bunifuSeparator2.TabIndex = 9;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // bunifuButton10
            // 
            this.bunifuButton10.AllowToggling = false;
            this.bunifuButton10.AnimationSpeed = 200;
            this.bunifuButton10.AutoGenerateColors = false;
            this.bunifuButton10.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton10.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton10.BackgroundImage")));
            this.bunifuButton10.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton10.ButtonText = "Save Changes";
            this.bunifuButton10.ButtonTextMarginLeft = 0;
            this.bunifuButton10.ColorContrastOnClick = 45;
            this.bunifuButton10.ColorContrastOnHover = 45;
            this.bunifuButton10.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges16.BottomLeft = true;
            borderEdges16.BottomRight = true;
            borderEdges16.TopLeft = true;
            borderEdges16.TopRight = true;
            this.bunifuButton10.CustomizableEdges = borderEdges16;
            this.bunifuButton10.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton10.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton10.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton10.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton10.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton10.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton10.ForeColor = System.Drawing.Color.White;
            this.bunifuButton10.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton10.IconMarginLeft = 11;
            this.bunifuButton10.IconPadding = 10;
            this.bunifuButton10.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton10.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton10.IdleBorderRadius = 30;
            this.bunifuButton10.IdleBorderThickness = 1;
            this.bunifuButton10.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton10.IdleIconLeftImage = null;
            this.bunifuButton10.IdleIconRightImage = null;
            this.bunifuButton10.IndicateFocus = false;
            this.bunifuButton10.Location = new System.Drawing.Point(24, 415);
            this.bunifuButton10.Name = "bunifuButton10";
            this.bunifuButton10.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton10.onHoverState.BorderRadius = 30;
            this.bunifuButton10.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton10.onHoverState.BorderThickness = 1;
            this.bunifuButton10.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton10.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton10.onHoverState.IconLeftImage = null;
            this.bunifuButton10.onHoverState.IconRightImage = null;
            this.bunifuButton10.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton10.OnIdleState.BorderRadius = 30;
            this.bunifuButton10.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton10.OnIdleState.BorderThickness = 1;
            this.bunifuButton10.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton10.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton10.OnIdleState.IconLeftImage = null;
            this.bunifuButton10.OnIdleState.IconRightImage = null;
            this.bunifuButton10.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton10.OnPressedState.BorderRadius = 30;
            this.bunifuButton10.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton10.OnPressedState.BorderThickness = 1;
            this.bunifuButton10.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton10.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton10.OnPressedState.IconLeftImage = null;
            this.bunifuButton10.OnPressedState.IconRightImage = null;
            this.bunifuButton10.Size = new System.Drawing.Size(110, 35);
            this.bunifuButton10.TabIndex = 2;
            this.bunifuButton10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton10.TextMarginLeft = 0;
            this.bunifuButton10.UseDefaultRadiusAndThickness = true;
            this.bunifuButton10.Click += new System.EventHandler(this.bunifuButton10_Click);
            // 
            // ut2
            // 
            this.ut2.AcceptsReturn = false;
            this.ut2.AcceptsTab = false;
            this.ut2.AnimationSpeed = 200;
            this.ut2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.ut2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.ut2.BackColor = System.Drawing.Color.Transparent;
            this.ut2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ut2.BackgroundImage")));
            this.ut2.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.ut2.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.ut2.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.ut2.BorderColorIdle = System.Drawing.Color.DimGray;
            this.ut2.BorderRadius = 30;
            this.ut2.BorderThickness = 2;
            this.ut2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.ut2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ut2.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.ut2.DefaultText = "";
            this.ut2.FillColor = System.Drawing.Color.White;
            this.ut2.HideSelection = true;
            this.ut2.IconLeft = null;
            this.ut2.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.ut2.IconPadding = 10;
            this.ut2.IconRight = null;
            this.ut2.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.ut2.Lines = new string[0];
            this.ut2.Location = new System.Drawing.Point(230, 343);
            this.ut2.MaxLength = 32767;
            this.ut2.MinimumSize = new System.Drawing.Size(1, 1);
            this.ut2.Modified = false;
            this.ut2.Multiline = false;
            this.ut2.Name = "ut2";
            stateProperties65.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties65.FillColor = System.Drawing.Color.Empty;
            stateProperties65.ForeColor = System.Drawing.Color.Empty;
            stateProperties65.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ut2.OnActiveState = stateProperties65;
            stateProperties66.BorderColor = System.Drawing.Color.Empty;
            stateProperties66.FillColor = System.Drawing.Color.White;
            stateProperties66.ForeColor = System.Drawing.Color.Empty;
            stateProperties66.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.ut2.OnDisabledState = stateProperties66;
            stateProperties67.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties67.FillColor = System.Drawing.Color.Empty;
            stateProperties67.ForeColor = System.Drawing.Color.Empty;
            stateProperties67.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ut2.OnHoverState = stateProperties67;
            stateProperties68.BorderColor = System.Drawing.Color.DimGray;
            stateProperties68.FillColor = System.Drawing.Color.White;
            stateProperties68.ForeColor = System.Drawing.Color.Empty;
            stateProperties68.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ut2.OnIdleState = stateProperties68;
            this.ut2.PasswordChar = '●';
            this.ut2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.ut2.PlaceholderText = "";
            this.ut2.ReadOnly = false;
            this.ut2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.ut2.SelectedText = "";
            this.ut2.SelectionLength = 0;
            this.ut2.SelectionStart = 0;
            this.ut2.ShortcutsEnabled = true;
            this.ut2.Size = new System.Drawing.Size(200, 35);
            this.ut2.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.ut2.TabIndex = 1;
            this.ut2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.ut2.TextMarginBottom = 0;
            this.ut2.TextMarginLeft = 5;
            this.ut2.TextMarginTop = 0;
            this.ut2.TextPlaceholder = "";
            this.ut2.UseSystemPasswordChar = true;
            this.ut2.WordWrap = true;
            // 
            // ut1
            // 
            this.ut1.AcceptsReturn = false;
            this.ut1.AcceptsTab = false;
            this.ut1.AnimationSpeed = 200;
            this.ut1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.ut1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.ut1.BackColor = System.Drawing.Color.Transparent;
            this.ut1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ut1.BackgroundImage")));
            this.ut1.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.ut1.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.ut1.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.ut1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.ut1.BorderRadius = 30;
            this.ut1.BorderThickness = 2;
            this.ut1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.ut1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ut1.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.ut1.DefaultText = "";
            this.ut1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ut1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ut1.HideSelection = true;
            this.ut1.IconLeft = null;
            this.ut1.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.ut1.IconPadding = 10;
            this.ut1.IconRight = null;
            this.ut1.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.ut1.Lines = new string[0];
            this.ut1.Location = new System.Drawing.Point(24, 343);
            this.ut1.MaxLength = 32767;
            this.ut1.MinimumSize = new System.Drawing.Size(1, 1);
            this.ut1.Modified = false;
            this.ut1.Multiline = false;
            this.ut1.Name = "ut1";
            stateProperties69.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties69.FillColor = System.Drawing.Color.Empty;
            stateProperties69.ForeColor = System.Drawing.Color.Empty;
            stateProperties69.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ut1.OnActiveState = stateProperties69;
            stateProperties70.BorderColor = System.Drawing.Color.Empty;
            stateProperties70.FillColor = System.Drawing.Color.White;
            stateProperties70.ForeColor = System.Drawing.Color.Empty;
            stateProperties70.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.ut1.OnDisabledState = stateProperties70;
            stateProperties71.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties71.FillColor = System.Drawing.Color.Empty;
            stateProperties71.ForeColor = System.Drawing.Color.Empty;
            stateProperties71.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ut1.OnHoverState = stateProperties71;
            stateProperties72.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties72.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            stateProperties72.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            stateProperties72.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.ut1.OnIdleState = stateProperties72;
            this.ut1.PasswordChar = '\0';
            this.ut1.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ut1.PlaceholderText = "";
            this.ut1.ReadOnly = false;
            this.ut1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.ut1.SelectedText = "";
            this.ut1.SelectionLength = 0;
            this.ut1.SelectionStart = 0;
            this.ut1.ShortcutsEnabled = true;
            this.ut1.Size = new System.Drawing.Size(200, 35);
            this.ut1.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.ut1.TabIndex = 0;
            this.ut1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.ut1.TextMarginBottom = 0;
            this.ut1.TextMarginLeft = 5;
            this.ut1.TextMarginTop = 0;
            this.ut1.TextPlaceholder = "";
            this.ut1.UseSystemPasswordChar = false;
            this.ut1.WordWrap = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(227, 321);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 13);
            this.label25.TabIndex = 6;
            this.label25.Text = "Password";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(6, 105);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(354, 32);
            this.label26.TabIndex = 7;
            this.label26.Text = "Change User and Password";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(32, 321);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 13);
            this.label24.TabIndex = 8;
            this.label24.Text = "Username";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 35);
            this.label7.TabIndex = 2;
            this.label7.Text = "Setting";
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.bunifuSeparator12);
            this.tabPage13.Controls.Add(this.profiterror);
            this.tabPage13.Controls.Add(this.nameerror);
            this.tabPage13.Controls.Add(this.priceerror);
            this.tabPage13.Controls.Add(this.qtyerror);
            this.tabPage13.Controls.Add(this.pictureBox1);
            this.tabPage13.Controls.Add(this.label15);
            this.tabPage13.Controls.Add(this.label8);
            this.tabPage13.Controls.Add(this.expirypicker);
            this.tabPage13.Controls.Add(this.bunifuButton6);
            this.tabPage13.Controls.Add(this.label9);
            this.tabPage13.Controls.Add(this.label10);
            this.tabPage13.Controls.Add(this.total);
            this.tabPage13.Controls.Add(this.label11);
            this.tabPage13.Controls.Add(this.label12);
            this.tabPage13.Controls.Add(this.label13);
            this.tabPage13.Controls.Add(this.label14);
            this.tabPage13.Controls.Add(this.t5);
            this.tabPage13.Controls.Add(this.t3);
            this.tabPage13.Controls.Add(this.t4);
            this.tabPage13.Controls.Add(this.t2);
            this.tabPage13.Controls.Add(this.t1);
            this.tabPage13.Location = new System.Drawing.Point(4, 4);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(876, 519);
            this.tabPage13.TabIndex = 6;
            this.tabPage13.Text = "additeam";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // bunifuSeparator12
            // 
            this.bunifuSeparator12.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator12.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator12.LineThickness = 1;
            this.bunifuSeparator12.Location = new System.Drawing.Point(28, 83);
            this.bunifuSeparator12.Name = "bunifuSeparator12";
            this.bunifuSeparator12.Size = new System.Drawing.Size(66, 10);
            this.bunifuSeparator12.TabIndex = 28;
            this.bunifuSeparator12.Transparency = 255;
            this.bunifuSeparator12.Vertical = false;
            // 
            // profiterror
            // 
            this.profiterror.AutoSize = true;
            this.profiterror.ForeColor = System.Drawing.Color.Red;
            this.profiterror.Location = new System.Drawing.Point(163, 344);
            this.profiterror.Name = "profiterror";
            this.profiterror.Size = new System.Drawing.Size(110, 13);
            this.profiterror.TabIndex = 27;
            this.profiterror.Text = "Do not input Alphabet";
            this.profiterror.Visible = false;
            // 
            // nameerror
            // 
            this.nameerror.AutoSize = true;
            this.nameerror.ForeColor = System.Drawing.Color.Red;
            this.nameerror.Location = new System.Drawing.Point(464, 184);
            this.nameerror.Name = "nameerror";
            this.nameerror.Size = new System.Drawing.Size(110, 13);
            this.nameerror.TabIndex = 27;
            this.nameerror.Text = "Please input Alphabet";
            this.nameerror.Visible = false;
            // 
            // priceerror
            // 
            this.priceerror.AutoSize = true;
            this.priceerror.ForeColor = System.Drawing.Color.Red;
            this.priceerror.Location = new System.Drawing.Point(163, 263);
            this.priceerror.Name = "priceerror";
            this.priceerror.Size = new System.Drawing.Size(110, 13);
            this.priceerror.TabIndex = 27;
            this.priceerror.Text = "Do not input Alphabet";
            this.priceerror.Visible = false;
            // 
            // qtyerror
            // 
            this.qtyerror.AutoSize = true;
            this.qtyerror.ForeColor = System.Drawing.Color.Red;
            this.qtyerror.Location = new System.Drawing.Point(464, 263);
            this.qtyerror.Name = "qtyerror";
            this.qtyerror.Size = new System.Drawing.Size(150, 13);
            this.qtyerror.TabIndex = 27;
            this.qtyerror.Text = "Intput Digits example(01234...)";
            this.qtyerror.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(58, 35);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 26;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial Narrow", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(6, 49);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(128, 35);
            this.label15.TabIndex = 25;
            this.label15.Text = "Add Iteam";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Narrow", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(146, 395);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 31);
            this.label8.TabIndex = 24;
            this.label8.Text = "Sel Price";
            // 
            // expirypicker
            // 
            this.expirypicker.BorderRadius = 13;
            this.expirypicker.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.expirypicker.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thick;
            this.expirypicker.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.expirypicker.DisabledColor = System.Drawing.Color.Gray;
            this.expirypicker.DisplayWeekNumbers = false;
            this.expirypicker.DPHeight = 0;
            this.expirypicker.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.expirypicker.FillDatePicker = false;
            this.expirypicker.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.expirypicker.Icon = ((System.Drawing.Image)(resources.GetObject("expirypicker.Icon")));
            this.expirypicker.IconColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.expirypicker.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.expirypicker.Location = new System.Drawing.Point(454, 306);
            this.expirypicker.MinimumSize = new System.Drawing.Size(246, 35);
            this.expirypicker.Name = "expirypicker";
            this.expirypicker.Size = new System.Drawing.Size(246, 35);
            this.expirypicker.TabIndex = 23;
            // 
            // bunifuButton6
            // 
            this.bunifuButton6.AllowToggling = false;
            this.bunifuButton6.AnimationSpeed = 200;
            this.bunifuButton6.AutoGenerateColors = false;
            this.bunifuButton6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton6.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton6.BackgroundImage")));
            this.bunifuButton6.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton6.ButtonText = "Done";
            this.bunifuButton6.ButtonTextMarginLeft = 0;
            this.bunifuButton6.ColorContrastOnClick = 45;
            this.bunifuButton6.ColorContrastOnHover = 45;
            this.bunifuButton6.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges17.BottomLeft = true;
            borderEdges17.BottomRight = true;
            borderEdges17.TopLeft = true;
            borderEdges17.TopRight = true;
            this.bunifuButton6.CustomizableEdges = borderEdges17;
            this.bunifuButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton6.DisabledBorderColor = System.Drawing.Color.Empty;
            this.bunifuButton6.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton6.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton6.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton6.ForeColor = System.Drawing.Color.White;
            this.bunifuButton6.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton6.IconMarginLeft = 11;
            this.bunifuButton6.IconPadding = 10;
            this.bunifuButton6.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton6.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton6.IdleBorderRadius = 35;
            this.bunifuButton6.IdleBorderThickness = 1;
            this.bunifuButton6.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton6.IdleIconLeftImage = null;
            this.bunifuButton6.IdleIconRightImage = null;
            this.bunifuButton6.IndicateFocus = false;
            this.bunifuButton6.Location = new System.Drawing.Point(557, 395);
            this.bunifuButton6.Name = "bunifuButton6";
            this.bunifuButton6.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton6.onHoverState.BorderRadius = 35;
            this.bunifuButton6.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton6.onHoverState.BorderThickness = 1;
            this.bunifuButton6.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton6.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton6.onHoverState.IconLeftImage = null;
            this.bunifuButton6.onHoverState.IconRightImage = null;
            this.bunifuButton6.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton6.OnIdleState.BorderRadius = 35;
            this.bunifuButton6.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton6.OnIdleState.BorderThickness = 1;
            this.bunifuButton6.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton6.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton6.OnIdleState.IconLeftImage = null;
            this.bunifuButton6.OnIdleState.IconRightImage = null;
            this.bunifuButton6.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton6.OnPressedState.BorderRadius = 35;
            this.bunifuButton6.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton6.OnPressedState.BorderThickness = 1;
            this.bunifuButton6.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton6.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton6.OnPressedState.IconLeftImage = null;
            this.bunifuButton6.OnPressedState.IconRightImage = null;
            this.bunifuButton6.Size = new System.Drawing.Size(143, 38);
            this.bunifuButton6.TabIndex = 5;
            this.bunifuButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton6.TextMarginLeft = 0;
            this.bunifuButton6.UseDefaultRadiusAndThickness = true;
            this.bunifuButton6.Click += new System.EventHandler(this.bunifuButton6_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(163, 206);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 16);
            this.label9.TabIndex = 15;
            this.label9.Text = "Price";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(470, 287);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 16);
            this.label10.TabIndex = 16;
            this.label10.Text = "Expiry";
            // 
            // total
            // 
            this.total.AutoSize = true;
            this.total.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total.Location = new System.Drawing.Point(271, 405);
            this.total.Name = "total";
            this.total.Size = new System.Drawing.Size(66, 18);
            this.total.TabIndex = 17;
            this.total.Text = "00.0000";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(163, 288);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 16);
            this.label11.TabIndex = 18;
            this.label11.Text = "Profit";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(470, 206);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(61, 16);
            this.label12.TabIndex = 19;
            this.label12.Text = "Quantity";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(470, 128);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 16);
            this.label13.TabIndex = 20;
            this.label13.Text = "Product Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(163, 128);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 16);
            this.label14.TabIndex = 21;
            this.label14.Text = "Code";
            // 
            // t5
            // 
            this.t5.AcceptsReturn = false;
            this.t5.AcceptsTab = false;
            this.t5.AnimationSpeed = 200;
            this.t5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.t5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.t5.BackColor = System.Drawing.Color.Transparent;
            this.t5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("t5.BackgroundImage")));
            this.t5.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t5.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.t5.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t5.BorderColorIdle = System.Drawing.Color.DimGray;
            this.t5.BorderRadius = 30;
            this.t5.BorderThickness = 2;
            this.t5.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.t5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t5.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.t5.DefaultText = "";
            this.t5.FillColor = System.Drawing.Color.White;
            this.t5.HideSelection = true;
            this.t5.IconLeft = null;
            this.t5.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.t5.IconPadding = 10;
            this.t5.IconRight = null;
            this.t5.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.t5.Lines = new string[0];
            this.t5.Location = new System.Drawing.Point(149, 306);
            this.t5.MaxLength = 32767;
            this.t5.MinimumSize = new System.Drawing.Size(1, 1);
            this.t5.Modified = false;
            this.t5.Multiline = false;
            this.t5.Name = "t5";
            stateProperties73.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties73.FillColor = System.Drawing.Color.Empty;
            stateProperties73.ForeColor = System.Drawing.Color.Empty;
            stateProperties73.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t5.OnActiveState = stateProperties73;
            stateProperties74.BorderColor = System.Drawing.Color.Empty;
            stateProperties74.FillColor = System.Drawing.Color.White;
            stateProperties74.ForeColor = System.Drawing.Color.Empty;
            stateProperties74.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t5.OnDisabledState = stateProperties74;
            stateProperties75.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties75.FillColor = System.Drawing.Color.Empty;
            stateProperties75.ForeColor = System.Drawing.Color.Empty;
            stateProperties75.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t5.OnHoverState = stateProperties75;
            stateProperties76.BorderColor = System.Drawing.Color.DimGray;
            stateProperties76.FillColor = System.Drawing.Color.White;
            stateProperties76.ForeColor = System.Drawing.Color.Empty;
            stateProperties76.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t5.OnIdleState = stateProperties76;
            this.t5.PasswordChar = '\0';
            this.t5.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t5.PlaceholderText = "";
            this.t5.ReadOnly = false;
            this.t5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.t5.SelectedText = "";
            this.t5.SelectionLength = 0;
            this.t5.SelectionStart = 0;
            this.t5.ShortcutsEnabled = true;
            this.t5.Size = new System.Drawing.Size(246, 35);
            this.t5.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.t5.TabIndex = 4;
            this.t5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.t5.TextMarginBottom = 0;
            this.t5.TextMarginLeft = 5;
            this.t5.TextMarginTop = 0;
            this.t5.TextPlaceholder = "";
            this.t5.UseSystemPasswordChar = false;
            this.t5.WordWrap = true;
            this.t5.TextChanged += new System.EventHandler(this.t5_TextChanged);
            // 
            // t3
            // 
            this.t3.AcceptsReturn = false;
            this.t3.AcceptsTab = false;
            this.t3.AnimationSpeed = 200;
            this.t3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.t3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.t3.BackColor = System.Drawing.Color.Transparent;
            this.t3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("t3.BackgroundImage")));
            this.t3.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t3.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.t3.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t3.BorderColorIdle = System.Drawing.Color.DimGray;
            this.t3.BorderRadius = 30;
            this.t3.BorderThickness = 2;
            this.t3.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.t3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t3.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.t3.DefaultText = "";
            this.t3.FillColor = System.Drawing.Color.White;
            this.t3.HideSelection = true;
            this.t3.IconLeft = null;
            this.t3.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.t3.IconPadding = 10;
            this.t3.IconRight = null;
            this.t3.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.t3.Lines = new string[0];
            this.t3.Location = new System.Drawing.Point(149, 224);
            this.t3.MaxLength = 32767;
            this.t3.MinimumSize = new System.Drawing.Size(1, 1);
            this.t3.Modified = false;
            this.t3.Multiline = false;
            this.t3.Name = "t3";
            stateProperties77.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties77.FillColor = System.Drawing.Color.Empty;
            stateProperties77.ForeColor = System.Drawing.Color.Empty;
            stateProperties77.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t3.OnActiveState = stateProperties77;
            stateProperties78.BorderColor = System.Drawing.Color.Empty;
            stateProperties78.FillColor = System.Drawing.Color.White;
            stateProperties78.ForeColor = System.Drawing.Color.Empty;
            stateProperties78.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t3.OnDisabledState = stateProperties78;
            stateProperties79.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties79.FillColor = System.Drawing.Color.Empty;
            stateProperties79.ForeColor = System.Drawing.Color.Empty;
            stateProperties79.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t3.OnHoverState = stateProperties79;
            stateProperties80.BorderColor = System.Drawing.Color.DimGray;
            stateProperties80.FillColor = System.Drawing.Color.White;
            stateProperties80.ForeColor = System.Drawing.Color.Empty;
            stateProperties80.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t3.OnIdleState = stateProperties80;
            this.t3.PasswordChar = '\0';
            this.t3.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t3.PlaceholderText = "";
            this.t3.ReadOnly = false;
            this.t3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.t3.SelectedText = "";
            this.t3.SelectionLength = 0;
            this.t3.SelectionStart = 0;
            this.t3.ShortcutsEnabled = true;
            this.t3.Size = new System.Drawing.Size(246, 35);
            this.t3.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.t3.TabIndex = 2;
            this.t3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.t3.TextMarginBottom = 0;
            this.t3.TextMarginLeft = 5;
            this.t3.TextMarginTop = 0;
            this.t3.TextPlaceholder = "";
            this.t3.UseSystemPasswordChar = false;
            this.t3.WordWrap = true;
            this.t3.TextChanged += new System.EventHandler(this.t3_TextChanged);
            // 
            // t4
            // 
            this.t4.AcceptsReturn = false;
            this.t4.AcceptsTab = false;
            this.t4.AnimationSpeed = 200;
            this.t4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.t4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.t4.BackColor = System.Drawing.Color.Transparent;
            this.t4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("t4.BackgroundImage")));
            this.t4.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t4.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.t4.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t4.BorderColorIdle = System.Drawing.Color.DimGray;
            this.t4.BorderRadius = 30;
            this.t4.BorderThickness = 2;
            this.t4.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.t4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t4.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.t4.DefaultText = "";
            this.t4.FillColor = System.Drawing.Color.White;
            this.t4.HideSelection = true;
            this.t4.IconLeft = null;
            this.t4.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.t4.IconPadding = 10;
            this.t4.IconRight = null;
            this.t4.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.t4.Lines = new string[0];
            this.t4.Location = new System.Drawing.Point(454, 224);
            this.t4.MaxLength = 32767;
            this.t4.MinimumSize = new System.Drawing.Size(1, 1);
            this.t4.Modified = false;
            this.t4.Multiline = false;
            this.t4.Name = "t4";
            stateProperties81.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties81.FillColor = System.Drawing.Color.Empty;
            stateProperties81.ForeColor = System.Drawing.Color.Empty;
            stateProperties81.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t4.OnActiveState = stateProperties81;
            stateProperties82.BorderColor = System.Drawing.Color.Empty;
            stateProperties82.FillColor = System.Drawing.Color.White;
            stateProperties82.ForeColor = System.Drawing.Color.Empty;
            stateProperties82.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t4.OnDisabledState = stateProperties82;
            stateProperties83.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties83.FillColor = System.Drawing.Color.Empty;
            stateProperties83.ForeColor = System.Drawing.Color.Empty;
            stateProperties83.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t4.OnHoverState = stateProperties83;
            stateProperties84.BorderColor = System.Drawing.Color.DimGray;
            stateProperties84.FillColor = System.Drawing.Color.White;
            stateProperties84.ForeColor = System.Drawing.Color.Empty;
            stateProperties84.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t4.OnIdleState = stateProperties84;
            this.t4.PasswordChar = '\0';
            this.t4.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t4.PlaceholderText = "";
            this.t4.ReadOnly = false;
            this.t4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.t4.SelectedText = "";
            this.t4.SelectionLength = 0;
            this.t4.SelectionStart = 0;
            this.t4.ShortcutsEnabled = true;
            this.t4.Size = new System.Drawing.Size(246, 35);
            this.t4.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.t4.TabIndex = 3;
            this.t4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.t4.TextMarginBottom = 0;
            this.t4.TextMarginLeft = 5;
            this.t4.TextMarginTop = 0;
            this.t4.TextPlaceholder = "";
            this.t4.UseSystemPasswordChar = false;
            this.t4.WordWrap = true;
            this.t4.TextChanged += new System.EventHandler(this.t4_TextChanged);
            // 
            // t2
            // 
            this.t2.AcceptsReturn = false;
            this.t2.AcceptsTab = false;
            this.t2.AnimationSpeed = 200;
            this.t2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.t2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.t2.BackColor = System.Drawing.Color.Transparent;
            this.t2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("t2.BackgroundImage")));
            this.t2.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t2.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.t2.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t2.BorderColorIdle = System.Drawing.Color.DimGray;
            this.t2.BorderRadius = 30;
            this.t2.BorderThickness = 2;
            this.t2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.t2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t2.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.t2.DefaultText = "";
            this.t2.FillColor = System.Drawing.Color.White;
            this.t2.HideSelection = true;
            this.t2.IconLeft = null;
            this.t2.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.t2.IconPadding = 10;
            this.t2.IconRight = null;
            this.t2.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.t2.Lines = new string[0];
            this.t2.Location = new System.Drawing.Point(454, 146);
            this.t2.MaxLength = 32767;
            this.t2.MinimumSize = new System.Drawing.Size(1, 1);
            this.t2.Modified = false;
            this.t2.Multiline = false;
            this.t2.Name = "t2";
            stateProperties85.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties85.FillColor = System.Drawing.Color.Empty;
            stateProperties85.ForeColor = System.Drawing.Color.Empty;
            stateProperties85.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t2.OnActiveState = stateProperties85;
            stateProperties86.BorderColor = System.Drawing.Color.Empty;
            stateProperties86.FillColor = System.Drawing.Color.White;
            stateProperties86.ForeColor = System.Drawing.Color.Empty;
            stateProperties86.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t2.OnDisabledState = stateProperties86;
            stateProperties87.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties87.FillColor = System.Drawing.Color.Empty;
            stateProperties87.ForeColor = System.Drawing.Color.Empty;
            stateProperties87.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t2.OnHoverState = stateProperties87;
            stateProperties88.BorderColor = System.Drawing.Color.DimGray;
            stateProperties88.FillColor = System.Drawing.Color.White;
            stateProperties88.ForeColor = System.Drawing.Color.Empty;
            stateProperties88.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t2.OnIdleState = stateProperties88;
            this.t2.PasswordChar = '\0';
            this.t2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t2.PlaceholderText = "";
            this.t2.ReadOnly = false;
            this.t2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.t2.SelectedText = "";
            this.t2.SelectionLength = 0;
            this.t2.SelectionStart = 0;
            this.t2.ShortcutsEnabled = true;
            this.t2.Size = new System.Drawing.Size(246, 35);
            this.t2.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.t2.TabIndex = 1;
            this.t2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.t2.TextMarginBottom = 0;
            this.t2.TextMarginLeft = 5;
            this.t2.TextMarginTop = 0;
            this.t2.TextPlaceholder = "";
            this.t2.UseSystemPasswordChar = false;
            this.t2.WordWrap = true;
            this.t2.TextChanged += new System.EventHandler(this.t2_TextChanged);
            // 
            // t1
            // 
            this.t1.AcceptsReturn = false;
            this.t1.AcceptsTab = false;
            this.t1.AnimationSpeed = 200;
            this.t1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.t1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.t1.BackColor = System.Drawing.Color.Transparent;
            this.t1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("t1.BackgroundImage")));
            this.t1.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t1.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.t1.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t1.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.t1.BorderRadius = 30;
            this.t1.BorderThickness = 2;
            this.t1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.t1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.t1.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.t1.DefaultText = "";
            this.t1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.t1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.t1.HideSelection = true;
            this.t1.IconLeft = null;
            this.t1.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.t1.IconPadding = 10;
            this.t1.IconRight = null;
            this.t1.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.t1.Lines = new string[0];
            this.t1.Location = new System.Drawing.Point(149, 146);
            this.t1.MaxLength = 32767;
            this.t1.MinimumSize = new System.Drawing.Size(1, 1);
            this.t1.Modified = false;
            this.t1.Multiline = false;
            this.t1.Name = "t1";
            stateProperties89.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties89.FillColor = System.Drawing.Color.Empty;
            stateProperties89.ForeColor = System.Drawing.Color.Empty;
            stateProperties89.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t1.OnActiveState = stateProperties89;
            stateProperties90.BorderColor = System.Drawing.Color.Empty;
            stateProperties90.FillColor = System.Drawing.Color.White;
            stateProperties90.ForeColor = System.Drawing.Color.Empty;
            stateProperties90.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.t1.OnDisabledState = stateProperties90;
            stateProperties91.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties91.FillColor = System.Drawing.Color.Empty;
            stateProperties91.ForeColor = System.Drawing.Color.Empty;
            stateProperties91.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t1.OnHoverState = stateProperties91;
            stateProperties92.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties92.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            stateProperties92.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            stateProperties92.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.t1.OnIdleState = stateProperties92;
            this.t1.PasswordChar = '\0';
            this.t1.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.t1.PlaceholderText = "";
            this.t1.ReadOnly = false;
            this.t1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.t1.SelectedText = "";
            this.t1.SelectionLength = 0;
            this.t1.SelectionStart = 0;
            this.t1.ShortcutsEnabled = true;
            this.t1.Size = new System.Drawing.Size(246, 35);
            this.t1.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.t1.TabIndex = 0;
            this.t1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.t1.TextMarginBottom = 0;
            this.t1.TextMarginLeft = 5;
            this.t1.TextMarginTop = 0;
            this.t1.TextPlaceholder = "";
            this.t1.UseSystemPasswordChar = false;
            this.t1.WordWrap = true;
            // 
            // tabPage9
            // 
            this.tabPage9.AutoScroll = true;
            this.tabPage9.Controls.Add(this.saleiderror);
            this.tabPage9.Controls.Add(this.backinvoice);
            this.tabPage9.Controls.Add(this.bunifuDatePicker2);
            this.tabPage9.Controls.Add(this.lrbtn);
            this.tabPage9.Controls.Add(this.groupBox2);
            this.tabPage9.Controls.Add(this.bunifuSeparator6);
            this.tabPage9.Controls.Add(this.label31);
            this.tabPage9.Controls.Add(this.label32);
            this.tabPage9.Controls.Add(this.saleidtxt);
            this.tabPage9.Controls.Add(this.dataGridView7);
            this.tabPage9.Location = new System.Drawing.Point(4, 4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(876, 519);
            this.tabPage9.TabIndex = 7;
            this.tabPage9.Text = "return";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // saleiderror
            // 
            this.saleiderror.AutoSize = true;
            this.saleiderror.ForeColor = System.Drawing.Color.Red;
            this.saleiderror.Location = new System.Drawing.Point(14, 143);
            this.saleiderror.Name = "saleiderror";
            this.saleiderror.Size = new System.Drawing.Size(94, 13);
            this.saleiderror.TabIndex = 28;
            this.saleiderror.Text = "Alphabet not allow";
            this.saleiderror.Visible = false;
            // 
            // backinvoice
            // 
            this.backinvoice.Cursor = System.Windows.Forms.Cursors.Hand;
            this.backinvoice.Image = ((System.Drawing.Image)(resources.GetObject("backinvoice.Image")));
            this.backinvoice.Location = new System.Drawing.Point(3, 0);
            this.backinvoice.Name = "backinvoice";
            this.backinvoice.Size = new System.Drawing.Size(58, 35);
            this.backinvoice.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.backinvoice.TabIndex = 27;
            this.backinvoice.TabStop = false;
            this.backinvoice.Click += new System.EventHandler(this.backinvoice_Click);
            // 
            // bunifuDatePicker2
            // 
            this.bunifuDatePicker2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuDatePicker2.BorderRadius = 1;
            this.bunifuDatePicker2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuDatePicker2.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thick;
            this.bunifuDatePicker2.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.bunifuDatePicker2.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuDatePicker2.DisplayWeekNumbers = false;
            this.bunifuDatePicker2.DPHeight = 0;
            this.bunifuDatePicker2.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.bunifuDatePicker2.Enabled = false;
            this.bunifuDatePicker2.FillDatePicker = false;
            this.bunifuDatePicker2.ForeColor = System.Drawing.Color.DimGray;
            this.bunifuDatePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.bunifuDatePicker2.Icon = ((System.Drawing.Image)(resources.GetObject("bunifuDatePicker2.Icon")));
            this.bunifuDatePicker2.IconColor = System.Drawing.Color.DimGray;
            this.bunifuDatePicker2.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.bunifuDatePicker2.Location = new System.Drawing.Point(651, 105);
            this.bunifuDatePicker2.MinimumSize = new System.Drawing.Size(217, 32);
            this.bunifuDatePicker2.Name = "bunifuDatePicker2";
            this.bunifuDatePicker2.Size = new System.Drawing.Size(217, 32);
            this.bunifuDatePicker2.TabIndex = 22;
            // 
            // lrbtn
            // 
            this.lrbtn.AllowToggling = false;
            this.lrbtn.AnimationSpeed = 200;
            this.lrbtn.AutoGenerateColors = false;
            this.lrbtn.BackColor = System.Drawing.Color.Transparent;
            this.lrbtn.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.lrbtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("lrbtn.BackgroundImage")));
            this.lrbtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.lrbtn.ButtonText = "Load";
            this.lrbtn.ButtonTextMarginLeft = 0;
            this.lrbtn.ColorContrastOnClick = 45;
            this.lrbtn.ColorContrastOnHover = 45;
            this.lrbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges18.BottomLeft = true;
            borderEdges18.BottomRight = true;
            borderEdges18.TopLeft = true;
            borderEdges18.TopRight = true;
            this.lrbtn.CustomizableEdges = borderEdges18;
            this.lrbtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.lrbtn.DisabledBorderColor = System.Drawing.Color.Empty;
            this.lrbtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.lrbtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.lrbtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.lrbtn.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.lrbtn.ForeColor = System.Drawing.Color.White;
            this.lrbtn.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.lrbtn.IconMarginLeft = 11;
            this.lrbtn.IconPadding = 10;
            this.lrbtn.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.lrbtn.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.lrbtn.IdleBorderRadius = 30;
            this.lrbtn.IdleBorderThickness = 1;
            this.lrbtn.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.lrbtn.IdleIconLeftImage = null;
            this.lrbtn.IdleIconRightImage = null;
            this.lrbtn.IndicateFocus = false;
            this.lrbtn.Location = new System.Drawing.Point(209, 102);
            this.lrbtn.Name = "lrbtn";
            this.lrbtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.lrbtn.onHoverState.BorderRadius = 30;
            this.lrbtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.lrbtn.onHoverState.BorderThickness = 1;
            this.lrbtn.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.lrbtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.lrbtn.onHoverState.IconLeftImage = null;
            this.lrbtn.onHoverState.IconRightImage = null;
            this.lrbtn.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.lrbtn.OnIdleState.BorderRadius = 30;
            this.lrbtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.lrbtn.OnIdleState.BorderThickness = 1;
            this.lrbtn.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.lrbtn.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.lrbtn.OnIdleState.IconLeftImage = null;
            this.lrbtn.OnIdleState.IconRightImage = null;
            this.lrbtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.lrbtn.OnPressedState.BorderRadius = 30;
            this.lrbtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.lrbtn.OnPressedState.BorderThickness = 1;
            this.lrbtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.lrbtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.lrbtn.OnPressedState.IconLeftImage = null;
            this.lrbtn.OnPressedState.IconRightImage = null;
            this.lrbtn.Size = new System.Drawing.Size(110, 35);
            this.lrbtn.TabIndex = 21;
            this.lrbtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lrbtn.TextMarginLeft = 0;
            this.lrbtn.UseDefaultRadiusAndThickness = true;
            this.lrbtn.Click += new System.EventHandler(this.lrbtn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bunifuButton2);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.refundtxt);
            this.groupBox2.Controls.Add(this.recodetxt);
            this.groupBox2.Controls.Add(this.tammounttxt);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Location = new System.Drawing.Point(3, 409);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(870, 107);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Refund";
            // 
            // bunifuButton2
            // 
            this.bunifuButton2.AllowToggling = false;
            this.bunifuButton2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuButton2.AnimationSpeed = 200;
            this.bunifuButton2.AutoGenerateColors = false;
            this.bunifuButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton2.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton2.BackgroundImage")));
            this.bunifuButton2.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.ButtonText = "Refund";
            this.bunifuButton2.ButtonTextMarginLeft = 0;
            this.bunifuButton2.ColorContrastOnClick = 45;
            this.bunifuButton2.ColorContrastOnHover = 45;
            this.bunifuButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges19.BottomLeft = true;
            borderEdges19.BottomRight = true;
            borderEdges19.TopLeft = true;
            borderEdges19.TopRight = true;
            this.bunifuButton2.CustomizableEdges = borderEdges19;
            this.bunifuButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton2.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton2.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton2.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton2.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.bunifuButton2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.bunifuButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IconMarginLeft = 11;
            this.bunifuButton2.IconPadding = 10;
            this.bunifuButton2.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuButton2.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton2.IdleBorderRadius = 30;
            this.bunifuButton2.IdleBorderThickness = 1;
            this.bunifuButton2.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton2.IdleIconLeftImage = null;
            this.bunifuButton2.IdleIconRightImage = null;
            this.bunifuButton2.IndicateFocus = false;
            this.bunifuButton2.Location = new System.Drawing.Point(688, 45);
            this.bunifuButton2.Name = "bunifuButton2";
            this.bunifuButton2.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton2.onHoverState.BorderRadius = 30;
            this.bunifuButton2.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.onHoverState.BorderThickness = 1;
            this.bunifuButton2.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton2.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.onHoverState.IconLeftImage = null;
            this.bunifuButton2.onHoverState.IconRightImage = null;
            this.bunifuButton2.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton2.OnIdleState.BorderRadius = 30;
            this.bunifuButton2.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.OnIdleState.BorderThickness = 1;
            this.bunifuButton2.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.bunifuButton2.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.OnIdleState.IconLeftImage = null;
            this.bunifuButton2.OnIdleState.IconRightImage = null;
            this.bunifuButton2.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton2.OnPressedState.BorderRadius = 30;
            this.bunifuButton2.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.bunifuButton2.OnPressedState.BorderThickness = 1;
            this.bunifuButton2.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(101)))), ((int)(((byte)(94)))));
            this.bunifuButton2.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton2.OnPressedState.IconLeftImage = null;
            this.bunifuButton2.OnPressedState.IconRightImage = null;
            this.bunifuButton2.Size = new System.Drawing.Size(110, 35);
            this.bunifuButton2.TabIndex = 5;
            this.bunifuButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton2.TextMarginLeft = 0;
            this.bunifuButton2.UseDefaultRadiusAndThickness = true;
            this.bunifuButton2.Click += new System.EventHandler(this.bunifuButton2_Click);
            // 
            // label33
            // 
            this.label33.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(470, 26);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(84, 13);
            this.label33.TabIndex = 4;
            this.label33.Text = "Ammount refund";
            // 
            // label30
            // 
            this.label30.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(265, 26);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(47, 13);
            this.label30.TabIndex = 4;
            this.label30.Text = "Barcode";
            // 
            // label29
            // 
            this.label29.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(58, 26);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(77, 13);
            this.label29.TabIndex = 4;
            this.label29.Text = "Total ammount";
            // 
            // refundtxt
            // 
            this.refundtxt.AcceptsReturn = false;
            this.refundtxt.AcceptsTab = false;
            this.refundtxt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.refundtxt.AnimationSpeed = 200;
            this.refundtxt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.refundtxt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.refundtxt.BackColor = System.Drawing.Color.Transparent;
            this.refundtxt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("refundtxt.BackgroundImage")));
            this.refundtxt.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.refundtxt.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.refundtxt.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.refundtxt.BorderColorIdle = System.Drawing.Color.Silver;
            this.refundtxt.BorderRadius = 30;
            this.refundtxt.BorderThickness = 1;
            this.refundtxt.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.refundtxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.refundtxt.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.refundtxt.DefaultText = "";
            this.refundtxt.Enabled = false;
            this.refundtxt.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.refundtxt.HideSelection = true;
            this.refundtxt.IconLeft = null;
            this.refundtxt.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.refundtxt.IconPadding = 10;
            this.refundtxt.IconRight = null;
            this.refundtxt.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.refundtxt.Lines = new string[0];
            this.refundtxt.Location = new System.Drawing.Point(463, 45);
            this.refundtxt.MaxLength = 32767;
            this.refundtxt.MinimumSize = new System.Drawing.Size(1, 1);
            this.refundtxt.Modified = false;
            this.refundtxt.Multiline = false;
            this.refundtxt.Name = "refundtxt";
            stateProperties93.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties93.FillColor = System.Drawing.Color.Empty;
            stateProperties93.ForeColor = System.Drawing.Color.Empty;
            stateProperties93.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.refundtxt.OnActiveState = stateProperties93;
            stateProperties94.BorderColor = System.Drawing.Color.Empty;
            stateProperties94.FillColor = System.Drawing.Color.White;
            stateProperties94.ForeColor = System.Drawing.Color.Empty;
            stateProperties94.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.refundtxt.OnDisabledState = stateProperties94;
            stateProperties95.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties95.FillColor = System.Drawing.Color.Empty;
            stateProperties95.ForeColor = System.Drawing.Color.Empty;
            stateProperties95.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.refundtxt.OnHoverState = stateProperties95;
            stateProperties96.BorderColor = System.Drawing.Color.Silver;
            stateProperties96.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties96.ForeColor = System.Drawing.Color.Empty;
            stateProperties96.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.refundtxt.OnIdleState = stateProperties96;
            this.refundtxt.PasswordChar = '\0';
            this.refundtxt.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.refundtxt.PlaceholderText = "";
            this.refundtxt.ReadOnly = false;
            this.refundtxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.refundtxt.SelectedText = "";
            this.refundtxt.SelectionLength = 0;
            this.refundtxt.SelectionStart = 0;
            this.refundtxt.ShortcutsEnabled = true;
            this.refundtxt.Size = new System.Drawing.Size(200, 35);
            this.refundtxt.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.refundtxt.TabIndex = 3;
            this.refundtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.refundtxt.TextMarginBottom = 0;
            this.refundtxt.TextMarginLeft = 5;
            this.refundtxt.TextMarginTop = 0;
            this.refundtxt.TextPlaceholder = "";
            this.refundtxt.UseSystemPasswordChar = false;
            this.refundtxt.WordWrap = true;
            // 
            // recodetxt
            // 
            this.recodetxt.AcceptsReturn = false;
            this.recodetxt.AcceptsTab = false;
            this.recodetxt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.recodetxt.AnimationSpeed = 200;
            this.recodetxt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.recodetxt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.recodetxt.BackColor = System.Drawing.Color.Transparent;
            this.recodetxt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("recodetxt.BackgroundImage")));
            this.recodetxt.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.recodetxt.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.recodetxt.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.recodetxt.BorderColorIdle = System.Drawing.Color.Silver;
            this.recodetxt.BorderRadius = 30;
            this.recodetxt.BorderThickness = 1;
            this.recodetxt.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.recodetxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.recodetxt.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.recodetxt.DefaultText = "";
            this.recodetxt.FillColor = System.Drawing.Color.White;
            this.recodetxt.HideSelection = true;
            this.recodetxt.IconLeft = null;
            this.recodetxt.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.recodetxt.IconPadding = 10;
            this.recodetxt.IconRight = null;
            this.recodetxt.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.recodetxt.Lines = new string[0];
            this.recodetxt.Location = new System.Drawing.Point(257, 45);
            this.recodetxt.MaxLength = 32767;
            this.recodetxt.MinimumSize = new System.Drawing.Size(1, 1);
            this.recodetxt.Modified = false;
            this.recodetxt.Multiline = false;
            this.recodetxt.Name = "recodetxt";
            stateProperties97.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties97.FillColor = System.Drawing.Color.Empty;
            stateProperties97.ForeColor = System.Drawing.Color.Empty;
            stateProperties97.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.recodetxt.OnActiveState = stateProperties97;
            stateProperties98.BorderColor = System.Drawing.Color.Empty;
            stateProperties98.FillColor = System.Drawing.Color.White;
            stateProperties98.ForeColor = System.Drawing.Color.Empty;
            stateProperties98.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.recodetxt.OnDisabledState = stateProperties98;
            stateProperties99.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties99.FillColor = System.Drawing.Color.Empty;
            stateProperties99.ForeColor = System.Drawing.Color.Empty;
            stateProperties99.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.recodetxt.OnHoverState = stateProperties99;
            stateProperties100.BorderColor = System.Drawing.Color.Silver;
            stateProperties100.FillColor = System.Drawing.Color.White;
            stateProperties100.ForeColor = System.Drawing.Color.Empty;
            stateProperties100.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.recodetxt.OnIdleState = stateProperties100;
            this.recodetxt.PasswordChar = '\0';
            this.recodetxt.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.recodetxt.PlaceholderText = "";
            this.recodetxt.ReadOnly = false;
            this.recodetxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.recodetxt.SelectedText = "";
            this.recodetxt.SelectionLength = 0;
            this.recodetxt.SelectionStart = 0;
            this.recodetxt.ShortcutsEnabled = true;
            this.recodetxt.Size = new System.Drawing.Size(200, 35);
            this.recodetxt.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.recodetxt.TabIndex = 2;
            this.recodetxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.recodetxt.TextMarginBottom = 0;
            this.recodetxt.TextMarginLeft = 5;
            this.recodetxt.TextMarginTop = 0;
            this.recodetxt.TextPlaceholder = "";
            this.recodetxt.UseSystemPasswordChar = false;
            this.recodetxt.WordWrap = true;
            this.recodetxt.Validating += new System.ComponentModel.CancelEventHandler(this.recodetxt_Validating);
            // 
            // tammounttxt
            // 
            this.tammounttxt.AcceptsReturn = false;
            this.tammounttxt.AcceptsTab = false;
            this.tammounttxt.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tammounttxt.AnimationSpeed = 200;
            this.tammounttxt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tammounttxt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tammounttxt.BackColor = System.Drawing.Color.Transparent;
            this.tammounttxt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tammounttxt.BackgroundImage")));
            this.tammounttxt.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tammounttxt.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.tammounttxt.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tammounttxt.BorderColorIdle = System.Drawing.Color.DarkGray;
            this.tammounttxt.BorderRadius = 30;
            this.tammounttxt.BorderThickness = 1;
            this.tammounttxt.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tammounttxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tammounttxt.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.tammounttxt.DefaultText = "";
            this.tammounttxt.Enabled = false;
            this.tammounttxt.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.tammounttxt.HideSelection = true;
            this.tammounttxt.IconLeft = null;
            this.tammounttxt.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tammounttxt.IconPadding = 10;
            this.tammounttxt.IconRight = null;
            this.tammounttxt.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tammounttxt.Lines = new string[0];
            this.tammounttxt.Location = new System.Drawing.Point(51, 45);
            this.tammounttxt.MaxLength = 32767;
            this.tammounttxt.MinimumSize = new System.Drawing.Size(1, 1);
            this.tammounttxt.Modified = false;
            this.tammounttxt.Multiline = false;
            this.tammounttxt.Name = "tammounttxt";
            stateProperties101.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties101.FillColor = System.Drawing.Color.Empty;
            stateProperties101.ForeColor = System.Drawing.Color.Empty;
            stateProperties101.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tammounttxt.OnActiveState = stateProperties101;
            stateProperties102.BorderColor = System.Drawing.Color.Empty;
            stateProperties102.FillColor = System.Drawing.Color.White;
            stateProperties102.ForeColor = System.Drawing.Color.Empty;
            stateProperties102.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tammounttxt.OnDisabledState = stateProperties102;
            stateProperties103.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties103.FillColor = System.Drawing.Color.Empty;
            stateProperties103.ForeColor = System.Drawing.Color.Empty;
            stateProperties103.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tammounttxt.OnHoverState = stateProperties103;
            stateProperties104.BorderColor = System.Drawing.Color.DarkGray;
            stateProperties104.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties104.ForeColor = System.Drawing.Color.Empty;
            stateProperties104.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tammounttxt.OnIdleState = stateProperties104;
            this.tammounttxt.PasswordChar = '\0';
            this.tammounttxt.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tammounttxt.PlaceholderText = "";
            this.tammounttxt.ReadOnly = false;
            this.tammounttxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tammounttxt.SelectedText = "";
            this.tammounttxt.SelectionLength = 0;
            this.tammounttxt.SelectionStart = 0;
            this.tammounttxt.ShortcutsEnabled = true;
            this.tammounttxt.Size = new System.Drawing.Size(200, 35);
            this.tammounttxt.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.tammounttxt.TabIndex = 0;
            this.tammounttxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tammounttxt.TextMarginBottom = 0;
            this.tammounttxt.TextMarginLeft = 5;
            this.tammounttxt.TextMarginTop = 0;
            this.tammounttxt.TextPlaceholder = "";
            this.tammounttxt.UseSystemPasswordChar = false;
            this.tammounttxt.WordWrap = true;
            // 
            // bunifuSeparator6
            // 
            this.bunifuSeparator6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator6.LineThickness = 1;
            this.bunifuSeparator6.Location = new System.Drawing.Point(19, 66);
            this.bunifuSeparator6.Name = "bunifuSeparator6";
            this.bunifuSeparator6.Size = new System.Drawing.Size(50, 10);
            this.bunifuSeparator6.TabIndex = 19;
            this.bunifuSeparator6.Transparency = 255;
            this.bunifuSeparator6.Vertical = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial Narrow", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(2, 39);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(90, 35);
            this.label31.TabIndex = 18;
            this.label31.Text = "Return";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(32, 17);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(0, 13);
            this.label32.TabIndex = 17;
            // 
            // saleidtxt
            // 
            this.saleidtxt.AcceptsReturn = false;
            this.saleidtxt.AcceptsTab = false;
            this.saleidtxt.AnimationSpeed = 200;
            this.saleidtxt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.saleidtxt.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.saleidtxt.BackColor = System.Drawing.Color.Transparent;
            this.saleidtxt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("saleidtxt.BackgroundImage")));
            this.saleidtxt.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.saleidtxt.BorderColorDisabled = System.Drawing.Color.DimGray;
            this.saleidtxt.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.saleidtxt.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.saleidtxt.BorderRadius = 30;
            this.saleidtxt.BorderThickness = 2;
            this.saleidtxt.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.saleidtxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.saleidtxt.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.saleidtxt.DefaultText = "";
            this.saleidtxt.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.saleidtxt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.saleidtxt.HideSelection = true;
            this.saleidtxt.IconLeft = null;
            this.saleidtxt.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.saleidtxt.IconPadding = 10;
            this.saleidtxt.IconRight = null;
            this.saleidtxt.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.saleidtxt.Lines = new string[0];
            this.saleidtxt.Location = new System.Drawing.Point(3, 102);
            this.saleidtxt.MaxLength = 32767;
            this.saleidtxt.MinimumSize = new System.Drawing.Size(1, 1);
            this.saleidtxt.Modified = false;
            this.saleidtxt.Multiline = false;
            this.saleidtxt.Name = "saleidtxt";
            stateProperties105.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties105.FillColor = System.Drawing.Color.Empty;
            stateProperties105.ForeColor = System.Drawing.Color.Empty;
            stateProperties105.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.saleidtxt.OnActiveState = stateProperties105;
            stateProperties106.BorderColor = System.Drawing.Color.DimGray;
            stateProperties106.FillColor = System.Drawing.Color.White;
            stateProperties106.ForeColor = System.Drawing.Color.Empty;
            stateProperties106.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.saleidtxt.OnDisabledState = stateProperties106;
            stateProperties107.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties107.FillColor = System.Drawing.Color.Empty;
            stateProperties107.ForeColor = System.Drawing.Color.Empty;
            stateProperties107.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.saleidtxt.OnHoverState = stateProperties107;
            stateProperties108.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties108.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            stateProperties108.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            stateProperties108.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.saleidtxt.OnIdleState = stateProperties108;
            this.saleidtxt.PasswordChar = '\0';
            this.saleidtxt.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.saleidtxt.PlaceholderText = "Enter Sale ID";
            this.saleidtxt.ReadOnly = false;
            this.saleidtxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.saleidtxt.SelectedText = "";
            this.saleidtxt.SelectionLength = 0;
            this.saleidtxt.SelectionStart = 0;
            this.saleidtxt.ShortcutsEnabled = true;
            this.saleidtxt.Size = new System.Drawing.Size(200, 35);
            this.saleidtxt.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.saleidtxt.TabIndex = 13;
            this.saleidtxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.saleidtxt.TextMarginBottom = 0;
            this.saleidtxt.TextMarginLeft = 5;
            this.saleidtxt.TextMarginTop = 0;
            this.saleidtxt.TextPlaceholder = "Enter Sale ID";
            this.saleidtxt.UseSystemPasswordChar = false;
            this.saleidtxt.WordWrap = true;
            // 
            // dataGridView7
            // 
            this.dataGridView7.AllowUserToAddRows = false;
            this.dataGridView7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView7.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView7.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.dataGridView7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView7.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridView7.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView7.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridView7.ColumnHeadersHeight = 30;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.r1,
            this.r2,
            this.r3,
            this.r8,
            this.r4,
            this.r5,
            this.r6,
            this.r7,
            this.r9,
            this.r10,
            this.r11,
            this.dataGridViewButtonColumn1});
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.MediumTurquoise;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView7.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridView7.EnableHeadersVisualStyles = false;
            this.dataGridView7.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.dataGridView7.Location = new System.Drawing.Point(3, 165);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.ReadOnly = true;
            this.dataGridView7.RowHeadersVisible = false;
            this.dataGridView7.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView7.Size = new System.Drawing.Size(870, 238);
            this.dataGridView7.TabIndex = 14;
            // 
            // r1
            // 
            this.r1.HeaderText = "Sale ID";
            this.r1.Name = "r1";
            this.r1.ReadOnly = true;
            // 
            // r2
            // 
            this.r2.HeaderText = "Bar Code";
            this.r2.Name = "r2";
            this.r2.ReadOnly = true;
            // 
            // r3
            // 
            this.r3.HeaderText = "Name";
            this.r3.Name = "r3";
            this.r3.ReadOnly = true;
            // 
            // r8
            // 
            this.r8.HeaderText = "Quantity";
            this.r8.Name = "r8";
            this.r8.ReadOnly = true;
            // 
            // r4
            // 
            this.r4.HeaderText = "Per Unit Price";
            this.r4.Name = "r4";
            this.r4.ReadOnly = true;
            // 
            // r5
            // 
            dataGridViewCellStyle17.Format = "N2";
            dataGridViewCellStyle17.NullValue = null;
            this.r5.DefaultCellStyle = dataGridViewCellStyle17;
            this.r5.HeaderText = "Total";
            this.r5.Name = "r5";
            this.r5.ReadOnly = true;
            this.r5.Visible = false;
            // 
            // r6
            // 
            this.r6.HeaderText = "Given";
            this.r6.Name = "r6";
            this.r6.ReadOnly = true;
            this.r6.Visible = false;
            // 
            // r7
            // 
            this.r7.HeaderText = "Return";
            this.r7.Name = "r7";
            this.r7.ReadOnly = true;
            this.r7.Visible = false;
            // 
            // r9
            // 
            dataGridViewCellStyle18.Format = "g";
            dataGridViewCellStyle18.NullValue = null;
            this.r9.DefaultCellStyle = dataGridViewCellStyle18;
            this.r9.HeaderText = "date";
            this.r9.Name = "r9";
            this.r9.ReadOnly = true;
            this.r9.Visible = false;
            // 
            // r10
            // 
            this.r10.HeaderText = "Total Per Unit";
            this.r10.Name = "r10";
            this.r10.ReadOnly = true;
            // 
            // r11
            // 
            this.r11.HeaderText = "proid";
            this.r11.Name = "r11";
            this.r11.ReadOnly = true;
            this.r11.Visible = false;
            // 
            // dataGridViewButtonColumn1
            // 
            this.dataGridViewButtonColumn1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridViewButtonColumn1.DataPropertyName = "Remove";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewButtonColumn1.DefaultCellStyle = dataGridViewCellStyle19;
            this.dataGridViewButtonColumn1.HeaderText = "Action";
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.ReadOnly = true;
            this.dataGridViewButtonColumn1.Text = "Remove";
            this.dataGridViewButtonColumn1.ToolTipText = "Remove the quantity";
            this.dataGridViewButtonColumn1.UseColumnTextForButtonValue = true;
            this.dataGridViewButtonColumn1.Visible = false;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.navigation;
            this.bunifuDragControl1.Vertical = true;
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteRowToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(131, 26);
            this.contextMenuStrip2.Click += new System.EventHandler(this.contextMenuStrip2_Click);
            // 
            // deleteRowToolStripMenuItem
            // 
            this.deleteRowToolStripMenuItem.Name = "deleteRowToolStripMenuItem";
            this.deleteRowToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.deleteRowToolStripMenuItem.Text = "Delete row";
            // 
            // cb1
            // 
            this.cb1.AllowBindingControlAnimation = true;
            this.cb1.AllowBindingControlColorChanges = false;
            this.cb1.AllowBindingControlLocation = true;
            this.cb1.AllowCheckBoxAnimation = false;
            this.cb1.AllowCheckmarkAnimation = true;
            this.cb1.AllowOnHoverStates = true;
            this.cb1.AutoCheck = true;
            this.cb1.BackColor = System.Drawing.Color.Transparent;
            this.cb1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cb1.BackgroundImage")));
            this.cb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.cb1.BindingControl = null;
            this.cb1.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.cb1.Checked = false;
            this.cb1.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Unchecked;
            this.cb1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.cb1.CustomCheckmarkImage = null;
            this.cb1.Location = new System.Drawing.Point(148, 424);
            this.cb1.MinimumSize = new System.Drawing.Size(17, 17);
            this.cb1.Name = "cb1";
            this.cb1.OnCheck.BorderColor = System.Drawing.Color.DodgerBlue;
            this.cb1.OnCheck.BorderRadius = 2;
            this.cb1.OnCheck.BorderThickness = 2;
            this.cb1.OnCheck.CheckBoxColor = System.Drawing.Color.DodgerBlue;
            this.cb1.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.cb1.OnCheck.CheckmarkThickness = 2;
            this.cb1.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.cb1.OnDisable.BorderRadius = 2;
            this.cb1.OnDisable.BorderThickness = 2;
            this.cb1.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.cb1.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.cb1.OnDisable.CheckmarkThickness = 2;
            this.cb1.OnHoverChecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.cb1.OnHoverChecked.BorderRadius = 2;
            this.cb1.OnHoverChecked.BorderThickness = 2;
            this.cb1.OnHoverChecked.CheckBoxColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.cb1.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.cb1.OnHoverChecked.CheckmarkThickness = 2;
            this.cb1.OnHoverUnchecked.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.cb1.OnHoverUnchecked.BorderRadius = 2;
            this.cb1.OnHoverUnchecked.BorderThickness = 1;
            this.cb1.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.cb1.OnUncheck.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.cb1.OnUncheck.BorderRadius = 2;
            this.cb1.OnUncheck.BorderThickness = 1;
            this.cb1.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.cb1.Size = new System.Drawing.Size(17, 17);
            this.cb1.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.cb1.TabIndex = 21;
            this.cb1.ThreeState = false;
            this.cb1.ToolTipText = null;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label34.Location = new System.Drawing.Point(170, 428);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(60, 13);
            this.label34.TabIndex = 22;
            this.label34.Text = "Only Image";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.ClientSize = new System.Drawing.Size(1064, 580);
            this.Controls.Add(this.bunifuPages1);
            this.Controls.Add(this.navigation);
            this.Controls.Add(this.slide);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.navigation.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.circularpicture1)).EndInit();
            this.slide.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.indicator)).EndInit();
            this.bunifuPages1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.bunifuPages2.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuDataGridView1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.bunifuPages4.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.bunifuPages5.ResumeLayout(false);
            this.tabPage16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage18.ResumeLayout(false);
            this.tabPage18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userimage)).EndInit();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.backinvoice)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel navigation;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton close;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton minimum;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton maxnormal;
        private System.Windows.Forms.Panel slide;
        private Bunifu.Framework.UI.BunifuFlatButton report;
        private Bunifu.Framework.UI.BunifuFlatButton inventroy;
        private Bunifu.Framework.UI.BunifuFlatButton invoice;
        private Bunifu.Framework.UI.BunifuFlatButton menu;
        private Bunifu.Framework.UI.BunifuFlatButton setting;
        private Bunifu.Framework.UI.BunifuFlatButton payment;
        private Bunifu.Framework.UI.BunifuFlatButton stock;
        private System.Windows.Forms.PictureBox indicator;
        private Bunifu.UI.WinForms.BunifuPages bunifuPages1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton addbtn;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox searchiteam;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton returnreport;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnreport;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel indicator1;
        private Bunifu.UI.WinForms.BunifuPages bunifuPages2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox searchreport;
        private System.Windows.Forms.Button button1;
        private Bunifu.UI.WinForms.BunifuDataGridView bunifuDataGridView1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.Label label8;
        private Bunifu.UI.WinForms.BunifuDatePicker expirypicker;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label total;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        public Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox t5;
        public Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox t3;
        public Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox t4;
        public Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox t2;
        public Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox t1;
        private System.Windows.Forms.Label label15;
        private Bunifu.UI.WinForms.BunifuPages bunifuPages4;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.Button stkbtn;
        private System.Windows.Forms.Button empty;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox stcksearch;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn scode;
        private System.Windows.Forms.DataGridViewTextBoxColumn sname;
        private System.Windows.Forms.DataGridViewTextBoxColumn sqty;
        private System.Windows.Forms.DataGridViewTextBoxColumn sdue;
        private System.Windows.Forms.DataGridViewTextBoxColumn sprice;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox searchempty;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ecode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ename;
        private System.Windows.Forms.DataGridViewTextBoxColumn eqty;
        private System.Windows.Forms.DataGridViewTextBoxColumn edue;
        private System.Windows.Forms.DataGridViewTextBoxColumn eprice;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnemp;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel indicator3;
        private Bunifu.UI.WinForms.BunifuPages bunifuPages5;
        private System.Windows.Forms.TabPage tabPage16;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton addloan;
        private System.Windows.Forms.Button loanrefresh;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.TabPage tabPage18;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton9;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox gt4;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox gt2;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox gt5;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox gt3;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox gt1;
        private System.Windows.Forms.Label remaning;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label qtyerror;
        private System.Windows.Forms.Label profiterror;
        private System.Windows.Forms.Label priceerror;
        private System.Windows.Forms.Label noerror;
        private System.Windows.Forms.Label giveerror;
        private System.Windows.Forms.Label loanerror;
        private System.Windows.Forms.DataGridViewTextBoxColumn g1;
        private System.Windows.Forms.DataGridViewTextBoxColumn g2;
        private System.Windows.Forms.DataGridViewTextBoxColumn g3;
        private System.Windows.Forms.DataGridViewTextBoxColumn g4;
        private System.Windows.Forms.DataGridViewTextBoxColumn g5;
        private System.Windows.Forms.DataGridViewTextBoxColumn g6;
        private System.Windows.Forms.DataGridViewTextBoxColumn g7;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator4;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton1;
        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox changetxt;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox giventext;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox totaltxt;
        private System.Windows.Forms.Label invoiceerror;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator5;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox code;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton paybtn;
        private System.Windows.Forms.Label grosstotal;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton checkbtn;
        private System.Windows.Forms.Label gerror;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox5;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox bunifuTextBox4;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label23;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton10;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox ut2;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox ut1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton loadbtn;
        private Bunifu.UI.WinForms.BunifuDatePicker bunifuDatePicker1;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem deleteRowToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn iproduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn iquantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn iprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn itotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn idgv;
        private System.Windows.Forms.DataGridViewButtonColumn actionbtn;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private System.Windows.Forms.TabPage tabPage9;
        private Bunifu.UI.WinForms.BunifuDatePicker bunifuDatePicker2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton lrbtn;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator6;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox saleidtxt;
        private System.Windows.Forms.DataGridView dataGridView7;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton rebtn;
        private System.Windows.Forms.PictureBox backinvoice;
        private System.Windows.Forms.DataGridViewTextBoxColumn c1;
        private System.Windows.Forms.DataGridViewTextBoxColumn c2;
        private System.Windows.Forms.DataGridViewTextBoxColumn c3;
        private System.Windows.Forms.DataGridViewTextBoxColumn c4;
        private System.Windows.Forms.DataGridViewTextBoxColumn c5;
        private System.Windows.Forms.DataGridViewTextBoxColumn c6;
        private System.Windows.Forms.DataGridViewTextBoxColumn c7;
        private System.Windows.Forms.DataGridViewTextBoxColumn c8;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox refundtxt;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox recodetxt;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox tammounttxt;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label saleiderror;
        private System.Windows.Forms.DataGridViewTextBoxColumn r1;
        private System.Windows.Forms.DataGridViewTextBoxColumn r2;
        private System.Windows.Forms.DataGridViewTextBoxColumn r3;
        private System.Windows.Forms.DataGridViewTextBoxColumn r8;
        private System.Windows.Forms.DataGridViewTextBoxColumn r4;
        private System.Windows.Forms.DataGridViewTextBoxColumn r5;
        private System.Windows.Forms.DataGridViewTextBoxColumn r6;
        private System.Windows.Forms.DataGridViewTextBoxColumn r7;
        private System.Windows.Forms.DataGridViewTextBoxColumn r9;
        private System.Windows.Forms.DataGridViewTextBoxColumn r10;
        private System.Windows.Forms.DataGridViewTextBoxColumn r11;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator7;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator8;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator9;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator10;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator11;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator12;
        private System.Windows.Forms.Label naerror;
        private System.Windows.Forms.Label nameerror;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton3;
        private Circularpicture userimage;
        private Circularpicture circularpicture1;
        private System.Windows.Forms.DataGridViewTextBoxColumn s1;
        private System.Windows.Forms.DataGridViewTextBoxColumn s2;
        private System.Windows.Forms.DataGridViewTextBoxColumn s3;
        private System.Windows.Forms.DataGridViewTextBoxColumn s4;
        private System.Windows.Forms.DataGridViewTextBoxColumn s5;
        private System.Windows.Forms.Label label34;
        private Bunifu.UI.WinForms.BunifuCheckBox cb1;
    }
}