﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigiShop
{
    class Updation
    {
        public void update_salerefund(DataGridView gv,  string r4, string r10,string id)
        {
            try
             {
                foreach (DataGridViewRow row in gv.Rows) 
                {
                    SqlCommand cmd = new SqlCommand("up_saledetail", DBMain.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@qty", Convert.ToInt32(row.Cells[r4].Value.ToString()));
                    cmd.Parameters.AddWithValue("@saleid", Convert.ToInt64(id));
                    cmd.Parameters.AddWithValue("@total", Convert.ToSingle(row.Cells[r10].Value.ToString()));
                    DBMain.con.Open();
                    cmd.ExecuteNonQuery();
                }
                    
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
        }
        public void Update_user(string name,string pass,byte[] imgg)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("sg_update", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name",name);
                cmd.Parameters.AddWithValue("@pass",pass);
                cmd.Parameters.AddWithValue("@image", imgg);
                DBMain.con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
        }
        public void Update_userwithoutimage(string name,string pass)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("sg_updatewi", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name",name);
                cmd.Parameters.AddWithValue("@pass",pass);
                DBMain.con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
        }
        public void update_Stockiteam(int id, int qty)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("updatastock", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@quan", qty);
               // DBMain.con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                //DBMain.con.Close();
            }
        }
        public void update_quantity(int id, int qty)
        {
            //hi
            try
            {
                SqlCommand cmd = new SqlCommand("updatastock", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@quan", qty);
                DBMain.con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
        }
        public void update_saledetails(Int64 id, int qty,int proid)
        {
            try
            {
                SqlCommand cmd = new SqlCommand("re_upsaladetails", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@salid", id);
                cmd.Parameters.AddWithValue("@qty", qty);
                cmd.Parameters.AddWithValue("@proid", proid);
                DBMain.con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
        }
    }
}
