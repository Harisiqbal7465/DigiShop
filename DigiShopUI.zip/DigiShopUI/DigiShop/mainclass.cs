﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Windows.Forms;
namespace DigiShop
{
    class DBMain
    {
        private static string Path = Environment.GetFolderPath(Environment.SpecialFolder.MyComputer);
        private static string s = File.ReadAllText(Path+"\\connect");
        public static SqlConnection con = new SqlConnection(s);
        public static void showWindow(Form OpenWindow,Form CloseWindow)
        {
            OpenWindow.Show();
            CloseWindow.Close();
        }
        public static void openWindow(Form OpenWindow)
        {
            OpenWindow.Show();
        }
        public static void enable_reset(GroupBox gb)
        {
            foreach(Control c in gb.Controls)
            {
                if(c is TextBox)
                {
                    TextBox t = (TextBox)c;
                    t.Enabled = true;
                    t.Text = "";
                }
               
            }
        }

    }
}
