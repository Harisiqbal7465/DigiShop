﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace DigiShop
{
    public partial class loading : Form
    {
        public loading()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //condition for loading screen
            panel2.Width += 3; //increase panel 3 time when tick
            if (panel2.Width >= 684)//it works when panel size is qual to 684
            {
                timer1.Stop();//stop the tick
                //login lg = new login();
                //lg.Show();
                //this.Hide();
                string Path = Environment.GetFolderPath(Environment.SpecialFolder.MyComputer);
                if (File.Exists(Path + "\\connect"))
                {
                    login lg = new login();
                    lg.Show();
                    this.Hide();
                }
                else
                {
                    Information info = new Information();
                    info.Show();
                    this.Hide();
                }
            }
        }
    }
}
