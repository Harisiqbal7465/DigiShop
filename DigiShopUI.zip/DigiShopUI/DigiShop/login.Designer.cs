﻿namespace DigiShop
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton bunifuButton1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(login));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.singin = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.pass = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.user = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            bunifuButton1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuButton1
            // 
            bunifuButton1.AllowToggling = false;
            bunifuButton1.AnimationSpeed = 200;
            bunifuButton1.AutoGenerateColors = false;
            bunifuButton1.BackColor = System.Drawing.Color.Transparent;
            bunifuButton1.BackColor1 = System.Drawing.Color.Transparent;
            bunifuButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.BackgroundImage")));
            bunifuButton1.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            bunifuButton1.ButtonText = "";
            bunifuButton1.ButtonTextMarginLeft = 0;
            bunifuButton1.ColorContrastOnClick = 45;
            bunifuButton1.ColorContrastOnHover = 45;
            bunifuButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            bunifuButton1.CustomizableEdges = borderEdges1;
            bunifuButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            bunifuButton1.DisabledBorderColor = System.Drawing.Color.Empty;
            bunifuButton1.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            bunifuButton1.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            bunifuButton1.Dock = System.Windows.Forms.DockStyle.Right;
            bunifuButton1.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            bunifuButton1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            bunifuButton1.ForeColor = System.Drawing.Color.White;
            bunifuButton1.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            bunifuButton1.IconMarginLeft = 11;
            bunifuButton1.IconPadding = 10;
            bunifuButton1.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            bunifuButton1.IdleBorderColor = System.Drawing.Color.Transparent;
            bunifuButton1.IdleBorderRadius = 3;
            bunifuButton1.IdleBorderThickness = 1;
            bunifuButton1.IdleFillColor = System.Drawing.Color.Transparent;
            bunifuButton1.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.IdleIconLeftImage")));
            bunifuButton1.IdleIconRightImage = null;
            bunifuButton1.IndicateFocus = false;
            bunifuButton1.Location = new System.Drawing.Point(535, 0);
            bunifuButton1.Name = "bunifuButton1";
            bunifuButton1.onHoverState.BorderColor = System.Drawing.Color.DarkGray;
            bunifuButton1.onHoverState.BorderRadius = 3;
            bunifuButton1.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            bunifuButton1.onHoverState.BorderThickness = 1;
            bunifuButton1.onHoverState.FillColor = System.Drawing.Color.DarkGray;
            bunifuButton1.onHoverState.ForeColor = System.Drawing.Color.White;
            bunifuButton1.onHoverState.IconLeftImage = null;
            bunifuButton1.onHoverState.IconRightImage = null;
            bunifuButton1.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            bunifuButton1.OnIdleState.BorderRadius = 3;
            bunifuButton1.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            bunifuButton1.OnIdleState.BorderThickness = 1;
            bunifuButton1.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            bunifuButton1.OnIdleState.ForeColor = System.Drawing.Color.White;
            bunifuButton1.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton1.OnIdleState.IconLeftImage")));
            bunifuButton1.OnIdleState.IconRightImage = null;
            bunifuButton1.OnPressedState.BorderColor = System.Drawing.Color.Transparent;
            bunifuButton1.OnPressedState.BorderRadius = 3;
            bunifuButton1.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            bunifuButton1.OnPressedState.BorderThickness = 1;
            bunifuButton1.OnPressedState.FillColor = System.Drawing.Color.Transparent;
            bunifuButton1.OnPressedState.ForeColor = System.Drawing.Color.White;
            bunifuButton1.OnPressedState.IconLeftImage = null;
            bunifuButton1.OnPressedState.IconRightImage = null;
            bunifuButton1.Size = new System.Drawing.Size(35, 31);
            bunifuButton1.TabIndex = 0;
            bunifuButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            bunifuButton1.TextMarginLeft = 0;
            bunifuButton1.UseDefaultRadiusAndThickness = true;
            bunifuButton1.Click += new System.EventHandler(this.bunifuButton1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(bunifuButton1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(570, 31);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Login form";
            // 
            // singin
            // 
            this.singin.AllowToggling = false;
            this.singin.AnimationSpeed = 200;
            this.singin.AutoGenerateColors = false;
            this.singin.BackColor = System.Drawing.Color.Transparent;
            this.singin.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.singin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("singin.BackgroundImage")));
            this.singin.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.singin.ButtonText = "Login";
            this.singin.ButtonTextMarginLeft = 0;
            this.singin.ColorContrastOnClick = 45;
            this.singin.ColorContrastOnHover = 45;
            this.singin.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.singin.CustomizableEdges = borderEdges2;
            this.singin.DialogResult = System.Windows.Forms.DialogResult.None;
            this.singin.DisabledBorderColor = System.Drawing.Color.Empty;
            this.singin.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.singin.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.singin.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.singin.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.singin.ForeColor = System.Drawing.Color.Black;
            this.singin.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.singin.IconMarginLeft = 11;
            this.singin.IconPadding = 10;
            this.singin.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.singin.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.singin.IdleBorderRadius = 40;
            this.singin.IdleBorderThickness = 2;
            this.singin.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.singin.IdleIconLeftImage = null;
            this.singin.IdleIconRightImage = null;
            this.singin.IndicateFocus = false;
            this.singin.Location = new System.Drawing.Point(134, 311);
            this.singin.Name = "singin";
            this.singin.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.singin.onHoverState.BorderRadius = 40;
            this.singin.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.singin.onHoverState.BorderThickness = 2;
            this.singin.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.singin.onHoverState.ForeColor = System.Drawing.Color.Black;
            this.singin.onHoverState.IconLeftImage = null;
            this.singin.onHoverState.IconRightImage = null;
            this.singin.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.singin.OnIdleState.BorderRadius = 40;
            this.singin.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.singin.OnIdleState.BorderThickness = 2;
            this.singin.OnIdleState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.singin.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.singin.OnIdleState.IconLeftImage = null;
            this.singin.OnIdleState.IconRightImage = null;
            this.singin.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.singin.OnPressedState.BorderRadius = 40;
            this.singin.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.singin.OnPressedState.BorderThickness = 2;
            this.singin.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.singin.OnPressedState.ForeColor = System.Drawing.Color.Black;
            this.singin.OnPressedState.IconLeftImage = null;
            this.singin.OnPressedState.IconRightImage = null;
            this.singin.Size = new System.Drawing.Size(300, 45);
            this.singin.TabIndex = 3;
            this.singin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.singin.TextMarginLeft = 0;
            this.singin.UseDefaultRadiusAndThickness = true;
            this.singin.Click += new System.EventHandler(this.singin_Click);
            // 
            // pass
            // 
            this.pass.AcceptsReturn = false;
            this.pass.AcceptsTab = false;
            this.pass.AnimationSpeed = 200;
            this.pass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.pass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.pass.BackColor = System.Drawing.Color.Transparent;
            this.pass.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pass.BackgroundImage")));
            this.pass.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.pass.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.pass.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.pass.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.pass.BorderRadius = 40;
            this.pass.BorderThickness = 2;
            this.pass.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.pass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.pass.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.pass.DefaultText = "";
            this.pass.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.pass.ForeColor = System.Drawing.Color.Black;
            this.pass.HideSelection = true;
            this.pass.IconLeft = ((System.Drawing.Image)(resources.GetObject("pass.IconLeft")));
            this.pass.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.pass.IconPadding = 10;
            this.pass.IconRight = null;
            this.pass.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.pass.Lines = new string[0];
            this.pass.Location = new System.Drawing.Point(134, 247);
            this.pass.MaxLength = 32767;
            this.pass.MinimumSize = new System.Drawing.Size(1, 1);
            this.pass.Modified = false;
            this.pass.Multiline = false;
            this.pass.Name = "pass";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            stateProperties1.ForeColor = System.Drawing.Color.Black;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.pass.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.pass.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            stateProperties3.ForeColor = System.Drawing.Color.Black;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.pass.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            stateProperties4.ForeColor = System.Drawing.Color.Black;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.pass.OnIdleState = stateProperties4;
            this.pass.PasswordChar = '●';
            this.pass.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.pass.PlaceholderText = "Password";
            this.pass.ReadOnly = false;
            this.pass.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.pass.SelectedText = "";
            this.pass.SelectionLength = 0;
            this.pass.SelectionStart = 0;
            this.pass.ShortcutsEnabled = true;
            this.pass.Size = new System.Drawing.Size(300, 45);
            this.pass.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.pass.TabIndex = 2;
            this.pass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.pass.TextMarginBottom = 0;
            this.pass.TextMarginLeft = 5;
            this.pass.TextMarginTop = 0;
            this.pass.TextPlaceholder = "Password";
            this.pass.UseSystemPasswordChar = true;
            this.pass.WordWrap = true;
            this.pass.TextChanged += new System.EventHandler(this.password_TextChanged);
            // 
            // user
            // 
            this.user.AcceptsReturn = false;
            this.user.AcceptsTab = false;
            this.user.AnimationSpeed = 200;
            this.user.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.user.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.user.BackColor = System.Drawing.Color.Transparent;
            this.user.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("user.BackgroundImage")));
            this.user.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.user.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.user.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.user.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            this.user.BorderRadius = 40;
            this.user.BorderThickness = 2;
            this.user.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.user.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.user.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.user.DefaultText = "";
            this.user.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.user.ForeColor = System.Drawing.Color.Black;
            this.user.HideSelection = true;
            this.user.IconLeft = ((System.Drawing.Image)(resources.GetObject("user.IconLeft")));
            this.user.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.user.IconPadding = 10;
            this.user.IconRight = null;
            this.user.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.user.Lines = new string[0];
            this.user.Location = new System.Drawing.Point(134, 195);
            this.user.MaxLength = 32767;
            this.user.MinimumSize = new System.Drawing.Size(1, 1);
            this.user.Modified = false;
            this.user.Multiline = false;
            this.user.Name = "user";
            stateProperties5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            stateProperties5.ForeColor = System.Drawing.Color.Black;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.user.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.user.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            stateProperties7.ForeColor = System.Drawing.Color.Black;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.user.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(169)))), ((int)(((byte)(157)))));
            stateProperties8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            stateProperties8.ForeColor = System.Drawing.Color.Black;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.user.OnIdleState = stateProperties8;
            this.user.PasswordChar = '\0';
            this.user.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.user.PlaceholderText = "Username";
            this.user.ReadOnly = false;
            this.user.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.user.SelectedText = "";
            this.user.SelectionLength = 0;
            this.user.SelectionStart = 0;
            this.user.ShortcutsEnabled = true;
            this.user.Size = new System.Drawing.Size(300, 45);
            this.user.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.user.TabIndex = 1;
            this.user.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.user.TextMarginBottom = 0;
            this.user.TextMarginLeft = 5;
            this.user.TextMarginTop = 0;
            this.user.TextPlaceholder = "Username";
            this.user.UseSystemPasswordChar = false;
            this.user.WordWrap = true;
            this.user.TextChanged += new System.EventHandler(this.username_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(98, 52);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(365, 70);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panel1;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(123, 140);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(323, 10);
            this.bunifuSeparator1.TabIndex = 5;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(253)))), ((int)(((byte)(253)))));
            this.ClientSize = new System.Drawing.Size(570, 475);
            this.Controls.Add(this.bunifuSeparator1);
            this.Controls.Add(this.singin);
            this.Controls.Add(this.pass);
            this.Controls.Add(this.user);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "login";
            this.Load += new System.EventHandler(this.login_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox user;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox pass;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton singin;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
    }
}