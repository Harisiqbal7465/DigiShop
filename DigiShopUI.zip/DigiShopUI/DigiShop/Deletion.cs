﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigiShop
{
    class Deletion
    {
        public void delete_user()
        {
            try {
                SqlCommand cmd = new SqlCommand("sg_delete", DBMain.con);
                cmd.CommandType = CommandType.StoredProcedure;
                DBMain.con.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                DBMain.con.Close();
            }
            
        }
    }
}
