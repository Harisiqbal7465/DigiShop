﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DigiShop
{
    public partial class Additem : Form
    {
        
        public Additem()
        {
            InitializeComponent();
            (new Core.DropShaddow()).ApplyShadows(this);//for shadowing the forn
            bunifuFormDock1.SubscribeControlToDragEvents(panel1,true);//for dragging the form 
          
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
            this.Close();//close the form
        }

        private void btn_Click(object sender, EventArgs e)
        {
            Insertion i = new Insertion(); //insert data into sql server (insertion is globel class) 
            i.add_iteam(t2.Text, t1.Text, Convert.ToSingle(t3.Text), expirypicker.Value, Convert.ToInt32(t4.Text), Convert.ToSingle(t5.Text),Convert.ToSingle(total.Text));//call insertion method for insert data     
        }

        private void t5_TextChanged(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(t5.Text))
            {
                float profit = Convert.ToSingle(t5.Text);//for profit //convert string into float
                float money = Convert.ToSingle(t3.Text);//for price //convert string into float
                profit = (100 + profit) / 100;
                money = profit * money;
                total.Text = Convert.ToString(money);//convert float into string
            }
            else
            {
                total.Text = "00.0000";//if profit text box is emply it show
            }
        }
    }
}
